/*==============================================================================
    DirectX9_HEW_ROC
    [state.h]
    �E�X�e�[�g�Ǘ�
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include "arise.h"
#include "fall.h"
#include "complete.h"
#include "navigator.h"
#include "atlas.h"
#include "pause.h"


enum STATE {
    STATE_NORMAL,
    STATE_ARISE,
    STATE_FALL,
    STATE_COMPLETE,
    STATE_NAVIGATOR,
    STATE_ATLAS,
    STATE_PAUSE,
    
    STATE_MAX,
};

void STATE_update(void);
void STATE_draw(void);

void STATE_set(STATE state);
