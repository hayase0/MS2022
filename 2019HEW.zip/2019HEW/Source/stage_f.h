/*==============================================================================
    DirectX9_HEW_ROC
    [stage_f.h]
    �E�X�e�[�W
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_12_20-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include "camera.h"
#include "shadow.h"

#define MAX_COLLISION_OBJECT   (2048) 


// �I�u�W�F�N�g�ƃ^�[�Q�b�g��Z�߂Ĉړ�������ׂ̍��W�f�[�^�B
struct STAGE_POS {
    float x;
    float y;
    float z;
};

enum STAGE_LUMP {
    STAGE_LUMP_000,     // sekiro
    STAGE_LUMP_001,     // �c���ꍆ
    STAGE_LUMP_002,     // �ŏ��̂Ƃ�
    STAGE_LUMP_003,
    STAGE_LUMP_004,
    STAGE_LUMP_005,
    STAGE_LUMP_006,
    STAGE_LUMP_007,
    STAGE_LUMP_008,
    STAGE_LUMP_009,

    STAGE_LUMP_MAX
};



void STAGE_F_initialize(void);
void STAGE_F_finalize(void);
void STAGE_F_update(void);
void STAGE_F_draw(void);

void STAGE_F_set_collision_object(OBJECT *object);
void STAGE_F_collsion(DYNAMIC_OBJECT *player);
void STAGE_F_collsion_camera(CAMERA *camera);
void STAGE_F_collsion_shadow(SHADOW *shadow);

OBJECT *STAGE_F_get_collision_object(void);

STAGE_POS *STAGE_F_get_stage_pos(void);