/*==============================================================================
    DirectX9_HEW_ROC
    [collision_box.cpp]
    �E�����蔻��
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE (THS_AT12C342_23_80310)  /  2019_11_3-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "player.h"
#include "collision_box.h"
#include "direct3d.h"

#define FLIGHT_ANGLE        (45)    // ���������ʂ̊p�x�����̐��l�����������flight���I�t�ɂ���
#define PLAYER_LEN_FRONT    (0.2f)
#define PLAYER_LEN_BACK     (0.2f)
#define PLAYER_LEN_TOP      (1.0f)
#define PLAYER_LEN_BOTTOM   (0.0f)
#define PLAYER_LEN_RIGHT    (0.2f)
#define PLAYER_LEN_LEFT     (0.2f)

// ���b�V�����̓����蔻��SPHERE�f�[�^
struct MESH_COLLISION_SPHERE {
    D3DXVECTOR3 centerPos;
    D3DXVECTOR3 maxPos;
    bool use;
};

// ���b�V�����̓����蔻��BOX�f�[�^
struct MESH_COLLISION_BOX {
    D3DXVECTOR3 vtxPos[8];
    bool use;
};

struct DYNAMIC_MESH_COLLISION_BOX {
    D3DXVECTOR3 vtxPos[NUM_VERTEX_ALL];
    bool use;
};

MESH_COLLISION_SPHERE MeshColSphere[MESH_INDEX_MAX];
MESH_COLLISION_BOX MeshColBox[MESH_INDEX_MAX][NUM_MESH_BOX];
DYNAMIC_MESH_COLLISION_BOX DynamicMeshColBox[MESH_INDEX_MAX];

// �`��p*********************************************************************************
#define NUM_VERTEX   (18) // ���_��
#define NUM_POLYGON  (16) // �|���S����


// ***************************************************************************************

void COLLISION_BOX_initialize(void) {
    // �v���C���[�̓����蔻��
    MeshColSphere[MESH_INDEX_PLAYER].use = true;
    MeshColSphere[MESH_INDEX_PLAYER].centerPos = D3DXVECTOR3(0.0f, PLAYER_LEN_TOP / 2, 0.0f);
    MeshColSphere[MESH_INDEX_PLAYER].maxPos = D3DXVECTOR3(PLAYER_LEN_RIGHT, PLAYER_LEN_TOP / 2, PLAYER_LEN_FRONT);
    MeshColBox[MESH_INDEX_PLAYER][0].use = true;
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[0] = D3DXVECTOR3(-PLAYER_LEN_LEFT, PLAYER_LEN_TOP, PLAYER_LEN_FRONT);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[1] = D3DXVECTOR3(PLAYER_LEN_RIGHT, PLAYER_LEN_TOP, PLAYER_LEN_FRONT);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[2] = D3DXVECTOR3(PLAYER_LEN_RIGHT, PLAYER_LEN_TOP, -PLAYER_LEN_BACK);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[3] = D3DXVECTOR3(-PLAYER_LEN_LEFT, PLAYER_LEN_TOP, -PLAYER_LEN_BACK);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[4] = D3DXVECTOR3(-PLAYER_LEN_LEFT, -PLAYER_LEN_BOTTOM, PLAYER_LEN_FRONT);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[5] = D3DXVECTOR3(PLAYER_LEN_RIGHT, -PLAYER_LEN_BOTTOM, PLAYER_LEN_FRONT);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[6] = D3DXVECTOR3(PLAYER_LEN_RIGHT, -PLAYER_LEN_BOTTOM, -PLAYER_LEN_BACK);
    MeshColBox[MESH_INDEX_PLAYER][0].vtxPos[7] = D3DXVECTOR3(-PLAYER_LEN_LEFT, -PLAYER_LEN_BOTTOM, -PLAYER_LEN_BACK);
    //MeshColBox[MESH_INDEX_PLAYER][1].use = true;
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[0] = D3DXVECTOR3(-0.2f, 0.0f, 0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[1] = D3DXVECTOR3(0.2f, 0.0f, 0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[2] = D3DXVECTOR3(0.2f, 0.0f, -0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[3] = D3DXVECTOR3(-0.2f, 0.0f, -0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[4] = D3DXVECTOR3(-0.2f, -0.35f, 0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[5] = D3DXVECTOR3(0.2f, -0.35f, 0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[6] = D3DXVECTOR3(0.2f, -0.35f, -0.2f);
    //MeshColBox[MESH_INDEX_PLAYER][1].vtxPos[7] = D3DXVECTOR3(-0.0f, -0.35f, -0.0f);
    DynamicMeshColBox[MESH_INDEX_PLAYER].use = true;
    {
        int i = 0;
        for (int z = 0; z < NUM_VERTEX_Z; z++)
            for (int y = 0; y < NUM_VERTEX_Y; y++)
                for (int x = 0; x < NUM_VERTEX_X; x++)
                    if (x == 0 || x == NUM_VERTEX_X - 1 || y == 0 || y == NUM_VERTEX_Y - 1 || z == 0 || z == NUM_VERTEX_Z - 1) {
                        DynamicMeshColBox[MESH_INDEX_PLAYER].vtxPos[i] =
                            D3DXVECTOR3(-PLAYER_LEN_LEFT + (PLAYER_LEN_RIGHT + PLAYER_LEN_LEFT) / (NUM_VERTEX_X - 1) * x,
                                        -PLAYER_LEN_BOTTOM + (PLAYER_LEN_TOP + PLAYER_LEN_BOTTOM) / (NUM_VERTEX_Y - 1) * y,
                                        -PLAYER_LEN_BACK + (PLAYER_LEN_FRONT + PLAYER_LEN_BACK) / (NUM_VERTEX_Z - 1) * z);
                        i++;
                    }
    }
    // �r���̓����蔻��
    MeshColSphere[MESH_INDEX_BUILDING].use = true;
    MeshColSphere[MESH_INDEX_BUILDING].centerPos = D3DXVECTOR3(0.0f, 9.25f, 0.0f);
    MeshColSphere[MESH_INDEX_BUILDING].maxPos = D3DXVECTOR3(10.7f, 9.25, 8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].use = true;
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[0] = D3DXVECTOR3(-10.7f, 18.5f, 8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[1] = D3DXVECTOR3(10.7f, 18.5f, 8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[2] = D3DXVECTOR3(10.7f, 18.5f, -8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[3] = D3DXVECTOR3(-10.7f, 18.5f, -8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[4] = D3DXVECTOR3(-10.7f, 0.0f, 8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[5] = D3DXVECTOR3(10.7f, 0.0f, 8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[6] = D3DXVECTOR3(10.7f, 0.0f, -8.0f);
    MeshColBox[MESH_INDEX_BUILDING][0].vtxPos[7] = D3DXVECTOR3(-10.7f, 0.0f, -8.0f);

    // �������̓����蔻��
    MeshColSphere[MESH_INDEX_ITEM_000].use = true;
    MeshColSphere[MESH_INDEX_ITEM_000].centerPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    MeshColSphere[MESH_INDEX_ITEM_000].maxPos = D3DXVECTOR3(3.0f, 3.0f, 3.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].use = true;
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[0] = D3DXVECTOR3(-1.0f, 1.0f, 1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[1] = D3DXVECTOR3(1.0f, 1.0f, 1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[2] = D3DXVECTOR3(1.0f, 1.0f, -1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[3] = D3DXVECTOR3(-1.0f, 1.0f, -1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[4] = D3DXVECTOR3(-1.0f, -1.0f, 1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[5] = D3DXVECTOR3(1.0f, -1.0f, 1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[6] = D3DXVECTOR3(1.0f, -1.0f, -1.0f);
    MeshColBox[MESH_INDEX_ITEM_000][0].vtxPos[7] = D3DXVECTOR3(-1.0f, -1.0f, -1.0f);

    // XFile�L���[�u�̓����蔻��
    for (int i = 0; i < 2; i++) {
        int index = MESH_INDEX_STAGE_000 + i;
        MeshColSphere[index].use = true;
        MeshColSphere[index].centerPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        MeshColSphere[index].maxPos = D3DXVECTOR3(1.0f, 1.0, 1.0f);
        MeshColBox[index][0].use = true;
        MeshColBox[index][0].vtxPos[0] = D3DXVECTOR3(-1.0f, 1.0f, 1.0f);
        MeshColBox[index][0].vtxPos[1] = D3DXVECTOR3(1.0f, 1.0f, 1.0f);
        MeshColBox[index][0].vtxPos[2] = D3DXVECTOR3(1.0f, 1.0f, -1.0f);
        MeshColBox[index][0].vtxPos[3] = D3DXVECTOR3(-1.0f, 1.0f, -1.0f);
        MeshColBox[index][0].vtxPos[4] = D3DXVECTOR3(-1.0f, -1.0f, 1.0f);
        MeshColBox[index][0].vtxPos[5] = D3DXVECTOR3(1.0f, -1.0f, 1.0f);
        MeshColBox[index][0].vtxPos[6] = D3DXVECTOR3(1.0f, -1.0f, -1.0f);
        MeshColBox[index][0].vtxPos[7] = D3DXVECTOR3(-1.0f, -1.0f, -1.0f);
    }

    // �L���[�u�̓����蔻��
    MeshColSphere[MESH_INDEX_STAGE_002].use = true;
    MeshColSphere[MESH_INDEX_STAGE_002].centerPos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    MeshColSphere[MESH_INDEX_STAGE_002].maxPos = D3DXVECTOR3(100.0f, 100.0, 100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].use = true;
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[0] = D3DXVECTOR3(-100.0f, 100.0f, 100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[1] = D3DXVECTOR3(100.0f, 100.0f, 100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[2] = D3DXVECTOR3(100.0f, 100.0f, -100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[3] = D3DXVECTOR3(-100.0f, 100.0f, -100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[4] = D3DXVECTOR3(-100.0f, -100.0f, 100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[5] = D3DXVECTOR3(100.0f, -100.0f, 100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[6] = D3DXVECTOR3(100.0f, -100.0f, -100.0f);
    MeshColBox[MESH_INDEX_STAGE_002][0].vtxPos[7] = D3DXVECTOR3(-100.0f, -100.0f, -100.0f);
}

void COLLISION_BOX_setting(DYNAMIC_OBJECT* dynamic_obj) {
    // �����蔻����ݒ�(OBJECT�Ɠ���)
    if (MeshColSphere[dynamic_obj->object.meshIndex].use) {
        dynamic_obj->object.objColSphere.centerPos = D3DXVECTOR3(MeshColSphere[dynamic_obj->object.meshIndex].centerPos.x * dynamic_obj->object.vecScale.x,
                                                                 MeshColSphere[dynamic_obj->object.meshIndex].centerPos.y * dynamic_obj->object.vecScale.y,
                                                                 MeshColSphere[dynamic_obj->object.meshIndex].centerPos.z * dynamic_obj->object.vecScale.z);
        {
            float x = dynamic_obj->object.objColSphere.centerPos.x, y = dynamic_obj->object.objColSphere.centerPos.y, z = dynamic_obj->object.objColSphere.centerPos.z;
            // Z����]
            dynamic_obj->object.objColSphere.centerPos.x = x * cosf(dynamic_obj->object.vecRotation.z) - y * sinf(dynamic_obj->object.vecRotation.z);
            dynamic_obj->object.objColSphere.centerPos.y = x * sinf(dynamic_obj->object.vecRotation.z) + y * cosf(dynamic_obj->object.vecRotation.z);
            // X����]
            y = dynamic_obj->object.objColSphere.centerPos.y;
            dynamic_obj->object.objColSphere.centerPos.y = y * cosf(dynamic_obj->object.vecRotation.x) - z * sinf(dynamic_obj->object.vecRotation.x);
            dynamic_obj->object.objColSphere.centerPos.z = y * sinf(dynamic_obj->object.vecRotation.x) + z * cosf(dynamic_obj->object.vecRotation.x);
            // Y����]
            x = dynamic_obj->object.objColSphere.centerPos.x;
            z = dynamic_obj->object.objColSphere.centerPos.z;
            dynamic_obj->object.objColSphere.centerPos.x = x * cosf(dynamic_obj->object.vecRotation.y) + z * sinf(dynamic_obj->object.vecRotation.y);
            dynamic_obj->object.objColSphere.centerPos.z = -x * sinf(dynamic_obj->object.vecRotation.y) + z * cosf(dynamic_obj->object.vecRotation.y);
        }
        dynamic_obj->object.objColSphere.centerPos += dynamic_obj->object.vecPosition;
        dynamic_obj->object.objColSphere.radius = sqrtf(MeshColSphere[dynamic_obj->object.meshIndex].maxPos.x * dynamic_obj->object.vecScale.x * MeshColSphere[dynamic_obj->object.meshIndex].maxPos.x * dynamic_obj->object.vecScale.x +
                                                        MeshColSphere[dynamic_obj->object.meshIndex].maxPos.y * dynamic_obj->object.vecScale.y * MeshColSphere[dynamic_obj->object.meshIndex].maxPos.y * dynamic_obj->object.vecScale.y +
                                                        MeshColSphere[dynamic_obj->object.meshIndex].maxPos.z * dynamic_obj->object.vecScale.z * MeshColSphere[dynamic_obj->object.meshIndex].maxPos.z * dynamic_obj->object.vecScale.z);
    }
    for (int j = 0; j < NUM_MESH_BOX; j++)
        if (MeshColBox[dynamic_obj->object.meshIndex][j].use) {
            for (int i = 0; i < 8; i++) {
                // ���_�̃��[�J�����W�𔽉f
                dynamic_obj->object.objColBox[j].vtxPos[i] = MeshColBox[dynamic_obj->object.meshIndex][j].vtxPos[i];
                // �v���C���[�̃X�P�[���𔽉f
                dynamic_obj->object.objColBox[j].vtxPos[i].x *= dynamic_obj->object.vecScale.x;
                dynamic_obj->object.objColBox[j].vtxPos[i].y *= dynamic_obj->object.vecScale.y;
                dynamic_obj->object.objColBox[j].vtxPos[i].z *= dynamic_obj->object.vecScale.z;
                // �v���C���[�̉�]�𔽉f
                {
                    float x = dynamic_obj->object.objColBox[j].vtxPos[i].x, y = dynamic_obj->object.objColBox[j].vtxPos[i].y, z = dynamic_obj->object.objColBox[j].vtxPos[i].z;
                    // Z����]
                    dynamic_obj->object.objColBox[j].vtxPos[i].x = x * cosf(dynamic_obj->object.vecRotation.z) - y * sinf(dynamic_obj->object.vecRotation.z);
                    dynamic_obj->object.objColBox[j].vtxPos[i].y = x * sinf(dynamic_obj->object.vecRotation.z) + y * cosf(dynamic_obj->object.vecRotation.z);
                    // X����]
                    y = dynamic_obj->object.objColBox[j].vtxPos[i].y;
                    dynamic_obj->object.objColBox[j].vtxPos[i].y = y * cosf(dynamic_obj->object.vecRotation.x) - z * sinf(dynamic_obj->object.vecRotation.x);
                    dynamic_obj->object.objColBox[j].vtxPos[i].z = y * sinf(dynamic_obj->object.vecRotation.x) + z * cosf(dynamic_obj->object.vecRotation.x);
                    // Y����]
                    x = dynamic_obj->object.objColBox[j].vtxPos[i].x;
                    z = dynamic_obj->object.objColBox[j].vtxPos[i].z;
                    dynamic_obj->object.objColBox[j].vtxPos[i].x = x * cosf(dynamic_obj->object.vecRotation.y) + z * sinf(dynamic_obj->object.vecRotation.y);
                    dynamic_obj->object.objColBox[j].vtxPos[i].z = -x * sinf(dynamic_obj->object.vecRotation.y) + z * cosf(dynamic_obj->object.vecRotation.y);
                }
                // �v���C���[�̍��W�𔽉f
                dynamic_obj->object.objColBox[j].vtxPos[i] += dynamic_obj->object.vecPosition;
            }
#if 0 // �v���C���[�ȊO�ɓ����蔻��(�ʒu�␳�t��)�̂��̂�����ΗL���ɂ���
            { // �ʖ@��
                D3DXVECTOR3 line[2];
                for (int i = 0; i < 6; i++) {
                    switch (i) {
                    case 0:
                        line[0] = dynamic_obj->object.objColBox[j].vtxPos[1] - dynamic_obj->object.objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = dynamic_obj->object.objColBox[j].vtxPos[3] - dynamic_obj->object.objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 1:
                        line[0] = dynamic_obj->object.objColBox[j].vtxPos[5] - dynamic_obj->object.objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = dynamic_obj->object.objColBox[j].vtxPos[7] - dynamic_obj->object.objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 2:
                        line[0] = dynamic_obj->object.objColBox[j].vtxPos[7] - dynamic_obj->object.objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = dynamic_obj->object.objColBox[j].vtxPos[2] - dynamic_obj->object.objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 3:
                        line[0] = dynamic_obj->object.objColBox[j].vtxPos[4] - dynamic_obj->object.objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = dynamic_obj->object.objColBox[j].vtxPos[1] - dynamic_obj->object.objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 4:
                        line[0] = dynamic_obj->object.objColBox[j].vtxPos[2] - dynamic_obj->object.objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = dynamic_obj->object.objColBox[j].vtxPos[5] - dynamic_obj->object.objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 5:
                        line[0] = dynamic_obj->object.objColBox[j].vtxPos[3] - dynamic_obj->object.objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = dynamic_obj->object.objColBox[j].vtxPos[4] - dynamic_obj->object.objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                    };
                    dynamic_obj->object.objColBox[j].faceNor[i].x = line[0].y * line[1].z - line[0].z * line[1].y;
                    dynamic_obj->object.objColBox[j].faceNor[i].y = line[0].z * line[1].x - line[0].x * line[1].z;
                    dynamic_obj->object.objColBox[j].faceNor[i].z = line[0].x * line[1].y - line[0].y * line[1].x;
                    dynamic_obj->object.objColBox[j].faceNor[i] /= sqrtf(dynamic_obj->object.objColBox[j].faceNor[i].x * dynamic_obj->object.objColBox[j].faceNor[i].x +
                                                                         dynamic_obj->object.objColBox[j].faceNor[i].y * dynamic_obj->object.objColBox[j].faceNor[i].y +
                                                                         dynamic_obj->object.objColBox[j].faceNor[i].z * dynamic_obj->object.objColBox[j].faceNor[i].z); // ���K��
                }
            }
#endif
            // AABB
            dynamic_obj->object.objColBox[j].maxPos = dynamic_obj->object.objColBox[j].minPos = dynamic_obj->object.objColBox[j].vtxPos[0];
            for (int i = 1; i < 8; i++) {
                if (dynamic_obj->object.objColBox[j].maxPos.x < dynamic_obj->object.objColBox[j].vtxPos[i].x) dynamic_obj->object.objColBox[j].maxPos.x = dynamic_obj->object.objColBox[j].vtxPos[i].x;
                if (dynamic_obj->object.objColBox[j].minPos.x > dynamic_obj->object.objColBox[j].vtxPos[i].x) dynamic_obj->object.objColBox[j].minPos.x = dynamic_obj->object.objColBox[j].vtxPos[i].x;
                if (dynamic_obj->object.objColBox[j].maxPos.y < dynamic_obj->object.objColBox[j].vtxPos[i].y) dynamic_obj->object.objColBox[j].maxPos.y = dynamic_obj->object.objColBox[j].vtxPos[i].y;
                if (dynamic_obj->object.objColBox[j].minPos.y > dynamic_obj->object.objColBox[j].vtxPos[i].y) dynamic_obj->object.objColBox[j].minPos.y = dynamic_obj->object.objColBox[j].vtxPos[i].y;
                if (dynamic_obj->object.objColBox[j].maxPos.z < dynamic_obj->object.objColBox[j].vtxPos[i].z) dynamic_obj->object.objColBox[j].maxPos.z = dynamic_obj->object.objColBox[j].vtxPos[i].z;
                if (dynamic_obj->object.objColBox[j].minPos.z > dynamic_obj->object.objColBox[j].vtxPos[i].z) dynamic_obj->object.objColBox[j].minPos.z = dynamic_obj->object.objColBox[j].vtxPos[i].z;
            }
        }
    if (DynamicMeshColBox[dynamic_obj->object.meshIndex].use)
        for (int i = 0; i < NUM_VERTEX_ALL; i++) {
            // ���_�̃��[�J�����W�𔽉f
            dynamic_obj->vtxPos[i] = DynamicMeshColBox[dynamic_obj->object.meshIndex].vtxPos[i];
            // �v���C���[�̃X�P�[���𔽉f
            dynamic_obj->vtxPos[i].x *= dynamic_obj->object.vecScale.x;
            dynamic_obj->vtxPos[i].y *= dynamic_obj->object.vecScale.y;
            dynamic_obj->vtxPos[i].z *= dynamic_obj->object.vecScale.z;
            // �v���C���[�̉�]�𔽉f
            {
                float fx = dynamic_obj->vtxPos[i].x, fy = dynamic_obj->vtxPos[i].y, fz = dynamic_obj->vtxPos[i].z;
                // Z����]
                dynamic_obj->vtxPos[i].x = fx * cosf(dynamic_obj->object.vecRotation.z) - fy * sinf(dynamic_obj->object.vecRotation.z);
                dynamic_obj->vtxPos[i].y = fx * sinf(dynamic_obj->object.vecRotation.z) + fy * cosf(dynamic_obj->object.vecRotation.z);
                // X����]
                fy = dynamic_obj->vtxPos[i].y;
                dynamic_obj->vtxPos[i].y = fy * cosf(dynamic_obj->object.vecRotation.x) - fz * sinf(dynamic_obj->object.vecRotation.x);
                dynamic_obj->vtxPos[i].z = fy * sinf(dynamic_obj->object.vecRotation.x) + fz * cosf(dynamic_obj->object.vecRotation.x);
                // Y����]
                fx = dynamic_obj->vtxPos[i].x;
                fz = dynamic_obj->vtxPos[i].z;
                dynamic_obj->vtxPos[i].x = fx * cosf(dynamic_obj->object.vecRotation.y) + fz * sinf(dynamic_obj->object.vecRotation.y);
                dynamic_obj->vtxPos[i].z = -fx * sinf(dynamic_obj->object.vecRotation.y) + fz * cosf(dynamic_obj->object.vecRotation.y);
            }
            // �v���C���[�̍��W�𔽉f
            dynamic_obj->vtxPos[i] += dynamic_obj->object.vecPosition;
        }
}

void COLLISION_BOX_setting(OBJECT* obj) {
    // �����蔻����ݒ�(OBJECT�Ɠ���)
    if (MeshColSphere[obj->meshIndex].use) {
        obj->objColSphere.centerPos = D3DXVECTOR3(MeshColSphere[obj->meshIndex].centerPos.x * obj->vecScale.x,
                                                  MeshColSphere[obj->meshIndex].centerPos.y * obj->vecScale.y,
                                                  MeshColSphere[obj->meshIndex].centerPos.z * obj->vecScale.z);
        {
            float x = obj->objColSphere.centerPos.x, y = obj->objColSphere.centerPos.y, z = obj->objColSphere.centerPos.z;
            // Z����]
            obj->objColSphere.centerPos.x = x * cosf(obj->vecRotation.z) - y * sinf(obj->vecRotation.z);
            obj->objColSphere.centerPos.y = x * sinf(obj->vecRotation.z) + y * cosf(obj->vecRotation.z);
            // X����]
            y = obj->objColSphere.centerPos.y;
            obj->objColSphere.centerPos.y = y * cosf(obj->vecRotation.x) - z * sinf(obj->vecRotation.x);
            obj->objColSphere.centerPos.z = y * sinf(obj->vecRotation.x) + z * cosf(obj->vecRotation.x);
            // Y����]
            x = obj->objColSphere.centerPos.x;
            z = obj->objColSphere.centerPos.z;
            obj->objColSphere.centerPos.x = x * cosf(obj->vecRotation.y) + z * sinf(obj->vecRotation.y);
            obj->objColSphere.centerPos.z = -x * sinf(obj->vecRotation.y) + z * cosf(obj->vecRotation.y);
        }
        obj->objColSphere.centerPos += obj->vecPosition;
        obj->objColSphere.radius = sqrtf(MeshColSphere[obj->meshIndex].maxPos.x * obj->vecScale.x * MeshColSphere[obj->meshIndex].maxPos.x * obj->vecScale.x +
                                         MeshColSphere[obj->meshIndex].maxPos.y * obj->vecScale.y * MeshColSphere[obj->meshIndex].maxPos.y * obj->vecScale.y +
                                         MeshColSphere[obj->meshIndex].maxPos.z * obj->vecScale.z * MeshColSphere[obj->meshIndex].maxPos.z * obj->vecScale.z);
    }
    if (MeshColSphere[obj->meshIndex].use) {
        obj->objColSphere.centerPos = D3DXVECTOR3(MeshColSphere[obj->meshIndex].centerPos.x * obj->vecScale.x,
                                                  MeshColSphere[obj->meshIndex].centerPos.y * obj->vecScale.y,
                                                  MeshColSphere[obj->meshIndex].centerPos.z * obj->vecScale.z) + obj->vecPosition;
        obj->objColSphere.radius = sqrtf(MeshColSphere[obj->meshIndex].maxPos.x * obj->vecScale.x * MeshColSphere[obj->meshIndex].maxPos.x * obj->vecScale.x +
                                         MeshColSphere[obj->meshIndex].maxPos.y * obj->vecScale.y * MeshColSphere[obj->meshIndex].maxPos.y * obj->vecScale.y +
                                         MeshColSphere[obj->meshIndex].maxPos.z * obj->vecScale.z * MeshColSphere[obj->meshIndex].maxPos.z * obj->vecScale.z);
    }
    for (int j = 0; j < NUM_MESH_BOX; j++)
        if (MeshColBox[obj->meshIndex][j].use) {
            for (int i = 0; i < 8; i++) {
                // ���_�̃��[�J�����W�𔽉f
                obj->objColBox[j].vtxPos[i] = MeshColBox[obj->meshIndex][j].vtxPos[i];
                // �v���C���[�̃X�P�[���𔽉f
                obj->objColBox[j].vtxPos[i].x *= obj->vecScale.x;
                obj->objColBox[j].vtxPos[i].y *= obj->vecScale.y;
                obj->objColBox[j].vtxPos[i].z *= obj->vecScale.z;
                // �v���C���[�̉�]�𔽉f
                {
                    float x = obj->objColBox[j].vtxPos[i].x, y = obj->objColBox[j].vtxPos[i].y, z = obj->objColBox[j].vtxPos[i].z;
                    // Z����]
                    obj->objColBox[j].vtxPos[i].x = x * cosf(obj->vecRotation.z) - y * sinf(obj->vecRotation.z);
                    obj->objColBox[j].vtxPos[i].y = x * sinf(obj->vecRotation.z) + y * cosf(obj->vecRotation.z);
                    // X����]
                    y = obj->objColBox[j].vtxPos[i].y;
                    obj->objColBox[j].vtxPos[i].y = y * cosf(obj->vecRotation.x) - z * sinf(obj->vecRotation.x);
                    obj->objColBox[j].vtxPos[i].z = y * sinf(obj->vecRotation.x) + z * cosf(obj->vecRotation.x);
                    // Y����]
                    x = obj->objColBox[j].vtxPos[i].x;
                    z = obj->objColBox[j].vtxPos[i].z;
                    obj->objColBox[j].vtxPos[i].x = x * cosf(obj->vecRotation.y) + z * sinf(obj->vecRotation.y);
                    obj->objColBox[j].vtxPos[i].z = -x * sinf(obj->vecRotation.y) + z * cosf(obj->vecRotation.y);
                }
                // �v���C���[�̍��W�𔽉f
                obj->objColBox[j].vtxPos[i] += obj->vecPosition;
            }
            { // �ʖ@��
                D3DXVECTOR3 line[2];
                for (int i = 0; i < 6; i++) {
                    switch (i) {
                    case 0:
                        line[0] = obj->objColBox[j].vtxPos[1] - obj->objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = obj->objColBox[j].vtxPos[3] - obj->objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 1:
                        line[0] = obj->objColBox[j].vtxPos[5] - obj->objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = obj->objColBox[j].vtxPos[7] - obj->objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 2:
                        line[0] = obj->objColBox[j].vtxPos[7] - obj->objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = obj->objColBox[j].vtxPos[2] - obj->objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 3:
                        line[0] = obj->objColBox[j].vtxPos[4] - obj->objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = obj->objColBox[j].vtxPos[1] - obj->objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 4:
                        line[0] = obj->objColBox[j].vtxPos[2] - obj->objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = obj->objColBox[j].vtxPos[5] - obj->objColBox[j].vtxPos[6];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        break;
                    case 5:
                        line[0] = obj->objColBox[j].vtxPos[3] - obj->objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                        line[1] = obj->objColBox[j].vtxPos[4] - obj->objColBox[j].vtxPos[0];    // ���ʂ�1���_����ʂ�1���_�ւ̃x�N�g��
                    };
                    obj->objColBox[j].faceNor[i].x = line[0].y * line[1].z - line[0].z * line[1].y;
                    obj->objColBox[j].faceNor[i].y = line[0].z * line[1].x - line[0].x * line[1].z;
                    obj->objColBox[j].faceNor[i].z = line[0].x * line[1].y - line[0].y * line[1].x;
                    obj->objColBox[j].faceNor[i] /= sqrtf(obj->objColBox[j].faceNor[i].x * obj->objColBox[j].faceNor[i].x +
                                                          obj->objColBox[j].faceNor[i].y * obj->objColBox[j].faceNor[i].y +
                                                          obj->objColBox[j].faceNor[i].z * obj->objColBox[j].faceNor[i].z); // ���K��
                }
            }
            // AABB
            obj->objColBox[j].maxPos = obj->objColBox[j].minPos = obj->objColBox[j].vtxPos[0];
            for (int i = 1; i < 8; i++) {
                if (obj->objColBox[j].maxPos.x < obj->objColBox[j].vtxPos[i].x) obj->objColBox[j].maxPos.x = obj->objColBox[j].vtxPos[i].x;
                if (obj->objColBox[j].minPos.x > obj->objColBox[j].vtxPos[i].x) obj->objColBox[j].minPos.x = obj->objColBox[j].vtxPos[i].x;
                if (obj->objColBox[j].maxPos.y < obj->objColBox[j].vtxPos[i].y) obj->objColBox[j].maxPos.y = obj->objColBox[j].vtxPos[i].y;
                if (obj->objColBox[j].minPos.y > obj->objColBox[j].vtxPos[i].y) obj->objColBox[j].minPos.y = obj->objColBox[j].vtxPos[i].y;
                if (obj->objColBox[j].maxPos.z < obj->objColBox[j].vtxPos[i].z) obj->objColBox[j].maxPos.z = obj->objColBox[j].vtxPos[i].z;
                if (obj->objColBox[j].minPos.z > obj->objColBox[j].vtxPos[i].z) obj->objColBox[j].minPos.z = obj->objColBox[j].vtxPos[i].z;
            }
        }
}

bool COLLISION_BOX_trigger(const DYNAMIC_OBJECT* dynamic_obj, const OBJECT* obj) {
    D3DXVECTOR3 line = dynamic_obj->object.objColSphere.centerPos - obj->objColSphere.centerPos;
    if (MeshColSphere[obj->meshIndex].use && sqrtf(line.x * line.x + line.y * line.y + line.z * line.z) <= dynamic_obj->object.objColSphere.radius + obj->objColSphere.radius)
        return true;
    return false;
}

static bool collision_detection(D3DXVECTOR3 face_vtx1, D3DXVECTOR3 face_vtx2, D3DXVECTOR3 face_vtx3, D3DXVECTOR3 face_vtx4, D3DXVECTOR3 face_nor, D3DXVECTOR3 line1, D3DXVECTOR3 line2, D3DXVECTOR3 line_vtx, DYNAMIC_OBJECT* dynamic_obj, float dot1) {
    float dot2 = face_nor.x * line2.x + face_nor.y * line2.y + face_nor.z * line2.z;
    if (dot2 <= 0) {
        float distance[2];
        distance[0] = fabsf(dot1);
        distance[1] = fabsf(dot2);
        float internalRatio = distance[0] / (distance[0] + distance[1]);    // ������
        D3DXVECTOR3 col_point = face_vtx1 + (1 - internalRatio) * line1 + internalRatio * line2;    // �Փ˓_
        bool inside = true; // �����ɂ��邩
        D3DXVECTOR3 line[2];
        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                line[0] = face_vtx2 - face_vtx1;
                line[1] = col_point - face_vtx2;
            }
            if (i == 1) {
                line[0] = face_vtx3 - face_vtx2;
                line[1] = col_point - face_vtx3;
            }
            if (i == 2) {
                line[0] = face_vtx4 - face_vtx3;
                line[1] = col_point - face_vtx4;
            }
            if (i == 3) {
                line[0] = face_vtx1 - face_vtx4;
                line[1] = col_point - face_vtx1;
            }
            D3DXVECTOR3 cross;
            cross.x = line[0].y * line[1].z - line[0].z * line[1].y;
            cross.y = line[0].z * line[1].x - line[0].x * line[1].z;
            cross.z = line[0].x * line[1].y - line[0].y * line[1].x;
            if (face_nor.x * cross.x < 0 || face_nor.y * cross.y < 0 || face_nor.z * cross.z < 0) {
                inside = false;
                break;
            }
        }
        if (inside) {
            line[0] = line2;
            line[1] = line_vtx + face_nor * 10 - face_vtx1;
            distance[0] = fabsf(face_nor.x * line[0].x + face_nor.y * line[0].y + face_nor.z * line[0].z);
            distance[1] = fabsf(face_nor.x * line[1].x + face_nor.y * line[1].y + face_nor.z * line[1].z);
            internalRatio = distance[0] / (distance[0] + distance[1]);  // ������
            col_point = face_vtx1 + (1 - internalRatio) * line[0] + internalRatio * line[1];    // �Փ˓_
            dynamic_obj->object.vecPosition.y += (col_point.y - line_vtx.y) * 1.001f;   // �v���C���[�̃|�W�V�����X�V
            COLLISION_BOX_setting(dynamic_obj);
            if (face_nor.y >= sinf(D3DXToRadian(90 - FLIGHT_ANGLE))) {  // ���������ʂ̊p�x��FLIGHT_ANGLE��菬������Βn�ʂƂ��Ĕ���
                if (dynamic_obj->move.y < 0)dynamic_obj->flight = false;
            }
            else {
                dynamic_obj->object.vecPosition.x += (col_point.x - line_vtx.x) * 1.001f;   // �v���C���[�̃|�W�V�����X�V          
                dynamic_obj->object.vecPosition.z += (col_point.z - line_vtx.z) * 1.001f;   // �v���C���[�̃|�W�V�����X�V
                dynamic_obj->conflict = true;
            }
            return true;
        }
    }
    return false;
}

static bool collision_detection(D3DXVECTOR3 face_vtx1, D3DXVECTOR3 face_vtx2, D3DXVECTOR3 face_vtx3, D3DXVECTOR3 face_vtx4, D3DXVECTOR3 face_nor, D3DXVECTOR3 line_vtx1, D3DXVECTOR3 line_vtx2, D3DXVECTOR3 *col_point) {
    D3DXVECTOR3 line[2];
    line[0] = line_vtx1 - face_vtx1;    // ���ʂ�1���_�������1���_�ւ̃x�N�g��
    line[1] = line_vtx2 - face_vtx1;    // ���ʂ�1���_�������1���_�ւ̃x�N�g��
    float dot[2];   // ���ʂ̖@���ƕ��ʂ�1���_�������1���_�ւ̐��̓���
    dot[0] = face_nor.x * line[0].x + face_nor.y * line[0].y + face_nor.z * line[0].z;
    dot[1] = face_nor.x * line[1].x + face_nor.y * line[1].y + face_nor.z * line[1].z;
    if (dot[0] >= 0 && dot[1] <= 0) {
        float distance[2];
        distance[0] = fabsf(dot[0]);
        distance[1] = fabsf(dot[1]);
        float internalRatio = distance[0] / (distance[0] + distance[1]);    // ������
        *col_point = face_vtx1 + (1 - internalRatio) * line[0] + internalRatio * line[1];    // �Փ˓_
        bool inside = true; // �����ɂ��邩
        for (int i = 0; i < 4; i++) {
            if (i == 0) {
                line[0] = face_vtx2 - face_vtx1;
                line[1] = *col_point - face_vtx2;
            }
            if (i == 1) {
                line[0] = face_vtx3 - face_vtx2;
                line[1] = *col_point - face_vtx3;
            }
            if (i == 2) {
                line[0] = face_vtx4 - face_vtx3;
                line[1] = *col_point - face_vtx4;
            }
            if (i == 3) {
                line[0] = face_vtx1 - face_vtx4;
                line[1] = *col_point - face_vtx1;
            }
            D3DXVECTOR3 cross;
            cross.x = line[0].y * line[1].z - line[0].z * line[1].y;
            cross.y = line[0].z * line[1].x - line[0].x * line[1].z;
            cross.z = line[0].x * line[1].y - line[0].y * line[1].x;
            if (face_nor.x * cross.x < 0 || face_nor.y * cross.y < 0 || face_nor.z * cross.z < 0) {
                inside = false;
                break;
            }
        }
        if (inside)return true;
    }
    return false;
}

bool COLLISION_BOX_collision(DYNAMIC_OBJECT* dynamic_obj, const OBJECT* obj) {
    D3DXVECTOR3 distance = dynamic_obj->object.objColSphere.centerPos - obj->objColSphere.centerPos;
    if (MeshColSphere[obj->meshIndex].use && D3DXVec3LengthSq(&distance) <= powf(dynamic_obj->object.objColSphere.radius + obj->objColSphere.radius, 2))
        for (int i = 0; i < NUM_MESH_BOX; i++)
            if (MeshColBox[obj->meshIndex][i].use) {
                // AABB�̓����蔻��
                if (obj->objColBox[i].AABB) {
                    if (dynamic_obj->object.objColBox[0].minPos.x > obj->objColBox[i].maxPos.x) return false;
                    if (dynamic_obj->object.objColBox[0].maxPos.x < obj->objColBox[i].minPos.x) return false;
                    if (dynamic_obj->object.objColBox[0].minPos.y > obj->objColBox[i].maxPos.y) return false;
                    if (dynamic_obj->object.objColBox[0].maxPos.y < obj->objColBox[i].minPos.y) return false;
                    if (dynamic_obj->object.objColBox[0].minPos.z > obj->objColBox[i].maxPos.z) return false;
                    if (dynamic_obj->object.objColBox[0].maxPos.z < obj->objColBox[i].minPos.z) return false;
                }

                D3DXVECTOR3 line1[2];
                line1[0] = dynamic_obj->object.objColSphere.centerPos - obj->objColBox[i].vtxPos[0]; // ���ʂ�1���_�������1���_�ւ̃x�N�g��
                line1[1] = dynamic_obj->object.objColSphere.centerPos - obj->objColBox[i].vtxPos[6]; // ���ʂ�1���_�������1���_�ւ̃x�N�g��
                bool dot1Flag[6] = { false }; // ���I�I�u�W�F�̒��S�_���ʂ̖@�������ɂ��邩
                float dot1[6];
                dot1[0] = obj->objColBox[i].faceNor[0].x * line1[0].x + obj->objColBox[i].faceNor[0].y * line1[0].y + obj->objColBox[i].faceNor[0].z * line1[0].z;
                dot1[1] = obj->objColBox[i].faceNor[1].x * line1[1].x + obj->objColBox[i].faceNor[1].y * line1[1].y + obj->objColBox[i].faceNor[1].z * line1[1].z;
                dot1[2] = obj->objColBox[i].faceNor[2].x * line1[1].x + obj->objColBox[i].faceNor[2].y * line1[1].y + obj->objColBox[i].faceNor[2].z * line1[1].z;
                dot1[3] = obj->objColBox[i].faceNor[3].x * line1[0].x + obj->objColBox[i].faceNor[3].y * line1[0].y + obj->objColBox[i].faceNor[3].z * line1[0].z;
                dot1[4] = obj->objColBox[i].faceNor[4].x * line1[1].x + obj->objColBox[i].faceNor[4].y * line1[1].y + obj->objColBox[i].faceNor[4].z * line1[1].z;
                dot1[5] = obj->objColBox[i].faceNor[5].x * line1[0].x + obj->objColBox[i].faceNor[5].y * line1[0].y + obj->objColBox[i].faceNor[5].z * line1[0].z;
                for (int j = 0; j < 6; j++)
                    if (dot1[j] >= 0 && obj->objColBox[i].faceUse[i]) dot1Flag[j] = true;
                for (int j = 0; j < NUM_VERTEX_ALL; j++) {
                    D3DXVECTOR3 line2[2];
                    line2[0] = dynamic_obj->vtxPos[j] - obj->objColBox[i].vtxPos[0]; // ���ʂ�1���_�������1���_�ւ̃x�N�g��
                    line2[1] = dynamic_obj->vtxPos[j] - obj->objColBox[i].vtxPos[6]; // ���ʂ�1���_�������1���_�ւ̃x�N�g��
                    if (dot1Flag[0])
                        if (collision_detection(obj->objColBox[i].vtxPos[0], obj->objColBox[i].vtxPos[1], obj->objColBox[i].vtxPos[2], obj->objColBox[i].vtxPos[3], obj->objColBox[i].faceNor[0], line1[0], line2[0], dynamic_obj->vtxPos[j], dynamic_obj, dot1[0]))return true;
                    if (dot1Flag[1])
                        if (collision_detection(obj->objColBox[i].vtxPos[6], obj->objColBox[i].vtxPos[5], obj->objColBox[i].vtxPos[4], obj->objColBox[i].vtxPos[7], obj->objColBox[i].faceNor[1], line1[1], line2[1], dynamic_obj->vtxPos[j], dynamic_obj, dot1[1]))return true;
                    if (dot1Flag[2])
                        if (collision_detection(obj->objColBox[i].vtxPos[6], obj->objColBox[i].vtxPos[7], obj->objColBox[i].vtxPos[3], obj->objColBox[i].vtxPos[2], obj->objColBox[i].faceNor[2], line1[1], line2[1], dynamic_obj->vtxPos[j], dynamic_obj, dot1[2]))return true;
                    if (dot1Flag[3])
                        if (collision_detection(obj->objColBox[i].vtxPos[0], obj->objColBox[i].vtxPos[4], obj->objColBox[i].vtxPos[5], obj->objColBox[i].vtxPos[1], obj->objColBox[i].faceNor[3], line1[0], line2[0], dynamic_obj->vtxPos[j], dynamic_obj, dot1[3]))return true;
                    if (dot1Flag[4])
                        if (collision_detection(obj->objColBox[i].vtxPos[6], obj->objColBox[i].vtxPos[2], obj->objColBox[i].vtxPos[1], obj->objColBox[i].vtxPos[5], obj->objColBox[i].faceNor[4], line1[1], line2[1], dynamic_obj->vtxPos[j], dynamic_obj, dot1[4]))return true;
                    if (dot1Flag[5])
                        if (collision_detection(obj->objColBox[i].vtxPos[0], obj->objColBox[i].vtxPos[3], obj->objColBox[i].vtxPos[7], obj->objColBox[i].vtxPos[4], obj->objColBox[i].faceNor[5], line1[0], line2[0], dynamic_obj->vtxPos[j], dynamic_obj, dot1[5]))return true;
                }
            }
    return false;
}

bool COLLISION_BOX_vsline(const DYNAMIC_OBJECT* dynamic_obj, const OBJECT* obj, D3DXVECTOR3 startpos, D3DXVECTOR3 endpos, D3DXVECTOR3 *col_point) {
    float tmp_length = 1000000;
    D3DXVECTOR3 tmp_col_point;
    if (D3DXVec3LengthSq(&(dynamic_obj->object.objColSphere.centerPos - obj->objColSphere.centerPos)) <= powf(D3DXVec3Length(&(startpos - endpos)) + obj->objColSphere.radius, 2))
        for (int i = 0; i < NUM_MESH_BOX; i++)
            if (MeshColBox[obj->meshIndex][i].use)
                for (int j = 0; j < NUM_VERTEX_ALL; j++) {
                    if (collision_detection(obj->objColBox[i].vtxPos[0], obj->objColBox[i].vtxPos[1], obj->objColBox[i].vtxPos[2], obj->objColBox[i].vtxPos[3], obj->objColBox[i].faceNor[0], startpos, endpos, &tmp_col_point))
                        if (tmp_length > D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()))) {
                            tmp_length = D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()));
                            *col_point = tmp_col_point;
                        }
                    if (collision_detection(obj->objColBox[i].vtxPos[4], obj->objColBox[i].vtxPos[7], obj->objColBox[i].vtxPos[6], obj->objColBox[i].vtxPos[5], obj->objColBox[i].faceNor[1], startpos, endpos, &tmp_col_point))
                        if (tmp_length > D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()))) {
                            tmp_length = D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()));
                            *col_point = tmp_col_point;
                        }
                    if (collision_detection(obj->objColBox[i].vtxPos[3], obj->objColBox[i].vtxPos[2], obj->objColBox[i].vtxPos[6], obj->objColBox[i].vtxPos[7], obj->objColBox[i].faceNor[2], startpos, endpos, &tmp_col_point))
                        if (tmp_length > D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()))) {
                            tmp_length = D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()));
                            *col_point = tmp_col_point;
                        }
                    if (collision_detection(obj->objColBox[i].vtxPos[0], obj->objColBox[i].vtxPos[4], obj->objColBox[i].vtxPos[5], obj->objColBox[i].vtxPos[1], obj->objColBox[i].faceNor[3], startpos, endpos, &tmp_col_point))
                        if (tmp_length > D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()))) {
                            tmp_length = D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()));
                            *col_point = tmp_col_point;
                        }
                    if (collision_detection(obj->objColBox[i].vtxPos[2], obj->objColBox[i].vtxPos[1], obj->objColBox[i].vtxPos[5], obj->objColBox[i].vtxPos[6], obj->objColBox[i].faceNor[4], startpos, endpos, &tmp_col_point))
                        if (tmp_length > D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()))) {
                            tmp_length = D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()));
                            *col_point = tmp_col_point;
                        }
                    if (collision_detection(obj->objColBox[i].vtxPos[3], obj->objColBox[i].vtxPos[7], obj->objColBox[i].vtxPos[4], obj->objColBox[i].vtxPos[0], obj->objColBox[i].faceNor[5], startpos, endpos, &tmp_col_point))
                        if (tmp_length > D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()))) {
                            tmp_length = D3DXVec3LengthSq(&(tmp_col_point - PLAYER_getpos()));
                            *col_point = tmp_col_point;
                        }
                }
    if (tmp_length != 1000000) return true;
    return false;
}

void COLLISION_BOX_draw_initialize(OBJECT* obj) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    // ���_�f�[�^�쐬
    for (int i = 0; i < NUM_MESH_BOX; i++)
        if (MeshColBox[obj->meshIndex][i].use) {
            pDevice->CreateVertexBuffer(sizeof(VERTEX_3D) * NUM_VERTEX, D3DUSAGE_WRITEONLY, FVF_VERTEX_3D, D3DPOOL_MANAGED, &obj->objColBox[i].vtxBuff, NULL);

            // ���_�f�[�^��ύX���邽�߂̃|�C���^
            VERTEX_3D *pVtx;

            // ���b�N(���_�f�[�^��VRAM���烁�����Ɏ����Ă���(���_�f�[�^��ύX�\�ɂ���))
            obj->objColBox[i].vtxBuff->Lock(0, 0, (void**)&pVtx, 0);

            // ���_���W
            // ���&��O��
            pVtx[0].pos = obj->objColBox[i].vtxPos[0];
            pVtx[1].pos = obj->objColBox[i].vtxPos[1];
            pVtx[2].pos = obj->objColBox[i].vtxPos[3];
            pVtx[3].pos = obj->objColBox[i].vtxPos[2];
            pVtx[4].pos = obj->objColBox[i].vtxPos[7];
            pVtx[5].pos = obj->objColBox[i].vtxPos[6];
            // �E��&����
            pVtx[6].pos = obj->objColBox[i].vtxPos[6];
            pVtx[7].pos = obj->objColBox[i].vtxPos[2];
            pVtx[8].pos = obj->objColBox[i].vtxPos[5];
            pVtx[9].pos = obj->objColBox[i].vtxPos[1];
            pVtx[10].pos = obj->objColBox[i].vtxPos[4];
            pVtx[11].pos = obj->objColBox[i].vtxPos[0];
            // ����&����
            pVtx[12].pos = obj->objColBox[i].vtxPos[0];
            pVtx[13].pos = obj->objColBox[i].vtxPos[3];
            pVtx[14].pos = obj->objColBox[i].vtxPos[4];
            pVtx[15].pos = obj->objColBox[i].vtxPos[7];
            pVtx[16].pos = obj->objColBox[i].vtxPos[5];
            pVtx[17].pos = obj->objColBox[i].vtxPos[6];

            // �J���[�ύX(RGBA)
            for (int j = 0; j < 18; j++)pVtx[j].col = D3DXCOLOR(0.0f, 0.0f, 1.0f, 0.5f);

            // �A�����b�N(���_�f�[�^������������VRAM�ɕԂ�(���_�f�[�^�ύX�s�ɂȂ�))
            obj->objColBox[i].vtxBuff->Unlock();
        }
}

void COLLISION_BOX_draw(DYNAMIC_OBJECT* dynamic_obj) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    for (int i = 0; i < NUM_MESH_BOX; i++)
        if (MeshColBox[dynamic_obj->object.meshIndex][i].use) {
            // ���_�f�[�^�X�V
            {
                // ���_�f�[�^��ύX���邽�߂̃|�C���^
                VERTEX_3D *pVtx;

                // ���b�N(���_�f�[�^��VRAM���烁�����Ɏ����Ă���(���_�f�[�^��ύX�\�ɂ���))
                dynamic_obj->object.objColBox[i].vtxBuff->Lock(0, 0, (void**)&pVtx, 0);

                // ���_���W
                // ���&��O��
                pVtx[0].pos = dynamic_obj->object.objColBox[i].vtxPos[0];
                pVtx[1].pos = dynamic_obj->object.objColBox[i].vtxPos[1];
                pVtx[2].pos = dynamic_obj->object.objColBox[i].vtxPos[3];
                pVtx[3].pos = dynamic_obj->object.objColBox[i].vtxPos[2];
                pVtx[4].pos = dynamic_obj->object.objColBox[i].vtxPos[7];
                pVtx[5].pos = dynamic_obj->object.objColBox[i].vtxPos[6];
                // �E��&����
                pVtx[6].pos = dynamic_obj->object.objColBox[i].vtxPos[6];
                pVtx[7].pos = dynamic_obj->object.objColBox[i].vtxPos[2];
                pVtx[8].pos = dynamic_obj->object.objColBox[i].vtxPos[5];
                pVtx[9].pos = dynamic_obj->object.objColBox[i].vtxPos[1];
                pVtx[10].pos = dynamic_obj->object.objColBox[i].vtxPos[4];
                pVtx[11].pos = dynamic_obj->object.objColBox[i].vtxPos[0];
                // ����&����
                pVtx[12].pos = dynamic_obj->object.objColBox[i].vtxPos[0];
                pVtx[13].pos = dynamic_obj->object.objColBox[i].vtxPos[3];
                pVtx[14].pos = dynamic_obj->object.objColBox[i].vtxPos[4];
                pVtx[15].pos = dynamic_obj->object.objColBox[i].vtxPos[7];
                pVtx[16].pos = dynamic_obj->object.objColBox[i].vtxPos[5];
                pVtx[17].pos = dynamic_obj->object.objColBox[i].vtxPos[6];

                // �J���[�ύX(RGBA)
                for (int j = 0; j < 18; j++)pVtx[j].col = D3DXCOLOR(0.0f, 0.0f, 1.0f, 0.5f);

                // �A�����b�N(���_�f�[�^������������VRAM�ɕԂ�(���_�f�[�^�ύX�s�ɂȂ�))
                dynamic_obj->object.objColBox[i].vtxBuff->Unlock();
            }
            // �`��
            D3DXMATRIX matrix;
            D3DXMatrixIdentity(&matrix);
            pDevice->SetTransform(D3DTS_WORLD, &matrix);
            pDevice->SetStreamSource(0, dynamic_obj->object.objColBox[i].vtxBuff, 0, sizeof(VERTEX_3D));
            pDevice->SetFVF(FVF_VERTEX_3D);
            pDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, NUM_POLYGON);
        }
}

void COLLISION_BOX_draw(OBJECT* obj) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    for (int i = 0; i < NUM_MESH_BOX; i++)
        if (MeshColBox[obj->meshIndex][i].use) {
            // �`��
            D3DXMATRIX matrix;
            D3DXMatrixIdentity(&matrix);
            pDevice->SetTransform(D3DTS_WORLD, &matrix);
            pDevice->SetStreamSource(0, obj->objColBox[i].vtxBuff, 0, sizeof(VERTEX_3D));
            pDevice->SetFVF(FVF_VERTEX_3D);
            pDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, NUM_POLYGON);
        }
}