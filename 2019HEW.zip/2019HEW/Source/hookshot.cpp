/*==============================================================================
    DirectX9_HEW_ROC
    [ARM.cpp]
    �E�t�b�N�V���b�g
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_16-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "direct3d.h"
#include "gamepad.h"
#include "keyboard.h"
 
#include "player.h"
#include "player_action.h"
#include "player_state.h"
#include "stage.h"
#include "camera.h"
#include "collision_box.h"
#include <time.h>
#include <math.h>

#define FRAME_SHOT       (10)         //�t�b�N�V���b�g���˃X�s�[�h

static OBJECT hook;
static bool shot = false;             //�t�b�N�V���b�g���˃t���O
static D3DXVECTOR3 hook_goal;         //�t�b�N�V���b�g����ڕW�_�܂ł̃x�N�g��
static int frame;                     //�t���[���J�E���g�p

void ARM_initialize(void) {
    hook.vecPosition = PLAYER_getpos();
    hook.vecRotation = *PLAYER_getrot();
    hook.vecRotation.x = D3DX_PI / 2;
    hook.vecScale = D3DXVECTOR3(3, 3, 3);
    shot = false;
}

void ARM_update(void) {
    //�v���C���[�ɒǏ]
    if (PLAYER_STATE_get() != PLAYER_STATE_SHOT && PLAYER_STATE_get() != PLAYER_STATE_HOOKMOVE && PLAYER_STATE_get() != PLAYER_STATE_SWING) {
        hook.vecPosition = PLAYER_getpos();
        hook.vecPosition.y += 3.0f;
        hook.vecRotation = *PLAYER_getrot();
        hook.vecRotation.x = D3DX_PI / 2;
    }
}

void ARM_draw(void) {
    MESH_render(&hook, MESH_INDEX_ARM);
}

void ARM_shot(void) {
    DYNAMIC_OBJECT *player = PLAYER_get();
    hook.vecPosition += hook_goal / FRAME_SHOT;

    frame++;
    if (frame >= FRAME_SHOT) { //�ڕW�_�܂œ��B��
        PLAYER_STATE_set(PLAYER_STATE_SWING);
        PLAYER_ACTION_sethookmove();
        frame = 0;
    }
}

void ARM_setgoalpos(void) {
    D3DXVec3Subtract(&hook_goal, &PLAYER_getgoalpos(), &hook.vecPosition);
}

D3DXVECTOR3 ARM_getpos(void) {
    return hook.vecPosition;
}