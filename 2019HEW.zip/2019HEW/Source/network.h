/*==============================================================================
    DirectX9_HEW_ROC
    [network.h]
    �E�l�b�g���[�N
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2020_01_16
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include "building.h"

void NETWORK_initialize(void);
void NETWORK_finalize(void);

void NETWORK_sendsignal(void);
void NETWORK_send(BUILDING building, SELECTSQUARE* square);
void NETWORK_receive(void);
void NETWORK_last(void);