/*==============================================================================
    DirectX9_HEW_ROC
    [entry.h]
    �E���O�o�^�V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once



void ENTRY_initialize(void);
void ENTRY_finalize(void);
void ENTRY_update(void);
void ENTRY_draw(void);

void ENTRY_begin(void);
void ENTRY_run(void);
void ENTRY_end(void);