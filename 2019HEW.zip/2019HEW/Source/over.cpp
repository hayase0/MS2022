/*==============================================================================
    DirectX9_HEW_ROC
    [over.cpp]
    �E�T���L���[�t�H�[�v���C���O
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"

#include "scene.h"
#include "phase.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

/*============================================================================*/
void OVER_initialize(void) {
    PHASE_set(PHASE_BEGIN);

}
void OVER_finalize(void) {

}
void OVER_update(void) {
    PHASE_function(SCENE_get());
}
void OVER_draw(void) {
    SPRITE_draw(TEST_08);

}
/*============================================================================*/
void OVER_begin(void) {
    // if (!TRANSITION_check()) PHASE_set(RUN);
    PHASE_set(PHASE_RUN);
}
void OVER_run(void) {
    if (KEYBOARD_trigger(DIK_1)) {
        PHASE_set(PHASE_END);
    }
}
void OVER_end(void) {
    // if (!TRANSITION_check()) SCENE_change(TITLE);
    SCENE_change(SCENE_START);
}