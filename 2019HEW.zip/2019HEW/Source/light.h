#pragma once

#include "main.h"

void LIGHT_initialize(void);
void LIGHT_finalize(void);
void LIGHT_update(void);
