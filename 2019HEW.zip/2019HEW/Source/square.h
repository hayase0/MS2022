/*==============================================================================
    DirectX9_HEW_ROC
    [square.h]
    �E�}�X
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_23_80310) / 2019_12_16
================================================================================
    �X�V����

/*============================================================================*/

#pragma once

//#include <d3dx9.h>
// 
#include "build_data.h"

void SQUARE_initialize(void);
void SQUARE_finalize(void);
void SQUARE_update(void);
void SQUARE_draw(void);
SQUARE* SQUARE_get(void);
SELECTSQUARE* SQUARE_getSelectSquare(void);
SQUAREVECTOR2* SQUARE_getpos(void);