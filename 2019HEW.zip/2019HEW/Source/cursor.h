/*==============================================================================
    DirectX9_HEW_ROC
    [cursor.h]
    �E���O���͉�ʂ̃J�[�\��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2020_01_20-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include "character.h"

// �J�[�\���X�e�[�g
enum CURSOR_STATE {
    CURSOR_STATE_NEUTRAL,
    CURSOR_STATE_UP,
    CURSOR_STATE_DOWN,
    CURSOR_STATE_LEFT,
    CURSOR_STATE_RIGHT,
    CURSOR_STATE_DECIDE,

    CURSOR_STATE_MAX
};

struct CURSOR {
    D3DXVECTOR2 pos;
    D3DXVECTOR2 rot;
    D3DXVECTOR2 scale;
    D3DCOLOR    color;
    float speed;        // �J�[�\���̈ړ����x
    STRING_NUM word;    // �I������Ă镶�����W
};

void CURSOR_initialize(void);
void CURSOR_finalize(void);
void CURSOR_update(void);
void CURSOR_draw(void);
