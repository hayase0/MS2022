/*==============================================================================
    DirectX9_HEW_ROC
    [building.cpp]
    �E����
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_23_80310) / 2019_12_17
================================================================================
    �X�V����

/*============================================================================*/

#include "main.h"
#include "building.h"
#include "square.h"
#include "item.h"
#include "keyboard.h"
#include "phase.h"
#include "sprite.h"
#include "network.h"

#define SELECTBUILDING_ALPHA    (0.5f)                          // �I�𒆂̌����̓����x

struct SELECTBUILDING {
    BUILDING building;  // �I�����Ă��錚��
    int num;        // �I�����Ă���A�C�e���̔ԍ�(�擾�����A�C�e���̔z��̗v�f�ԍ�)
};

static BUILDING Building[BUILDING_NUM_MAX]; // �z�u�ς̌���
static SELECTBUILDING SelectBuilding;       // �I�𒆂̌���

void BUILDING_initialize(void) {
    // �}�b�v��̌����̏��
    BUILD_DATA_send(Building);

    // �I�𒆂̌����̏��̏�����
    SelectBuilding.num = 0;
    SelectBuilding.building.object.vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    {
        if (ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].buildingFormPattern == BUILDING_FORM_PATTERN_SQUARE) {
            SelectBuilding.building.object.vecPosition = D3DXVECTOR3((SQUARE_getpos()->x - 0.5f) * SQUARE_WIDTH
                                                                     , 0.0f,
                                                                     (SQUARE_getpos()->z + 0.5f) * SQUARE_WIDTH);
        }
        else {
            float posX = -ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].localPosition.x;
            float posZ = -ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].localPosition.z;
            float sinY = sinf(-SelectBuilding.building.object.vecRotation.y);
            float cosY = cosf(-SelectBuilding.building.object.vecRotation.y);
            SelectBuilding.building.object.vecPosition = D3DXVECTOR3(SQUARE_getpos()->x * SQUARE_WIDTH + (cosY * posX - sinY * posZ)
                                                                     , 0.0f,
                                                                     SQUARE_getpos()->z * SQUARE_WIDTH + (sinY * posX + cosY * posZ));
        }
    }
    SelectBuilding.building.object.meshIndex = ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].meshIndex;
    SelectBuilding.building.object.vecScale = ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].scale;
}

void BUILDING_update(void) {
    ITEM_INDEX* acquiredItem = ITEM_getAcquiredItem();
    ITEM_DATA* itemData = ITEM_getItemData();

    if (KEYBOARD_trigger(DIK_UP))   // �����ύX(��)
        for (int i = 1; i < ACQUIREDITEM_NUM_MAX; i++)
            if (SelectBuilding.num - i < 0)break;
            else if (acquiredItem[SelectBuilding.num - i] != ITEM_INDEX_NONE) {
                SelectBuilding.num -= i;
                SelectBuilding.building.object.meshIndex = itemData[acquiredItem[SelectBuilding.num]].meshIndex;
                SelectBuilding.building.object.vecScale = itemData[acquiredItem[SelectBuilding.num]].scale;
                break;
            }

    if (KEYBOARD_trigger(DIK_DOWN)) // �����ύX(��)
        for (int i = 1; i < ACQUIREDITEM_NUM_MAX; i++)
            if (SelectBuilding.num + i > ACQUIREDITEM_NUM_MAX)break;
            else if (acquiredItem[SelectBuilding.num + i] != ITEM_INDEX_NONE) {
                SelectBuilding.num += i;
                SelectBuilding.building.object.meshIndex = itemData[acquiredItem[SelectBuilding.num]].meshIndex;
                SelectBuilding.building.object.vecScale = itemData[acquiredItem[SelectBuilding.num]].scale;
                break;
            }

    if (KEYBOARD_trigger(DIK_R))    // ������]
        if (SelectBuilding.building.object.vecRotation.y == D3DX_PI)SelectBuilding.building.object.vecRotation.y = D3DX_PI * 0.5;
        else if (SelectBuilding.building.object.vecRotation.y == D3DX_PI * 0.5f)SelectBuilding.building.object.vecRotation.y = 0.0f;
        else if (SelectBuilding.building.object.vecRotation.y == 0.0f)SelectBuilding.building.object.vecRotation.y = -D3DX_PI * 0.5f;
        else if (SelectBuilding.building.object.vecRotation.y == -D3DX_PI * 0.5f)SelectBuilding.building.object.vecRotation.y = D3DX_PI;

    if (KEYBOARD_trigger(DIK_RETURN)) { // �z�u
        SQUARE* square = SQUARE_get();
        SQUAREVECTOR2* selectpos = SQUARE_getpos();
        SELECTSQUARE* selectSquare = SQUARE_getSelectSquare();
        if ((selectSquare[0].use == false || square[selectSquare[0].pos.z * SQUARE_NUM_X + selectSquare[0].pos.x].available) &&
            (selectSquare[1].use == false || square[selectSquare[1].pos.z * SQUARE_NUM_X + selectSquare[1].pos.x].available) &&
            (selectSquare[2].use == false || square[selectSquare[2].pos.z * SQUARE_NUM_X + selectSquare[2].pos.x].available) &&
            (selectSquare[3].use == false || square[selectSquare[3].pos.z * SQUARE_NUM_X + selectSquare[3].pos.x].available)) {
            if (BUILD_DATA_receive(SelectBuilding.building, selectSquare)) {
                BUILD_DATA_send(square, Building);
                acquiredItem[SelectBuilding.num] = ITEM_INDEX_NONE; // �g�p�����A�C�e�����擾�����A�C�e������폜����
                {   // �c���Ă���A�C�e���̊m�F
                    int count = 0;
                    for (int i = 0; i < ACQUIREDITEM_NUM_MAX; i++)
                        if (acquiredItem[i] != ITEM_INDEX_NONE) {
                            if (count == 0) { // �c���Ă���A�C�e����1�Ԗڂ�I��
                                SelectBuilding.num = i;
                                SelectBuilding.building.object.meshIndex = itemData[acquiredItem[SelectBuilding.num]].meshIndex;
                                SelectBuilding.building.object.vecScale = itemData[acquiredItem[SelectBuilding.num]].scale;
                            }
                            count++;
                        }
                    if (count == 0) PHASE_set(PHASE_END);  // �A�C�e����S�ď���I��
                    else if (count == 1) NETWORK_last(); // �A�C�e���c��1��
                }
            }
        }
    }

    {
        if (ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].buildingFormPattern == BUILDING_FORM_PATTERN_SQUARE) {
            SelectBuilding.building.object.vecPosition = D3DXVECTOR3((SQUARE_getpos()->x - 0.5f) * SQUARE_WIDTH
                                                                     , 0.0f,
                                                                     (SQUARE_getpos()->z + 0.5f) * SQUARE_WIDTH);
        }
        else {
            float posX = -ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].localPosition.x;
            float posZ = -ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].localPosition.z;
            float sinY = sinf(-SelectBuilding.building.object.vecRotation.y);
            float cosY = cosf(-SelectBuilding.building.object.vecRotation.y);
            SelectBuilding.building.object.vecPosition = D3DXVECTOR3(SQUARE_getpos()->x * SQUARE_WIDTH + (cosY * posX - sinY * posZ)
                                                                     , 0.0f,
                                                                     SQUARE_getpos()->z * SQUARE_WIDTH + (sinY * posX + cosY * posZ));
        }
    }
}

void BUILDING_draw(void) {
    // �z�u�ς̌�����`��
    SQUARE* square = SQUARE_get();
    for (int i = 0; i < BUILDING_NUM_MAX; i++)
        if (Building[i].object.isuse)
            MESH_render(&Building[i].object, Building[i].object.meshIndex);

    // �I�𒆂̌�����`��
    MESH_render(&SelectBuilding.building.object, SelectBuilding.building.object.meshIndex, SELECTBUILDING_ALPHA);

    {   // �I�𒆂̌�����UI��`��
        ITEM_INDEX* acquiredItem = ITEM_getAcquiredItem();
        ITEM_DATA* itemData = ITEM_getItemData();
        int count = 0;
        for (int i = 0; i < ACQUIREDITEM_NUM_MAX; i++)
            if (acquiredItem[i] != ITEM_INDEX_NONE) {
                SPRITE_draw(itemData[acquiredItem[i]].textureIndex,
                            1920 - 100,
                            1080 / 2 + (float)count * 100);
                if (i == SelectBuilding.num)
                    SPRITE_draw(TEXTURE_INDEX_ITEM_FRAME,
                                1920 - 100,
                                1080 / 2 + (float)count * 100);
                count++;
            }
    }
}

BUILDING_FORM_PATTERN BUILDING_getbuildingform(void) {
    return ITEM_getItemData()[ITEM_getAcquiredItem()[SelectBuilding.num]].buildingFormPattern;
}

float BUILDING_getrotationy(void) {
    return SelectBuilding.building.object.vecRotation.y;
}