/*==============================================================================
    DirectX9_HEW_ROC
    [target.cpp]
    �E�^�[�Q�b�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA THS_AT12C342_36_80299) / 2020_01_19-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "direct3d.h"
 
#include "player.h"
#include "player_action.h"
#include "stage_f.h"
#include "target.h"

#include "debugproc.h"

static OBJECT Target[MAX_TARGET];
static OBJECT Target_frame[MAX_TARGET];
TARGET_VERTEX Target_vertex[MAX_TARGET];


static int Target_num = 0;

/*============================================================================*/

static void set_target(void) {

    STAGE_POS *stage_pos = STAGE_F_get_stage_pos();

    for (int i = 0; i < MAX_TARGET; i++) {
        Target[i].isuse = false;
        Target[i].meshIndex = MESH_INDEX_STAGE_002;
        Target[i].vecPosition = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target[i].vecScale = D3DXVECTOR3(5.0f, 5.0f, 5.0f);
    }
    
    // �e�X�g�p
    Target[Target_num].vecPosition = D3DXVECTOR3(0.0f, 100.0f, 0.0f);
    Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    Target_num++;
    ///////////

    /*----------------------------------------------------------------------------*/
    /* �e���v��
    {
        int x, y, z;
        x = y = z = 0;

        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

    }
    */
    /*----------------------------------------------------------------------------*/


    {   // sekiro
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_000].x;
        y = stage_pos[STAGE_LUMP_000].y;
        z = stage_pos[STAGE_LUMP_000].z;

        y += 150;

        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 1500.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        Target[Target_num].vecPosition = D3DXVECTOR3(-500.0f + x, 0.0f + y, 2500.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        Target[Target_num].vecPosition = D3DXVECTOR3(500.0f + x, 0.0f + y, 2500.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 3500.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;
    }


    {   // �c���ꍆ
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_001].x;
        y = stage_pos[STAGE_LUMP_001].y;
        z = stage_pos[STAGE_LUMP_001].z;

        // ��K
        Target[Target_num].vecPosition = D3DXVECTOR3(-200.0f + x, 350.0f + y, 500.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        Target[Target_num].vecPosition = D3DXVECTOR3(200.0f + x, 350.0f + y, 500.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        // 
        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 700.0f + y, 900.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        // 
        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 1050.0f + y, 300.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 1300.0f + y, 1000.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;

        Target[Target_num].vecPosition = D3DXVECTOR3(0.0f + x, 1300.0f + y, 2000.0f + z);
        Target[Target_num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_num++;
    }



    /*----------------------------------------------------------------------------*/
    for (int i = 0; i < Target_num; i++) Target[i].isuse = true;
}


static void target_frame(void) {
    for (int i = 0; i < Target_num; i++) {
        Target_frame[i].isuse = false;
        Target_frame[i].meshIndex = MESH_INDEX_STAGE_001;
        Target_frame[i].vecPosition = Target[i].vecPosition;
        Target_frame[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Target_frame[i].vecScale = D3DXVECTOR3(10.0f, 10.0f, 10.0f);
    }    

    int target_rockon_num = PLAYER_ACTION_GET_TARGET_NUM();
}
/*============================================================================*/

void TARGET_initialize(void) {
    set_target();
    target_frame();

    

}
void TARGET_finalize(void) {

}
void TARGET_update(void) {
    if (PLAYER_lockon()) {
        int target_num = PLAYER_ACTION_GET_TARGET_NUM();
        static bool scale = false;

        Target_frame[target_num].vecRotation += D3DXVECTOR3(0.1f, 0.1f, 0.1f);
        if (Target_frame[target_num].vecScale.x <= 7.5f && !scale) {
            scale = true;
        }
        if (Target_frame[target_num].vecScale.x >= 12.5f && scale) {
            scale = false;
        }
        if(scale) Target_frame[target_num].vecScale += D3DXVECTOR3(0.125f, 0.125f, 0.125f);
        else Target_frame[target_num].vecScale -= D3DXVECTOR3(0.125f, 0.125f, 0.125f);
    }
}

void TARGET_draw(void) {
    //LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    for (int i = 0; i < Target_num; i++) {
        // �{��
        MESH_render(&Target[i], Target[i].meshIndex);
        MESH_render(&Target_frame[i], Target_frame[i].meshIndex);
    }

#ifdef DEBUG
    if (PLAYER_lockon()) {
        static OBJECT target;
        target.vecPosition = PLAYER_ACTION_gettargetpos();
        target.vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        target.vecScale = D3DXVECTOR3(30.0f, 30.0f, 30.0f);
        DebugProc_Print("�^�[�Q�b�g�ʒu:X:%f5/Y:%f5/Z:%f5\n", target.vecPosition.x, target.vecPosition.y, target.vecPosition.z);
        MESH_render(&target, MESH_INDEX_TOMATO);
    }
#endif
}

OBJECT *TARGET_get(void) {
    return Target;
}