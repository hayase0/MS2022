/*==============================================================================
    DirectX9_HEW_ROC
    [phase.cpp]
    �E�t�F�C�Y�Ǘ�
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_19-
================================================================================
    �X�V����
        19_11_09 FU �v���g�^�C�v�p����}�X�^�p�ɕύX���܂����B

/*============================================================================*/
#include "main.h"
#include "phase.h"

/*============================================================================*/
static PHASE Phase = PHASE_BEGIN;

// �֐��|�C���^�񎟌��z��
void(*phase_function[SCENE_MAX][PHASE_MAX])(void) = {
    {START_begin,START_run,START_end},
    {TITLE_begin,TITLE_run,TITLE_end},
    {DEMO_begin,DEMO_run,DEMO_end},
    {TUTORIAL_begin,TUTORIAL_run,TUTORIAL_end},
    {EXPLORE_begin,EXPLORE_run,EXPLORE_end},
    {ENTRY_begin,ENTRY_run,ENTRY_end},
    {BUILD_begin,BUILD_run,BUILD_end},
    {OVER_begin,OVER_run,OVER_end},
};

/*============================================================================*/
void PHASE_function(SCENE scene) {
    phase_function[scene][Phase]();
}

void PHASE_set(PHASE phase) { Phase = phase; }
