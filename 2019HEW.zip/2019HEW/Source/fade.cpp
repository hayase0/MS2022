/*==============================================================================
    DirectX9_HEW_ROC
    [fade.cpp]
    �E�t�F�[�h
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_28-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"
#include "direct3d.h"

#include "transition.h"

#include "fade.h"



static float Fade_alpha;                                // �A���t�@�l
static D3DXCOLOR Fade_color(0.0f, 0.0f, 0.0f, 1.0f);    // �J���[

/*============================================================================*/
// �t�F�[�h�C��
void FADE_in(void) {
    if (Fade_alpha >= 0.0f) {
        Fade_alpha -= 1.0f / TRANSITION_get_time();
    }
    else {
        Fade_alpha = 0.0f;
        TRANSITION_set(TRANSITION_NONE);
    }
}
// �t�F�[�h�A�E�g
void FADE_out(void) {
    if (Fade_alpha <= 1.0f) {
        Fade_alpha += 1.0f / TRANSITION_get_time();
    }
    else {
        Fade_alpha = 1.0f;
        TRANSITION_set(TRANSITION_NONE);
    }
}
/*============================================================================*/
void FADE_initialize(void) {
    Fade_alpha = 1.0f;
}
void FADE_finalize(void) {

}
void FADE_update(void) {
    
}
void FADE_draw(void) {
    Fade_color.a = Fade_alpha;
    D3DCOLOR c = Fade_color;

    Fade_vertex v[] = {
        { D3DXVECTOR4(0.0f,         0.0f,          0.0f, 1.0f), c },
        { D3DXVECTOR4(WINDOW_WIDTH, 0.0f,          0.0f, 1.0f), c },
        { D3DXVECTOR4(0.0f,         WINDOW_HEIGHT, 0.0f, 1.0f), c },
        { D3DXVECTOR4(WINDOW_WIDTH, WINDOW_HEIGHT, 0.0f, 1.0f), c },
    };

    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    pDevice->SetFVF(FVF_FADE_VERTEX);
    pDevice->SetTexture(0, NULL);
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Fade_vertex));

}