/*==============================================================================
    DirectX9_HEW_ROC
    [texture.h]
    �E�e�N�X�`���[
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_20-
================================================================================
    �X�V����
        2019_11_09  �}�X�^�ł̑J�ڗp�Ƀe�X�g�p�摜�����܂����B

/*============================================================================*/
#pragma once

enum TEXTURE_INDEX {
    TEXTURE_INDEX_ITEM_FRAME,
    TEXTURE_INDEX_ITEM_BUILDING1,
    TEXTURE_INDEX_ITEM_MONKEY,
    TEXTURE_INDEX_ITEM_COCOONTOWER,
    TEXTURE_INDEX_ITEM_BIGSIGHT,
    TEXTURE_INDEX_ITEM_GOVERNMENTOFFICE,
    TEXTURE_INDEX_ITEM_NATIONALSTADIUM,

    TEXTURE_INDEX_CHARACTER,
    TEST_SQUARE_FRAME,
    TEST_GROUND_AVAILABLE,
    TEST_GROUND_UNAVAILABLE,

    TEST_01,
    TEST_02,
    TEST_03,
    TEST_04,
    TEST_05,
    TEST_06,
    TEST_07,
    TEST_08,

    TEST_ARISE,
    TEST_FALL,
    TEST_COMPLETE,
    TEST_NAVIGATOR,
    TEST_MAP,
    TEST_PAUSE,
    TEST_MOVING_OBJECT,

    TEST_BACKGROUND,
    TEST_BACKGROUND_SIDE,
    TEST_BACKGROUND_DOWN,
    TEST_BACKGROUND_UP,

    TEXTURE_INDEX_GAUGE_EMPTY,
    TEXTURE_INDEX_GAUGE_FULL,

    TEST_FLOATMATTER,
    TEST_GUIDE,

    TEXTURE_INDEX_SHADOW,

    CUBE_TEXTURE_001,
    CUBE_TEXTURE_002,
    CUBE_TEXTURE_003,

    TEXTURE_INDEX_CURSOR,

    TEXTURE_INDEX_MAX
};

int TEXTURE_load(void);
void TEXTURE_release(void);
LPDIRECT3DTEXTURE9 TEXTURE_get_texture(TEXTURE_INDEX);
int TEXTURE_get_width(TEXTURE_INDEX);
int TEXTURE_get_height(TEXTURE_INDEX);
