/*==============================================================================
    DirectX9_HEW_ROC
    [start.h]
    �E�N���V�[���B���S��\������B
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

void TITLE_initialize(void);
void TITLE_finalize(void);
void TITLE_update(void);
void TITLE_draw(void);

void TITLE_begin(void);
void TITLE_run(void);
void TITLE_end(void);
