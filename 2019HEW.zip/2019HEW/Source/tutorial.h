/*==============================================================================
    DirectX9_HEW_ROC
    [turorial.h]
    �E�`���[�g���A���V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once



void TUTORIAL_initialize(void);
void TUTORIAL_finalize(void);
void TUTORIAL_update(void);
void TUTORIAL_draw(void);

void TUTORIAL_begin(void);
void TUTORIAL_run(void);
void TUTORIAL_end(void);
