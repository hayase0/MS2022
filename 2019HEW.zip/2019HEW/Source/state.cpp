/*==============================================================================
    DirectX9_HEW_ROC
    [state.cpp]
    �E�X�e�[�g�Ǘ�
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����
        19_11_11 FU �X�e�[�g�������������₵�܂����B

/*============================================================================*/
#include "scene.h"
#include "phase.h"
#include "state.h"

#include "keyboard.h"

#include "player.h"
#include "ARM.h"
#include "chain.h"
#include "target.h"
#include "camera.h"
#include "floatmatter.h"
#include "player_action.h"

/*============================================================================*/
static STATE State = STATE_NORMAL;

/*============================================================================*/
static void nomal_update(void) {
     // player.cpp�o�����火�̏����Ď�������
     PLAYER_update();
     ARM_update();
     CHAIN_update();
     CAMERA_update();
     FLOATMATTER_update();
     TARGET_update();
        
    if (KEYBOARD_trigger(DIK_1)) {
        PHASE_set(PHASE_END);
    }
    if (KEYBOARD_trigger(DIK_2)) {
        STATE_set(STATE_NAVIGATOR);
    }
    if (KEYBOARD_trigger(DIK_3)) {
        STATE_set(STATE_PAUSE);
    }
    if (KEYBOARD_trigger(DIK_4)) {
        STATE_set(STATE_ATLAS);
    }
    //if (KEYBOARD_trigger(DIK_5)) {
    //    STATE_set(STATE_FALL);
    //}
    if (KEYBOARD_trigger(DIK_6)) {
        STATE_set(STATE_ARISE);
    }

    if (FALL_border()) {
        STATE_set(STATE_FALL);
    }
}
static void arise_update(void) {
    ARISE_update();
}
static void fall_update(void) {
    FALL_update();
}
static void complete_update(void) {
    COMPLETE_update();
}
static void navigator_update(void) {
    NAVIGATOR_update();
}
static void atlas_update(void) {
    ATLAS_update();
}
static void pause_update(void) {
    PAUSE_update();
}

/*----------------------------------------------------------------------------*/
static void nomal_draw(void) {
}
static void arise_draw(void) {
    ARISE_draw();
}
static void fall_draw(void) {
    FALL_draw();
}
static void complete_draw(void) {
    COMPLETE_draw();
}
static void navigator_draw(void) {
    NAVIGATOR_draw();
}
static void atlas_draw(void) {
    ATLAS_draw();
}
static void pause_draw(void) {
    PAUSE_draw();
}

/*----------------------------------------------------------------------------*/
// �V�[���֐��|�C���^�f�[�^�^����
typedef void(*state_function)(void);

// �֐��z��
static const state_function update[] = {
    nomal_update,
    arise_update,
    fall_update,
    complete_update,
    navigator_update,
    atlas_update,
    pause_update,
};
static const state_function draw[] = {
    nomal_draw,
    arise_draw,
    fall_draw,
    complete_draw,
    navigator_draw,
    atlas_draw,
    pause_draw,
};

/*============================================================================*/
// ���݂�State�̊֐����Ăяo���֐�
void STATE_update(void) { update[State](); }
void STATE_draw(void) { draw[State](); }

// setter
void STATE_set(STATE state) { State = state; }
