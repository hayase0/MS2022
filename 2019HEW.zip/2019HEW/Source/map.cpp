/*==============================================================================
    DirectX9_HEW_ROC
    [map.cpp]
    �E�}�b�v
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "texture.h"
#include "sprite.h"

void MAP_initialize(void) {

}

void MAP_finalize(void) {

}

void MAP_update(void) {

}

void MAP_draw(void) {
    SPRITE_draw(TEST_MAP);
}
