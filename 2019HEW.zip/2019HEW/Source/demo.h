/*==============================================================================
    DirectX9_HEW_ROC
    [demo.h]
    �E�f���V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once



void DEMO_initialize(void);
void DEMO_finalize(void);
void DEMO_update(void);
void DEMO_draw(void);

void DEMO_begin(void);
void DEMO_run(void);
void DEMO_end(void);