/*==============================================================================
    DirectX9_HEW_ROC
    [build_data.cpp]
    �E���z���
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_23_80310) / 2020_1_15
==============================================================================*/
#define _CRT_SECURE_NO_WARNINGS
#include "main.h"
 
#include "build_data.h"
#include "network.h"

static SQUARE Square[SQUARE_NUM_Z][SQUARE_NUM_X];       // �}�X
static BUILDING Building[BUILDING_NUM_MAX];             // �z�u�ς̌���

static void SQUARE_available(SQUAREVECTOR2);

void BUILD_DATA_initialize(void) {
    // �}�X
    for (int z = 0; z < SQUARE_NUM_Z; z++)
        for (int x = 0; x < SQUARE_NUM_X; x++) {
            Square[z][x].available = false;
            Square[z][x].building = false;
        }
    SQUARE_available(START_SQUARE_POS);
    // ����
    for (int i = 0; i < BUILDING_NUM_MAX; i++) {
        Building[i].object.isuse = false;
        Building[i].object.vecPosition = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Building[i].object.vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Building[i].object.vecScale = D3DXVECTOR3(1.0f, 1.0f, 1.0f);
        Building[i].object.meshIndex = MESH_INDEX_NONE;
    }
    // �l�b�g���[�N
    NETWORK_sendsignal();
    NETWORK_receive();
}

void BUILD_DATA_send(SQUARE* square, BUILDING* building) {
    { // �}�X
        int i = 0;
        for (int z = 0; z < SQUARE_NUM_Z; z++)
            for (int x = 0; x < SQUARE_NUM_X; x++) {
                square[i] = Square[z][x];
                i++;
            }
    }
    // ����
    for (int i = 0; i < BUILDING_NUM_MAX; i++) building[i] = Building[i];
}

void BUILD_DATA_send(SQUARE* square) {
    { // �}�X
        int i = 0;
        for (int z = 0; z < SQUARE_NUM_Z; z++)
            for (int x = 0; x < SQUARE_NUM_X; x++) {
                square[i] = Square[z][x];
                i++;
            }
    }
}

void BUILD_DATA_send(BUILDING* building) {
    // ����
    for (int i = 0; i < BUILDING_NUM_MAX; i++) building[i] = Building[i];
}

bool BUILD_DATA_receive(BUILDING building, SELECTSQUARE* selectsquare) {
    // ����
    if ((selectsquare[0].use == false || Square[selectsquare[0].pos.z][selectsquare[0].pos.x].available) &&
        (selectsquare[1].use == false || Square[selectsquare[1].pos.z][selectsquare[1].pos.x].available) &&
        (selectsquare[2].use == false || Square[selectsquare[2].pos.z][selectsquare[2].pos.x].available) &&
        (selectsquare[3].use == false || Square[selectsquare[3].pos.z][selectsquare[3].pos.x].available)) {
        // �z�u���錚���̃f�[�^��ݒ�
        for (int i = 0; i < BUILDING_NUM_MAX; i++)
            if (!Building[i].object.isuse) {
                Building[i] = building;
                //Building[i].object.vecPosition = building.object.vecPosition;
                //Building[i].object.vecRotation = building.object.vecRotation;
                //Building[i].object.vecScale = building.object.vecScale;
                //Building[i].object.meshIndex = building.object.meshIndex;
                //Building[i].buildersName = building.buildersName;
                Building[i].object.isuse = true;
                NETWORK_send(Building[i], selectsquare);
                break;
            }
        for (int i = 0; i < 4; i++)
            if (selectsquare[i].use) {
                SQUARE_available(selectsquare[i].pos);                                  // ���p�\�ȃ}�X�𑝂₷
                Square[selectsquare[i].pos.z][selectsquare[i].pos.x].available = false;   // ���݂����}�X�𗘗p�s�ɂ���
                Square[selectsquare[i].pos.z][selectsquare[i].pos.x].building = true;
            }
        return true;
    }
    return false;
}

BUILDING* BUILD_DATA_get_building(void) {
    return Building;
}

SQUARE* BUILD_DATA_get_square(void) {
    return *Square;
}

void SQUARE_set(int x, int z) {
    Square[z][x].available = false;
    Square[z][x].building = true;
    SQUAREVECTOR2 vec;
    vec.x = x; vec.z = z;
    SQUARE_available(vec);
}

static void SQUARE_available(SQUAREVECTOR2 vec) {
    // vec�𒆐S��AVAILABLE_RANGE�}�X�ȓ��̃}�X�𗘗p�\�ɂ���
    for (int z = 0; z < SQUARE_NUM_Z; z++)
        for (int x = 0; x < SQUARE_NUM_X; x++)
            if (!Square[z][x].available)
                if (!Square[z][x].building)
                    if (x >= vec.x - AVAILABLE_RANGE &&
                        x <= vec.x + AVAILABLE_RANGE &&
                        z >= vec.z - AVAILABLE_RANGE &&
                        z <= vec.z + AVAILABLE_RANGE)
                        Square[z][x].available = true;
}