/*==============================================================================
    DirectX9_HEW_ROC
    [turorial.cpp]
    �E�`���[�g���A���V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"

#include "scene.h"
#include "phase.h"
#include "state.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

#include "floatmatter.h"
#include "map.h"

/*============================================================================*/
void TUTORIAL_initialize(void) {
    PHASE_set(PHASE_BEGIN);
}
void TUTORIAL_finalize(void) {
    STATE_set(STATE_NORMAL);
}
void TUTORIAL_update(void) {
    PHASE_function(SCENE_get());
}
void TUTORIAL_draw(void) {
    SPRITE_draw(TEST_04);
    //STATE_draw();
}

/*============================================================================*/
void TUTORIAL_begin(void) {
    // if (!TRANSITION_check()) PHASE_set(RUN);
    PHASE_set(PHASE_RUN);
}
void TUTORIAL_run(void) {
    // STATE_update();
    if (KEYBOARD_trigger(DIK_1)) {
        PHASE_set(PHASE_END);
    }
}
void TUTORIAL_end(void) {
    // if (!TRANSITION_check()) SCENE_change(TITLE);
    SCENE_change(SCENE_EXPLORE);
}
