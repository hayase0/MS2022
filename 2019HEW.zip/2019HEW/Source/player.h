/*==============================================================================
    DirectX9_HEW_ROC
    [player.h]
    �E�v���C���[
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_10_23-2019_10_
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include <d3dx9.h>
#include "animation.h"
#include "mesh.h"

void PLAYER_initialize(void);
void PLAYER_update(void);
void PLAYER_draw(void);
ANIMATION_OBJECT* PLAYER_animget(void);
DYNAMIC_OBJECT* PLAYER_get(void);
D3DXVECTOR3 PLAYER_getpos(void);
D3DXVECTOR3* PLAYER_getrot(void);
D3DXVECTOR3 PLAYER_getscl(void);
D3DXVECTOR3 PLAYER_getgoalpos(void);
bool PLAYER_lockon(void);
float PLAYER_gethovergauge(void);
bool PLAYER_moveflag(void);
bool PLAYER_getfpaimflag(void);
void PLAYER_resetmove(void);