/*==============================================================================
    DirectX9_HEW_ROC
    [explore.h]
    �E�T���V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

void EXPLORE_initialize(void);
void EXPLORE_finalize(void);
void EXPLORE_update(void);
void EXPLORE_draw(void);

void EXPLORE_begin(void);
void EXPLORE_run(void);
void EXPLORE_end(void);