/*==============================================================================
    DirectX9_HEW_ROC
    [entry.cpp]
    �E���O�o�^�V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"

#include "scene.h"
#include "phase.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"
#include "gamepad.h"

#include "transition.h"
#include "character.h"

#include "name_input.h"
#include "cursor.h"


/*============================================================================*/
void ENTRY_initialize(void) {
    PHASE_set(PHASE_BEGIN);

    TRANSITION_set(FADE_IN, 60);


    NAME_INPUT_initialize();

}
void ENTRY_finalize(void) {

}
void ENTRY_update(void) {
    PHASE_function(SCENE_get());
}
void ENTRY_draw(void) {
    //SPRITE_draw(TEST_06);
    NAME_INPUT_draw();

}

/*============================================================================*/
void ENTRY_begin(void) {
    if (!TRANSITION_check()) PHASE_set(PHASE_RUN);
}
void ENTRY_run(void) {
    if (KEYBOARD_trigger(DIK_1)) {
        TRANSITION_set(FADE_OUT, 60);
        PHASE_set(PHASE_END);
    }
    NAME_INPUT_update();
}
void ENTRY_end(void) {
    if (!TRANSITION_check()) SCENE_change(SCENE_EXPLORE);
}
