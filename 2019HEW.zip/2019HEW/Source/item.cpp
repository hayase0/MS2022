/*==============================================================================
    DirectX9_HEW_ROC
    [item.cpp]
    �E�A�C�e��
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_23_80310) / 2019_12_18
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "item.h"
#include "collision_box.h"
#include "square.h"
#include "texture.h"

#include "stage_f.h"

static ITEM_OBJECT Item[ITEM_INDEX_MAX];

static const ITEM_DATA ItemData[ITEM_INDEX_MAX] = {
    {},
    {"�r��", MESH_INDEX_BUILDING, BUILDING_FORM_PATTERN_POINT, D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(4.0f, 4.0f, 4.0f), TEXTURE_INDEX_ITEM_BUILDING1},
    {"��", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_SERIES2, D3DXVECTOR3(SQUARE_WIDTH * 0.5f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
    {"�R�N�[���^���[", MESH_INDEX_COCOONTOWER, BUILDING_FORM_PATTERN_POINT, D3DXVECTOR3(SQUARE_WIDTH * 0.0f, 0.0f, 0.0f), D3DXVECTOR3(15.0f, 15.0f, 15.0f), TEXTURE_INDEX_ITEM_COCOONTOWER},
    {"�r�b�O�T�C�g", MESH_INDEX_BIGSIGHT, BUILDING_FORM_PATTERN_SQUARE, D3DXVECTOR3(SQUARE_WIDTH * 0.0f, 0.0f, 0.0f), D3DXVECTOR3(5.0f, 5.0f, 5.0f), TEXTURE_INDEX_ITEM_BIGSIGHT},
    {"�s��", MESH_INDEX_GOVERNMENTOFFICE, BUILDING_FORM_PATTERN_SERIES2, D3DXVECTOR3(SQUARE_WIDTH * 0.5f, 0.0f, 0.0f), D3DXVECTOR3(3.0f, 3.0f, 3.0f), TEXTURE_INDEX_ITEM_GOVERNMENTOFFICE},
    {"POINT", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_POINT, D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
    {"SERIES2", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_SERIES2, D3DXVECTOR3(SQUARE_WIDTH * 0.5f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
    {"SERIES3", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_SERIES3, D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
    {"SERIES4", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_SERIES4, D3DXVECTOR3(SQUARE_WIDTH * 0.5f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
    {"KEYBRACKETS", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_KEYBRACKETS, D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
    {"SQUARE", MESH_INDEX_PLAYER, BUILDING_FORM_PATTERN_SQUARE, D3DXVECTOR3(0.0f, 0.0f, 0.0f), D3DXVECTOR3(50.0f, 50.0f, 50.0f), TEXTURE_INDEX_ITEM_MONKEY},
};

static ITEM_INDEX AcquiredItem[ACQUIREDITEM_NUM_MAX];  // �擾�����A�C�e��




static void item_set(void) {
    int num = 0;

    STAGE_POS *stage_pos = STAGE_F_get_stage_pos();

    for (int i = 0; i < ITEM_INDEX_MAX; i++) Item[i].object.isuse = false;

    /* �e���v��
    {
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_000].x;
        y = stage_pos[STAGE_LUMP_000].y;
        z = stage_pos[STAGE_LUMP_000].z;

        Item[num].object.meshIndex = MESH_INDEX_ITEM_000;
        Item[num].object.vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Item[num].object.vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Item[num].object.vecScale = D3DXVECTOR3(10.0f, 10.0f, 10.0f);
        Item[num].Item = ITEM_INDEX_BUILDING1;
        num++;
    }
    
    */

    {
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_000].x;
        y = stage_pos[STAGE_LUMP_000].y;
        z = stage_pos[STAGE_LUMP_000].z;

        Item[num].object.meshIndex = MESH_INDEX_ITEM_000;
        Item[num].object.vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Item[num].object.vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Item[num].object.vecScale = D3DXVECTOR3(10.0f, 10.0f, 10.0f);
        Item[num].Item = ITEM_INDEX_BUILDING1;
        num++;
    }

    for (int i = 0; i < num; i++) {
        Item[i].object.isuse = true;
        COLLISION_BOX_setting(&Item[i].object);
    }

}

/*============================================================================*/

void ITEM_initialize(void) {
    // �擾�����A�C�e���̏�����
    for (int i = 0; i < ACQUIREDITEM_NUM_MAX; i++) AcquiredItem[i] = ITEM_INDEX_NONE;

    // �e�X�g
    for (int i = 0; i < ACQUIREDITEM_NUM_MAX; i++) AcquiredItem[i] = ITEM_INDEX_COCOONTOWER;
    for (int i = 0; i < 5; i++) AcquiredItem[i] = ITEM_INDEX_BIGSIGHT;


    item_set();
}

void ITEM_finalize(void) {

}

void ITEM_update(void) {

}

void ITEM_draw(void) {
    for (int i = 0; i < ITEM_INDEX_MAX; i++) {
        if (Item[i].object.isuse) MESH_render(&Item[i].object, Item[i].object.meshIndex);

    }
}

// �A�C�e���擾�֐�(�����Ɏ擾�����A�C�e����ITEM_INDEX������)
void ITEM_acquisition(ITEM_INDEX itemIndex) {
    for (int i = 0; i < ACQUIREDITEM_NUM_MAX; i++)
        if (AcquiredItem[i] == ITEM_INDEX_NONE) {
            AcquiredItem[i] = itemIndex;
            break;
        }
}

ITEM_DATA* ITEM_getItemData(void) {
    return (ITEM_DATA*)ItemData;
}

ITEM_INDEX* ITEM_getAcquiredItem(void) {
    return AcquiredItem;
}

ITEM_OBJECT* ITEM_get_obtained(void) {
    return Item;
}