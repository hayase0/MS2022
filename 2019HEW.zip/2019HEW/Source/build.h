/*==============================================================================
    DirectX9_HEW_ROC
    [build.h]
    �E�����z�u�V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once



void BUILD_initialize(void);
void BUILD_finalize(void);
void BUILD_update(void);
void BUILD_draw(void);

void BUILD_begin(void);
void BUILD_run(void);
void BUILD_end(void);