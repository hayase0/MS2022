/*==============================================================================
    DirectX9_HEW_ROC
    [build.cpp]
    �E�����z�u�V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"
#include "buildcamera.h"

#include "scene.h"
#include "phase.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

#include "build_data.h"
#include "square.h"
#include "background.h"
#include "ground.h"
#include "building.h"

#include "network.h"

/*============================================================================*/
void BUILD_initialize(void) {
    NETWORK_initialize();
    BUILD_DATA_initialize();
    SQUARE_initialize();
    BUILDING_initialize();      // SQUARE_initialize����
    BUILDCAMERA_initialize();   // SQUARE_initialize����
    GROUND_initialize();
    PHASE_set(PHASE_BEGIN);
}
void BUILD_finalize(void) {
    GROUND_finalize();
    SQUARE_finalize();
    NETWORK_finalize();
}
void BUILD_update(void) {
    PHASE_function(SCENE_get());
}
void BUILD_draw(void) {
    BUILDCAMERA_setting();
    GROUND_draw();
    SQUARE_draw();      // GROUND_draw����
    BUILDING_draw();    // �Ō�
}
/*============================================================================*/
void BUILD_begin(void) {
    // if (!TRANSITION_check()) PHASE_set(RUN);
    PHASE_set(PHASE_RUN);
}
void BUILD_run(void) {
    BUILDCAMERA_update();
    SQUARE_update();
    BUILDING_update();
    if (KEYBOARD_trigger(DIK_1)) {
        PHASE_set(PHASE_END);
    }
}
void BUILD_end(void) {
    // if (!TRANSITION_check()) SCENE_change(TITLE);
    SCENE_change(SCENE_OVER);
}