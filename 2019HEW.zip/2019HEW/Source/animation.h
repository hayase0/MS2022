/*==============================================================================
    DirectX9_HEW_ROC
    [animation.h]
    �E�A�j���[�V����
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2020_01_26-2020_01_
================================================================================
    �X�V����

/*============================================================================*/
#pragma once


#include "mesh.h"

enum ANIMOBJ_INDEX {
    ANIMOBJ_INDEX_PLAYER,
    ANIMOBJ_INDEX_PLAYERARM,

    ANIMOBJ_INDEX_MAX

};

enum ANIMATION_INDEX_PLAYER {
    //ANIMATION_INDEX_PLAYER_SHOT1,
    //ANIMATION_INDEX_PLAYER_SHOT2,
    //ANIMATION_INDEX_PLAYER_SHOT3,
    ANIMATION_INDEX_PLAYER_WAIT,
    ANIMATION_INDEX_PLAYER_WAIT1,
    ANIMATION_INDEX_PLAYER_WAIT2,
    ANIMATION_INDEX_PLAYER_WALK,
    ANIMATION_INDEX_PLAYER_RUN,
    ANIMATION_INDEX_PLAYER_JUMP,
    ANIMATION_INDEX_PLAYER_SHOT,
};

enum ANIMATION_INDEX_PLAYERARM {
    //ANIMATION_INDEX_PLAYER_SHOT1,
    //ANIMATION_INDEX_PLAYER_SHOT2,
    //ANIMATION_INDEX_PLAYER_SHOT3,
    ANIMATION_INDEX_PLAYERARM_WAIT,
    ANIMATION_INDEX_PLAYERARM_WAIT1,
    ANIMATION_INDEX_PLAYERARM_WAIT2,
    ANIMATION_INDEX_PLAYERARM_WALK,
    ANIMATION_INDEX_PLAYERARM_RUN,
    ANIMATION_INDEX_PLAYERARM_JUMP,
    ANIMATION_INDEX_PLAYERARM_SHOT,
};

struct ANIMATION_DATA {
    LPD3DXANIMATIONSET pAnimset;
    float animspeed;
    float animtime;
    float endtime;
    float loopstart;
};

// ���̍\����
struct ANIMATION_OBJECT {
    DYNAMIC_OBJECT dynamic_obj;
    LPD3DXFRAME pFrameRoot;
    LPD3DXANIMATIONCONTROLLER pAnimController;
    ANIMOBJ_INDEX animobjidx;
    ANIMATION_DATA animdata[10];
    int animnum;
    int animid;
};

HRESULT ANIMATION_load(ANIMATION_OBJECT* animobj, ANIMOBJ_INDEX animidx);
void RenderThing(ANIMATION_OBJECT* pObject);
void ANIMATION_set(ANIMATION_OBJECT* panim, int id);