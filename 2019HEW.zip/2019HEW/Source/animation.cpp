/*==============================================================================
    DirectX9_HEW_ROC
    [animation.cpp]
    �E�A�j���[�V����
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2020_01_26-2020_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "animation.h"
#include "player_state.h"
#include "direct3d.h"
#include "hierarchy.h"
MY_HIERARCHY g_cHierarchy;


const char filename[ANIMOBJ_INDEX_MAX][64] = {
    {"Asset/3dmodel/Player_object/player.x"},
    {"Asset/3dmodel/Player_object/arm.x"},
};

HRESULT ANIMATION_load(ANIMATION_OBJECT* animobj, ANIMOBJ_INDEX animidx) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    // X�t�@�C������A�j���[�V�������b�V����ǂݍ��ݍ쐬����
    if (FAILED(
        D3DXLoadMeshHierarchyFromX(filename[animidx], D3DXMESH_MANAGED, pDevice, &g_cHierarchy,
                                   NULL, &(animobj->pFrameRoot), &(animobj->pAnimController)))) {
        MessageBox(NULL, "X�t�@�C���̓ǂݍ��݂Ɏ��s���܂���", filename[animidx], MB_OK);
        return E_FAIL;
    }

    animobj->animnum = animobj->pAnimController->GetNumAnimationSets();
    for (int i = 0; i < animobj->animnum; i++) {
        animobj->pAnimController->GetAnimationSet(i, &(animobj->animdata[i].pAnimset));
    }
    return S_OK;
}
//
//VOID RenderMeshContainer(LPD3DXMESHCONTAINER pMeshContainerBase, LPD3DXFRAME pFrameBase)
//�t���[�����̂��ꂼ��̃��b�V���������_�����O����
VOID RenderMeshContainer(LPD3DXMESHCONTAINER pMeshContainerBase, LPD3DXFRAME pFrameBase) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    MYMESHCONTAINER *pMeshContainer = (MYMESHCONTAINER*)pMeshContainerBase;
    MYFRAME *pFrame = (MYFRAME*)pFrameBase;
    UINT iMaterial;

    pDevice->SetTransform(D3DTS_WORLD, &pFrame->CombinedTransformationMatrix);

    pDevice->SetRenderState(D3DRS_NORMALIZENORMALS, TRUE);

    for (iMaterial = 0; iMaterial < pMeshContainer->NumMaterials; iMaterial++) {
        pDevice->SetMaterial(&pMeshContainer->pMaterials[iMaterial].MatD3D);
        pDevice->SetTexture(0, pMeshContainer->ppTextures[iMaterial]);
        pMeshContainer->MeshData.pMesh->DrawSubset(iMaterial);
    }
}
//
//VOID DrawFrame(LPD3DXFRAME pFrame)
//�����̃��b�V�����琬��t���[���������_�����O����B
VOID DrawFrame(LPD3DXFRAME pFrame) {

    LPD3DXMESHCONTAINER pMeshContainer;

    pMeshContainer = pFrame->pMeshContainer;
    while (pMeshContainer != NULL) {
        RenderMeshContainer(pMeshContainer, pFrame);

        pMeshContainer = pMeshContainer->pNextMeshContainer;
    }

    if (pFrame->pFrameSibling != NULL) {
        DrawFrame(pFrame->pFrameSibling);
    }

    if (pFrame->pFrameFirstChild != NULL) {
        DrawFrame(pFrame->pFrameFirstChild);
    }
}
//
//VOID UpdateFrameMatrices(LPD3DXFRAME pFrameBase, LPD3DXMATRIX pParentMatrix)
//�t���[�����̃��b�V�����Ƀ��[���h�ϊ��s����X�V����
VOID UpdateFrameMatrices(LPD3DXFRAME pFrameBase, LPD3DXMATRIX pParentMatrix) {
    MYFRAME *pFrame = (MYFRAME*)pFrameBase;

    if (pParentMatrix != NULL) {
        D3DXMatrixMultiply(&pFrame->CombinedTransformationMatrix, &pFrame->TransformationMatrix, pParentMatrix);
    }
    else {
        pFrame->CombinedTransformationMatrix = pFrame->TransformationMatrix;
    }

    if (pFrame->pFrameSibling != NULL) {
        UpdateFrameMatrices(pFrame->pFrameSibling, pParentMatrix);
    }

    if (pFrame->pFrameFirstChild != NULL) {
        UpdateFrameMatrices(pFrame->pFrameFirstChild, &pFrame->CombinedTransformationMatrix);
    }
}
//
//VOID RenderThing(THING* pThing)
//���̂������_�����O
void RenderThing(ANIMATION_OBJECT* pObject) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    //���[���h�g�����X�t�H�[���i��΍��W�ϊ��j
    D3DXMATRIXA16 matWorld, matPosition, mtxScl, mtxRot;
    D3DXMatrixIdentity(&matWorld);

    D3DXMatrixScaling(&mtxScl, pObject->dynamic_obj.object.vecScale.x, pObject->dynamic_obj.object.vecScale.y,
                      pObject->dynamic_obj.object.vecScale.z);
    D3DXMatrixMultiply(&matWorld, &matWorld, &mtxScl);

    D3DXMatrixRotationYawPitchRoll(&mtxRot, pObject->dynamic_obj.object.vecRotation.y, pObject->dynamic_obj.object.vecRotation.x,
                                   pObject->dynamic_obj.object.vecRotation.z);
    D3DXMatrixMultiply(&matWorld, &matWorld, &mtxRot);

    D3DXMatrixTranslation(&matPosition, pObject->dynamic_obj.object.vecPosition.x, pObject->dynamic_obj.object.vecPosition.y,
                          pObject->dynamic_obj.object.vecPosition.z);
    D3DXMatrixMultiply(&matWorld, &matWorld, &matPosition);
    pDevice->SetTransform(D3DTS_WORLD, &matWorld);

    UpdateFrameMatrices(pObject->pFrameRoot, &matWorld);

    if ((pObject->animdata[pObject->animid].animtime <= pObject->animdata[pObject->animid].endtime) ||
        pObject->animdata[pObject->animid].endtime == 0.0f) {
        pObject->pAnimController->AdvanceTime(pObject->animdata[pObject->animid].animspeed, NULL);
        pObject->animdata[pObject->animid].animtime += pObject->animdata[pObject->animid].animspeed;
    }
    else {
        //�A�j���[�V�������[�J�����ԃ��Z�b�g
        pObject->pAnimController->SetTrackPosition(0, pObject->animdata[pObject->animid].loopstart);
        pObject->pAnimController->AdvanceTime(0, NULL);
        pObject->animdata[pObject->animid].animtime = pObject->animdata[pObject->animid].loopstart;

        if (pObject->animid == ANIMATION_INDEX_PLAYER_WAIT1 || pObject->animid == ANIMATION_INDEX_PLAYER_WAIT2)
            PLAYER_STATE_lifted();

    }

    DrawFrame(pObject->pFrameRoot);
}

void ANIMATION_set(ANIMATION_OBJECT* panim, int id) {
    if (panim->animid != id) {
        panim->animid = id;
        panim->pAnimController->SetTrackAnimationSet(0, panim->animdata[panim->animid].pAnimset);

        panim->animdata[panim->animid].animtime = 0.0f;
        panim->pAnimController->SetTrackSpeed(0, 1);

        //�A�j���[�V�������[�J�����ԃ��Z�b�g
        panim->pAnimController->SetTrackPosition(0, 0.0);
        panim->pAnimController->AdvanceTime(0, NULL);
    }
}
