/*==============================================================================
    DirectX9_HEW_ROC
    [navigator.cpp]
    �E�i�r�Q�[�^�[�X�e�[�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "state.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

/*============================================================================*/
void NAVIGATOR_initialize(void) {

}

void NAVIGATOR_finalize(void) {

}

void NAVIGATOR_update(void) {
    if (KEYBOARD_trigger(DIK_0)) {
        STATE_set(STATE_NORMAL);
    }
}

void NAVIGATOR_draw(void) {
    SPRITE_draw(TEST_NAVIGATOR);
}