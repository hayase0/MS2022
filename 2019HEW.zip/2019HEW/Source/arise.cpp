/*==============================================================================
    DirectX9_HEW_ROC
    [arise.cpp]
    �E�Q�[���J�n�X�e�[�g(�v���C���[�L�����o��)
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_11-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "state.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

/*============================================================================*/
void ARISE_initialize(void) {

}

void ARISE_finalize(void) {

}

void ARISE_update(void) {
    if (KEYBOARD_trigger(DIK_0)) {
        STATE_set(STATE_NORMAL);
    }
}

void ARISE_draw(void) {
    SPRITE_draw(TEST_ARISE);
}