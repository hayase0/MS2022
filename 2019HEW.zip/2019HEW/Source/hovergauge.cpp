/*==============================================================================
    DirectX9_HEW_ROC
    [hovergauge.cpp]
    �E�z�o�[�Q�[�W
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_21-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "texture.h"
#include "player.h"
#include "hovergauge.h"
#include "sprite.h"
#include "keyboard.h"

void HOVERGAUGE_initialize(void) {
    
}

void HOVERGAUGE_finalize(void) {

}

void HOVERGAUGE_updata(void) {
    
}

void HOVERGAUGE_draw(void) {
    SPRITE_draw(TEXTURE_INDEX_GAUGE_EMPTY,
                1920 / 2,
                1080 - 100);

    SPRITE_draw(TEXTURE_INDEX_GAUGE_FULL,
                1920 / 2 - 124,
                1080 - 105,
                248,
                10,
                (int)(248 * PLAYER_gethovergauge()),
                10);
}