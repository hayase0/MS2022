/*==============================================================================
    DirectX9_HEW_ROC
    [ARM.cpp]
    �E�t�b�N�V���b�g
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_16-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "direct3d.h"
#include "gamepad.h"
#include "keyboard.h"
#include "player.h"
#include "player_action.h"
#include "player_state.h"
#include "stage.h"
#include "camera.h"
#include "collision_box.h"
#include "arm.h"

#include <time.h>
#include <math.h>

#define FRAME_SHOT       (10)         //�t�b�N�V���b�g���˃X�s�[�h

static ANIMATION_OBJECT arm;
static bool shot = false;             //�t�b�N�V���b�g���˃t���O
static D3DXVECTOR3 hook_goal;         //�t�b�N�V���b�g����ڕW�_�܂ł̃x�N�g��
static float length_hook_goal;        //�t�b�N�V���b�g����ڕW�_�܂ł̋���
static int frame;                     //�t���[���J�E���g�p

void ARM_initialize(void) {
    arm.dynamic_obj = *PLAYER_get();
    shot = false;
    arm.animobjidx = ANIMOBJ_INDEX_PLAYERARM;
    ANIMATION_load(&arm, ANIMOBJ_INDEX_PLAYERARM);
    ANIMATION_set(&arm, ANIMATION_INDEX_PLAYERARM_WAIT);

    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT].animspeed = 0.00005f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT].endtime = 0.101f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT].loopstart = 0.0f;

    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT1].animspeed = 0.00015f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT1].endtime = 0.035f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT1].loopstart = 0.0f;

    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT2].animspeed = 0.00007f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT2].endtime = 0.016f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WAIT2].loopstart = 0.0f;

    arm.animdata[ANIMATION_INDEX_PLAYERARM_WALK].animspeed = 0.00025f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WALK].endtime = 0.0101f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_WALK].loopstart = 0.0f;

    arm.animdata[ANIMATION_INDEX_PLAYERARM_RUN].animspeed = 0.0001f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_RUN].endtime = 0.0108f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_RUN].loopstart = 0.0026f;

    arm.animdata[ANIMATION_INDEX_PLAYERARM_SHOT].animspeed = 0.0001f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_SHOT].endtime = 0.0005f;
    arm.animdata[ANIMATION_INDEX_PLAYERARM_SHOT].loopstart = 0.0f;
}

void ARM_update(void) {
    //�v���C���[�ɒǏ]
    if (PLAYER_STATE_get() != PLAYER_STATE_SHOT && PLAYER_STATE_get() != PLAYER_STATE_HOOKMOVE && PLAYER_STATE_get() != PLAYER_STATE_SWING) {
        arm.dynamic_obj = *PLAYER_get();
        arm.dynamic_obj.object.vecPosition.y += 37.0f;

    }
}

void ARM_draw(void) {
    RenderThing(&arm);
}

void ARM_shot(void) {
    DYNAMIC_OBJECT *player = PLAYER_get();
    arm.dynamic_obj.object.vecPosition += hook_goal / FRAME_SHOT;

    frame++;
    if (frame >= FRAME_SHOT) { //�ڕW�_�܂œ��B��
        PLAYER_STATE_set(PLAYER_STATE_SWING);
        PLAYER_ACTION_sethookmove();
        frame = 0;
    }
}

void ARM_setgoalpos(void) {
    D3DXVec3Subtract(&hook_goal, &PLAYER_getgoalpos(), &arm.dynamic_obj.object.vecPosition);

    arm.dynamic_obj.object.vecRotation.y = atan2f(hook_goal.x, hook_goal.z);

    D3DXVECTOR2 vec_xz;
    vec_xz.x = hook_goal.x;
    vec_xz.y = hook_goal.z;
    float length = D3DXVec2Length(&vec_xz);
    float rot = atan2f(length, hook_goal.y - arm.dynamic_obj.object.vecPosition.y) - D3DX_PI * 0.6f;

    arm.dynamic_obj.object.vecRotation.x = rot;
}

ANIMATION_OBJECT* ARM_get(void) {
    return &arm;
}

D3DXVECTOR3 ARM_getpos(void) {
    return arm.dynamic_obj.object.vecPosition;
}