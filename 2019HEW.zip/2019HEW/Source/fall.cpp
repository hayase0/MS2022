/*==============================================================================
    DirectX9_HEW_ROC
    [fall.cpp]
    �E�������X�e�[�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_11-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "texture.h"
#include "sprite.h"

#include "player.h"
#include "state.h"

#include "camera.h"

#define DEATH_BORDERLINE        (-1000.0f)      // ������������W(y)


static DYNAMIC_OBJECT *player;

/*============================================================================*/

static void reset_player_point(float x, float y, float z, float rotx, float roty, float rotz) {
    player->object.vecPosition = D3DXVECTOR3(x, y, z);
    player->object.vecRotation = D3DXVECTOR3(rotx, roty, rotz);
}

static int check_drop_point(void) {
    int fallcheck;

    // �����Ŏ��S���W���i��B

    if (player->object.vecPosition.x > 500) {
        fallcheck = 1;
        return fallcheck;
    }

    if (player->object.vecPosition.x < 500) {
        fallcheck = 2;
        return fallcheck;
    }

    if (player->object.vecPosition.z > 754) {
        fallcheck = 3;
        return fallcheck;
    }

    if (player->object.vecPosition.x > 754) {
        fallcheck = 4;
        return fallcheck;
    }

    return 0;
}

static void player_reset_point(void) {
    switch (check_drop_point()) {
    case 1:
        reset_player_point(100.0f, 50.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        break;
    case 2:
        reset_player_point(-100.0f, 50.0f, 0.0f, 0.0f, 0.0f, 0.0f);
        break;
    case 3:
        reset_player_point(0.0f, 50.0f, 100.0f, 0.0f, 0.0f, 0.0f);
        break;
    case 4:
        reset_player_point(0.0f, 50.0f, -100.0f, 0.0f, 0.0f, 0.0f);
        break;

    default:
        break;
    }
}


/*============================================================================*/
void FALL_initialize(void) {
    player = PLAYER_get();
    CAMERA_set_not_y(false);
}

void FALL_finalize(void) {
    CAMERA_set_not_y(true);
}

void FALL_update(void) {
    int count = 0;
    
    CAMERA_set_not_y(true);

    if (count > 300)
        player_reset_point();


    count++;

}


void FALL_draw(void) {
    //SPRITE_draw(TEST_FALL);
}

// ����ł���true��Ԃ�
bool FALL_border(void) {
    if (player->object.vecPosition.y < DEATH_BORDERLINE) return true;
    return false;
}