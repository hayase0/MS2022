/*==============================================================================
    DirectX9_HEW_ROC
    [player.cpp]
    �E�v���C���[
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_10_23-2019_10_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "mesh.h"
#include "keyboard.h"
#include "gamepad.h"
#include "direct3d.h"
#include "stage_f.h"
#include <time.h>
#include "collision_box.h"
#include "player_action.h"
#include "player_state.h"
#include "animation.h"
#include "player.h"

#include "cube.h"
#include "xcube.h"
#include "item.h"

static ANIMATION_OBJECT player;

void PLAYER_initialize(void) {
    ANIMATION_load(&player, ANIMOBJ_INDEX_PLAYER);
    player.dynamic_obj.object.vecPosition = D3DXVECTOR3(0, 200, 0);
    player.dynamic_obj.object.vecRotation = D3DXVECTOR3(0, 0, 0);
    player.dynamic_obj.object.vecScale = D3DXVECTOR3(50.0f, 50.0f, 50.0f);
    player.animobjidx = ANIMOBJ_INDEX_PLAYER;
    player.dynamic_obj.object.meshIndex = MESH_INDEX_PLAYER;
    PLAYER_STATE_set(PLAYER_STATE_WAIT);
    player.dynamic_obj.hovergage = 1.0f;
    player.dynamic_obj.move = D3DXVECTOR3(0, 0, 0);
    PLAYER_ACTION_settime();
    player.dynamic_obj.flightTime = 0;
    player.dynamic_obj.fpaim = false;

    player.animid = ANIMATION_INDEX_PLAYER_WAIT;
    ANIMATION_set(&player, player.animid);

    //player.animdata[ANIMATION_INDEX_PLAYER_WAIT].animspeed = 1.0f;
    //player.animdata[ANIMATION_INDEX_PLAYER_WALK].animspeed = 3.0f;


    //player.animdata[ANIMATION_INDEX_PLAYER_WAIT].endtime = 1.0f;
    //player.animdata[ANIMATION_INDEX_PLAYER_WALK].endtime = 0.0f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT].animspeed = 0.00005f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT].endtime = 0.101f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT].loopstart = 0.0f;

    player.animdata[ANIMATION_INDEX_PLAYER_WAIT1].animspeed = 0.00015f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT1].endtime = 0.035f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT1].loopstart = 0.0f;

    player.animdata[ANIMATION_INDEX_PLAYER_WAIT2].animspeed = 0.00007f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT2].endtime = 0.016f;
    player.animdata[ANIMATION_INDEX_PLAYER_WAIT2].loopstart = 0.0f;

    player.animdata[ANIMATION_INDEX_PLAYER_WALK].animspeed = 0.00025f;
    player.animdata[ANIMATION_INDEX_PLAYER_WALK].endtime = 0.0101f;
    player.animdata[ANIMATION_INDEX_PLAYER_WALK].loopstart = 0.0f;

    player.animdata[ANIMATION_INDEX_PLAYER_RUN].animspeed = 0.0001f;
    player.animdata[ANIMATION_INDEX_PLAYER_RUN].endtime = 0.0108f;
    player.animdata[ANIMATION_INDEX_PLAYER_RUN].loopstart = 0.0026f;

    player.animdata[ANIMATION_INDEX_PLAYER_SHOT].animspeed = 0.0001f;
    player.animdata[ANIMATION_INDEX_PLAYER_SHOT].endtime = 0.0005f;
    player.animdata[ANIMATION_INDEX_PLAYER_SHOT].loopstart = 0.0f;

    COLLISION_BOX_setting(&player.dynamic_obj);
    COLLISION_BOX_draw_initialize(&player.dynamic_obj.object);
}

void PLAYER_update(void) {
    PLAYER_STATE_update();

    // �v���C���[�ʒu���Z�b�g
    if (KEYBOARD_press(DIK_R)) {
        PLAYER_initialize();
    }

    if (PLAYER_STATE_get() != PLAYER_STATE_HOOKMOVE && PLAYER_STATE_get() != PLAYER_STATE_SHOT && PLAYER_STATE_get() != PLAYER_STATE_SWING)
        if (KEYBOARD_press(DIK_LSHIFT) || GAMEPAD_ispress(0, BUTTON_L2)) {
            player.dynamic_obj.fpaim = true;
        }
    if (player.dynamic_obj.fpaim == true) {
        PLAYER_ACTION_fpaim();
    }

    // �����蔻��
    player.dynamic_obj.flight = true;
    player.dynamic_obj.conflict = false;

    STAGE_F_collsion(&player.dynamic_obj);

    //{
    //    CUBE* objCube = CUBE_get();    // �X�e�[�W�̃I�u�W�F�N�g���擾
    //    OBJECT* objXCube = XCUBE_get();    // �X�e�[�W�̃I�u�W�F�N�g���擾

    //    static int cube_num = CUBE_get_num();
    //    static int xcube_num = XCUBE_get_num();

    //    for (int i = 0; i < NUM_DETECTION + 1; i++) {
    //        if (i != 0) player.dynamic_obj.object.vecPosition += player.dynamic_obj.move / NUM_DETECTION;
    //        COLLISION_BOX_setting(&player.dynamic_obj);         // �����蔻����X�V
    //        while (1) {
    //            for (int j = 0; j < cube_num; j++) {
    //                if (objCube[j].object.isuse)
    //                    if (COLLISION_BOX_collision(&player.dynamic_obj, &(objCube[j].object))) continue;
    //            }
    //            break;
    //        }
    //        while (1) {
    //            for (int j = 0; j < xcube_num; j++) {
    //                if (objXCube[j].isuse)
    //                    if (COLLISION_BOX_collision(&player.dynamic_obj, &objXCube[j])) continue;
    //            }
    //            break;
    //        }
    //    }
    //}

    //ITEM_OBJECT* objItem = ITEM_get_obtained();    // �A�C�e���̃I�u�W�F�N�g���擾
    //for (int i = 0; i < 5; i++)
    //    if (objItem[i].object.isuse) {
    //        objItem[i].object.objColBox[0].detection = false;
    //        if (COLLISION_BOX_trigger(&player.dynamic_obj, &objItem[i].object))objItem[i].object.objColBox[0].detection = true;
    //    }
}

void PLAYER_draw(void) {
    RenderThing(&player);

    //COLLISION_BOX_draw(&player.object);
}

ANIMATION_OBJECT* PLAYER_animget(void) {
    return &player;
}

DYNAMIC_OBJECT* PLAYER_get(void) {
    return &player.dynamic_obj;
}

D3DXVECTOR3 PLAYER_getpos(void) {
    return player.dynamic_obj.object.vecPosition;
}

D3DXVECTOR3* PLAYER_getrot(void) {
    return &player.dynamic_obj.object.vecRotation;
}

D3DXVECTOR3 PLAYER_getscl(void) {
    return player.dynamic_obj.object.vecScale;
}

D3DXVECTOR3 PLAYER_getgoalpos(void) {
    return player.dynamic_obj.targetpos;
}

bool PLAYER_lockon(void) {
    return player.dynamic_obj.lockon;
}

float PLAYER_gethovergauge(void) {
    return player.dynamic_obj.hovergage;
}

bool PLAYER_moveflag(void) {
    if (player.dynamic_obj.move.x != 0 || player.dynamic_obj.move.z != 0)return true;
    return false;
}

bool PLAYER_getfpaimflag(void) {
    return player.dynamic_obj.fpaim;
}

void PLAYER_resetmove(void) {
    player.dynamic_obj.move = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
}