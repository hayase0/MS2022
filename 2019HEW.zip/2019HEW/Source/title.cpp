/*==============================================================================
    DirectX9_HEW_ROC
    [title.cpp]
    �E�^�C�g���V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"

#include "scene.h"
#include "phase.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

#include "transition.h"



#include "character.h"

/*============================================================================*/
static SCENE Next_scene;

/*============================================================================*/
void TITLE_initialize(void) {
    PHASE_set(PHASE_BEGIN);
}
void TITLE_finalize(void) {

}
void TITLE_update(void) {
    PHASE_function(SCENE_get());
}
void TITLE_draw(void) {
    SPRITE_draw(TEST_02);
}
/*============================================================================*/
void TITLE_begin(void) {
    if (!TRANSITION_check()) PHASE_set(PHASE_RUN);
}
void TITLE_run(void) {
    if (KEYBOARD_trigger(DIK_1)) {
        Next_scene = SCENE_ENTRY;
        TRANSITION_set(FADE_OUT, 60);
        PHASE_set(PHASE_END);
    }
    if (KEYBOARD_trigger(DIK_2)) {
        Next_scene = SCENE_DEMO;
        PHASE_set(PHASE_END);
    }
}
void TITLE_end(void) {
    if (!TRANSITION_check()) SCENE_change(Next_scene);
}