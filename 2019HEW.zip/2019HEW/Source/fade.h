/*==============================================================================
    DirectX9_HEW_ROC
    [fade.h]
    �E�t�F�[�h
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_28-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

struct Fade_vertex {
    D3DXVECTOR4 position;
    D3DCOLOR color;
};
#define FVF_FADE_VERTEX (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)

void FADE_in(void);
void FADE_out(void);
void FADE_initialize(void);
void FADE_finalize(void);
void FADE_update(void);
void FADE_draw(void);