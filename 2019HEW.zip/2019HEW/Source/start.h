/*==============================================================================
    DirectX9_HEW_ROC
    [start.h]
    �E�N���V�[���B���S��\������B
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once



void START_initialize(void);
void START_finalize(void);
void START_update(void);
void START_draw(void);

void START_begin(void);
void START_run(void);
void START_end(void);