/*==============================================================================
    DirectX9_HEW_ROC
    [playeraction.cpp]
    �E�v���C���[����
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_17-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "camera.h"
#include "player.h"
#include "stage.h" 
#include "cube.h"
#include "xcube.h"
#include "target.h"
#include "item.h"
#include "collision_box.h"
#include "keyboard.h"
#include "gamepad.h"
#include "player_action.h"
#include "player_state.h"
#include "debugproc.h"
#include "ARM.h"
#include "guide.h"
#include <time.h>

#define VALUE_MOVE           (5.0f)                // �ړ���
#define VALUE_RUNMOVE        (20.0f)                // �_�b�V���ړ���
#define VALUE_JUMPMOVE       (VALUE_MOVE/80)       // �W�����v���ړ���
#define VALUE_ROTATE         (D3DX_PI * 0.08f)     // ��]��
#define ROTATE_MIN           (D3DX_PI * 0.125f)    // ��]��
#define VALUE_JUMP           (7.0f)                // �W�����v��
#define FALLSPEED_MAX        (-20.0f)              // �������x�ő�l
#define VALUE_HOVER          (0.05f)               // �z�o�[
#define VALUE_HOOKMOVE       (20.0f)               // �t�b�N�V���b�g�ړ���
#define ARM_FRAME_MAX   (60)                       // �t�b�N�V���b�g�ő�t���[��
#define ARM_RANGE_MIN   (300.0f)                   // �t�b�N�V���b�g�˒�����
#define ARM_RANGE_MAX   (900.0f)                   // �t�b�N�V���b�g�˒�����
#define XZ_RANGE             (D3DX_PI / 10)        // �t�b�N�V���b�g�^�[�Q�b�g�͈�
#define Y_RANGE              (D3DX_PI / 20)        // �t�b�N�V���b�g�^�[�Q�b�g�͈�
#define INTERVALFRAME        (10)                  // ���n��d���t���[��
#define FRAME_HOVER          (60)                 // �z�o�[�ő�t���[��
#define FRAME_RUN            (300)                 // �_�b�V���ő�t���[��
#define FRAME_HOVER_RECOVERY (200)
#define VALUE_AIR_RESISTANCE (0.990f)              // ��C��R
#define VALUE_GRAVITY        (9.8f)                // �d��

static int previoustime;                           // �O�t���[���̎���(�~���b�P��)
static D3DXVECTOR3 targetpos;
static int frame;
static D3DXVECTOR3 player_target;

static int Taget_rockon_num = 0;

/*===========================================================================================================*/
//�ҋ@
void PLAYER_ACTION_wait(void) {
    ANIMATION_OBJECT* player = PLAYER_animget();

    if (player->dynamic_obj.flight == false) {//�Q�[�W��
        if (player->dynamic_obj.hovergage < 1.0f) player->dynamic_obj.hovergage += 1.0f / FRAME_HOVER_RECOVERY;
        if (player->dynamic_obj.hovergage >= 1.0f) player->dynamic_obj.hovergage = 1.0f;
        player->dynamic_obj.flightTime = 0.0f;
        PLAYER_ACTION_settime();
    }
    else {//����
        if (player->dynamic_obj.move.y >= FALLSPEED_MAX) {//�d��
            int currenttime = clock();                                 // ���݂̎���(�~���b�P��)
            player->dynamic_obj.flightTime = (float)(currenttime - previoustime);  // �؋󎞊ԉ��Z(�~���b�P��)
            player->dynamic_obj.move.y -= VALUE_GRAVITY * player->dynamic_obj.flightTime / 15000;       // �d�͉��Z(�d�͉����x*�؋󎞊�)
        }
        if (player->dynamic_obj.move.y < 0.0f)
            PLAYER_STATE_set(PLAYER_STATE_FALL);
    }

    if (KEYBOARD_press(DIK_W) || KEYBOARD_press(DIK_A) || KEYBOARD_press(DIK_S) || KEYBOARD_press(DIK_D) ||
        LEFTSTICK_get().x != 0 || LEFTSTICK_get().y != 0) {
        PLAYER_STATE_set(PLAYER_STATE_WALK);
    }
    if (player->dynamic_obj.flight == false) {//�W�����v
        if (KEYBOARD_press(DIK_SPACE) || GAMEPAD_ispress(0, BUTTON_X)) {
            PLAYER_STATE_set(PLAYER_STATE_JUMP);
        }
    }

    if (KEYBOARD_press(DIK_G) || GAMEPAD_ispress(0, BUTTON_O)) {
        PLAYER_STATE_set(PLAYER_STATE_GETITEM);
    }
}

/*===========================================================================================================*/
//��{�ړ�
void PLAYER_ACTION_move_(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    D3DXVECTOR3 cam_rot = CAMERA_getrot();

    if (player->flight == false) {
        player->move.x = 0.0f;
        player->move.z = 0.0f;
    }
    else {
        player->move.x *= VALUE_AIR_RESISTANCE;
        player->move.z *= VALUE_AIR_RESISTANCE;
    }

    if (player->object.vecRotation.y < 0) player->object.vecRotation.y += D3DX_PI * 2.0f;
    if (player->object.vecRotation.y > D3DX_PI * 2.0f) player->object.vecRotation.y -= D3DX_PI * 2.0f;

    if (PLAYER_STATE_get() != PLAYER_STATE_SHOT) {//�t�b�N�V���b�g���˒��͈ړ��s��
        float valuemove = VALUE_MOVE;

        if (player->hovergage > 0.0f) {
            //�_�b�V��
            if (KEYBOARD_press(DIK_LCONTROL) || GAMEPAD_ispress(0, BUTTON_L) || GAMEPAD_ispress(0, BUTTON_R) || GAMEPAD_ispress(0, BUTTON_L3)) {
                valuemove = VALUE_RUNMOVE;
                player->hovergage -= 1.0f / FRAME_RUN;
                PLAYER_STATE_set(PLAYER_STATE_RUN);
            }
        }
        //�_�b�V������
        if (KEYBOARD_release(DIK_LCONTROL) || GAMEPAD_isrelease(0, BUTTON_L) || GAMEPAD_isrelease(0, BUTTON_R) || GAMEPAD_isrelease(0, BUTTON_L3)) {
            PLAYER_STATE_set(PLAYER_STATE_WALK);
        }
        //�W�����v��
        if (player->flight == true) valuemove = VALUE_JUMPMOVE;

        //�Q�[���p�b�h����
        if (LEFTSTICK_get().x != 0 || LEFTSTICK_get().y != 0) {
            if (player->fpaim == false) {
                float rot_input = atan2f(-LEFTSTICK_get().x, LEFTSTICK_get().y) + cam_rot.y - D3DX_PI;

                if (rot_input < 0) rot_input += D3DX_PI * 2.0f;
                if (rot_input > D3DX_PI * 2.0f) rot_input -= D3DX_PI * 2.0f;

                float prot_difference = player->object.vecRotation.y - rot_input;

                if (prot_difference > ROTATE_MIN || prot_difference < -ROTATE_MIN) {
                    if (prot_difference > 0.0f) {
                        if (prot_difference >= D3DX_PI) {
                            player->object.vecRotation.y += VALUE_ROTATE;
                            prot_difference = (D3DX_PI * 2.0f - prot_difference);
                            if (prot_difference <= VALUE_ROTATE)
                                player->object.vecRotation.y = rot_input;
                        }
                        else {
                            player->object.vecRotation.y -= VALUE_ROTATE;
                            if (prot_difference <= VALUE_ROTATE)
                                player->object.vecRotation.y = rot_input;
                        }
                    }
                    if (prot_difference < 0.0f) {
                        if (prot_difference <= -D3DX_PI) {
                            player->object.vecRotation.y -= VALUE_ROTATE;
                            prot_difference = -(D3DX_PI * 2.0f + prot_difference);
                            if (prot_difference >= -VALUE_ROTATE)
                                player->object.vecRotation.y = rot_input;
                        }
                        else {
                            player->object.vecRotation.y += VALUE_ROTATE;
                            if (prot_difference >= -VALUE_ROTATE)
                                player->object.vecRotation.y = rot_input;
                        }
                    }
                }
                else {
                    player->object.vecRotation.y = rot_input;
                    player->move.x += sinf(player->object.vecRotation.y) * valuemove * D3DXVec2LengthSq(&(LEFTSTICK_get() / RANGE_MAX));
                    player->move.z += cosf(player->object.vecRotation.y) * valuemove * D3DXVec2LengthSq(&(LEFTSTICK_get() / RANGE_MAX));
                }
            }
            else {
                player->move.x += sinf(player->object.vecRotation.y - D3DX_PI / 2) * LEFTSTICK_get().x / RANGE_MAX * valuemove +
                    sinf(player->object.vecRotation.y) * LEFTSTICK_get().y / RANGE_MAX * valuemove;
                player->move.z += cosf(player->object.vecRotation.y - D3DX_PI / 2) * LEFTSTICK_get().x / RANGE_MAX * valuemove +
                    cosf(player->object.vecRotation.y) * LEFTSTICK_get().y / RANGE_MAX * valuemove;
            }
        }

        //�L�[�{�[�h����
        if (player->fpaim == false) {
            if (KEYBOARD_press(DIK_A) && !KEYBOARD_press(DIK_D)) { // ���ړ�
                if (KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_S))player->object.vecRotation.y = cam_rot.y + D3DX_PI * 0.75f;
                else if (!KEYBOARD_press(DIK_W) && KEYBOARD_press(DIK_S))player->object.vecRotation.y = cam_rot.y + D3DX_PI * 0.25f;
                else player->object.vecRotation.y = cam_rot.y + D3DX_PI * 0.50f;
                player->move.x += sinf(player->object.vecRotation.y) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y) * valuemove;
            }
            else if (!KEYBOARD_press(DIK_A) && KEYBOARD_press(DIK_D)) { // �E�ړ�
                if (KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_S))player->object.vecRotation.y = cam_rot.y - D3DX_PI * 0.75f;
                else if (!KEYBOARD_press(DIK_W) && KEYBOARD_press(DIK_S))player->object.vecRotation.y = cam_rot.y - D3DX_PI * 0.25f;
                else player->object.vecRotation.y = cam_rot.y - D3DX_PI * 0.50f;
                player->move.x += sinf(player->object.vecRotation.y) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y) * valuemove;
            }
            else if (KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_S)) {
                player->object.vecRotation.y = cam_rot.y + D3DX_PI;
                player->move.x += sinf(player->object.vecRotation.y) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y) * valuemove;
            }
            else if (!KEYBOARD_press(DIK_W) && KEYBOARD_press(DIK_S)) {
                player->object.vecRotation.y = cam_rot.y;
                player->move.x += sinf(player->object.vecRotation.y) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y) * valuemove;
            }
        }
        else {
            if (KEYBOARD_press(DIK_W)) {
                player->move.x += sinf(player->object.vecRotation.y) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y) * valuemove;
            }
            if (KEYBOARD_press(DIK_A)) {
                player->move.x += sinf(player->object.vecRotation.y - D3DX_PI * 0.5f) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y - D3DX_PI * 0.5f) * valuemove;
            }
            if (KEYBOARD_press(DIK_S)) {
                player->move.x += sinf(player->object.vecRotation.y + D3DX_PI) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y + D3DX_PI) * valuemove;
            }
            if (KEYBOARD_press(DIK_D)) {
                player->move.x += sinf(player->object.vecRotation.y + D3DX_PI * 0.5f) * valuemove;
                player->move.z += cosf(player->object.vecRotation.y + D3DX_PI * 0.5f) * valuemove;
            }
        }

        if (LEFTSTICK_get().x == 0 && LEFTSTICK_get().y == 0) {
            PLAYER_STATE_set(PLAYER_STATE_WAIT);
        }
    }

    //�W�����v
    if (player->flight == false) {
        if ((KEYBOARD_press(DIK_SPACE) || GAMEPAD_ispress(0, BUTTON_X))) {
            PLAYER_STATE_set(PLAYER_STATE_JUMP);

        }
    }
    else {
        if (player->move.y >= FALLSPEED_MAX) {//�d��
            int currenttime = clock();                                 // ���݂̎���(�~���b�P��)
            player->flightTime = (float)(currenttime - previoustime);  // �؋󎞊ԉ��Z(�~���b�P��)
            player->move.y -= 9.8f * player->flightTime / 20000;       // �d�͉��Z(�d�͉����x*�؋󎞊�)
        }
    }

    if (PLAYER_STATE_get() == PLAYER_STATE_SHOT) player->move.y *= 0.9f;

    if (PLAYER_STATE_get() != PLAYER_STATE_RUN && PLAYER_STATE_get() != PLAYER_STATE_HOVER && PLAYER_STATE_get() != PLAYER_STATE_SHOT) {
        if (player->flight == false) {
            if (player->hovergage < 1.0f) player->hovergage += 1.0f / FRAME_HOVER * 0.5f;
            if (player->hovergage >= 1.0f) player->hovergage = 1.0f;
            player->flightTime = 0.0f;
            PLAYER_ACTION_settime();
        }
        else {
            if (player->move.y < 0.0f) {
                PLAYER_STATE_set(PLAYER_STATE_FALL);
            }
        }
    }
}


void PLAYER_ACTION_move(void) {
    ANIMATION_OBJECT* player = PLAYER_animget();
    D3DXVECTOR3 cam_rot = CAMERA_getrot();

    if (player->dynamic_obj.flight == false) {
        player->dynamic_obj.move.x = 0.0f;
        player->dynamic_obj.move.z = 0.0f;
    }
    else {
        player->dynamic_obj.move.x *= VALUE_AIR_RESISTANCE;
        player->dynamic_obj.move.z *= VALUE_AIR_RESISTANCE;
    }

    if (player->dynamic_obj.object.vecRotation.y < 0) player->dynamic_obj.object.vecRotation.y += D3DX_PI * 2.0f;
    if (player->dynamic_obj.object.vecRotation.y > D3DX_PI * 2.0f) player->dynamic_obj.object.vecRotation.y -= D3DX_PI * 2.0f;

    if (PLAYER_STATE_get() != PLAYER_STATE_SHOT) {//�t�b�N�V���b�g���˒��͈ړ��s��
        float valuemove = VALUE_MOVE;

        if (player->dynamic_obj.hovergage >= 1.0f / FRAME_HOVER) {
            //�_�b�V��
            if (KEYBOARD_press(DIK_LCONTROL) || GAMEPAD_ispress(0, BUTTON_L) || GAMEPAD_ispress(0, BUTTON_R) || GAMEPAD_ispress(0, BUTTON_L3)) {
                valuemove = VALUE_RUNMOVE;
                player->dynamic_obj.hovergage -= 1.0f / FRAME_RUN;
                PLAYER_STATE_set(PLAYER_STATE_RUN);
            }
        }
        //�_�b�V������
        if (KEYBOARD_release(DIK_LCONTROL) || GAMEPAD_isrelease(0, BUTTON_L) || GAMEPAD_isrelease(0, BUTTON_R) || GAMEPAD_isrelease(0, BUTTON_L3) || player->dynamic_obj.hovergage < 1.0f / FRAME_HOVER) {
            PLAYER_STATE_set(PLAYER_STATE_WALK);
        }
        //�W�����v��
        if (player->dynamic_obj.flight == true) valuemove = VALUE_JUMPMOVE;

        //�Q�[���p�b�h����
        if (LEFTSTICK_get().x != 0 || LEFTSTICK_get().y != 0) {
            if (player->dynamic_obj.fpaim == false) {
                float rot_input = atan2f(-LEFTSTICK_get().x, LEFTSTICK_get().y) + cam_rot.y - D3DX_PI;

                if (rot_input < 0) rot_input += D3DX_PI * 2.0f;
                if (rot_input > D3DX_PI * 2.0f) rot_input -= D3DX_PI * 2.0f;

                float prot_difference = player->dynamic_obj.object.vecRotation.y - rot_input;

                if (prot_difference > ROTATE_MIN || prot_difference < -ROTATE_MIN) {
                    if (prot_difference > 0.0f) {
                        if (prot_difference >= D3DX_PI) {
                            player->dynamic_obj.object.vecRotation.y += VALUE_ROTATE;
                            prot_difference = (D3DX_PI * 2.0f - prot_difference);
                            if (prot_difference <= VALUE_ROTATE)
                                player->dynamic_obj.object.vecRotation.y = rot_input;
                        }
                        else {
                            player->dynamic_obj.object.vecRotation.y -= VALUE_ROTATE;
                            if (prot_difference <= VALUE_ROTATE)
                                player->dynamic_obj.object.vecRotation.y = rot_input;
                        }
                    }
                    if (prot_difference < 0.0f) {
                        if (prot_difference <= -D3DX_PI) {
                            player->dynamic_obj.object.vecRotation.y -= VALUE_ROTATE;
                            prot_difference = -(D3DX_PI * 2.0f + prot_difference);
                            if (prot_difference >= -VALUE_ROTATE)
                                player->dynamic_obj.object.vecRotation.y = rot_input;
                        }
                        else {
                            player->dynamic_obj.object.vecRotation.y += VALUE_ROTATE;
                            if (prot_difference >= -VALUE_ROTATE)
                                player->dynamic_obj.object.vecRotation.y = rot_input;
                        }
                    }
                }
                else {
                    player->dynamic_obj.object.vecRotation.y = rot_input;
                    player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y) * valuemove * D3DXVec2LengthSq(&(LEFTSTICK_get() / RANGE_MAX));
                    player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y) * valuemove * D3DXVec2LengthSq(&(LEFTSTICK_get() / RANGE_MAX));
                }
            }
            else {
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y - D3DX_PI / 2) * LEFTSTICK_get().x / RANGE_MAX * valuemove +
                    sinf(player->dynamic_obj.object.vecRotation.y) * LEFTSTICK_get().y / RANGE_MAX * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y - D3DX_PI / 2) * LEFTSTICK_get().x / RANGE_MAX * valuemove +
                    cosf(player->dynamic_obj.object.vecRotation.y) * LEFTSTICK_get().y / RANGE_MAX * valuemove;
            }
        }

        //�L�[�{�[�h����
        if (player->dynamic_obj.fpaim == false) {
            if (KEYBOARD_press(DIK_A) && !KEYBOARD_press(DIK_D)) { // ���ړ�
                if (KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_S))player->dynamic_obj.object.vecRotation.y = cam_rot.y + D3DX_PI * 0.75f;
                else if (!KEYBOARD_press(DIK_W) && KEYBOARD_press(DIK_S))player->dynamic_obj.object.vecRotation.y = cam_rot.y + D3DX_PI * 0.25f;
                else player->dynamic_obj.object.vecRotation.y = cam_rot.y + D3DX_PI * 0.50f;
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y) * valuemove;
            }
            else if (!KEYBOARD_press(DIK_A) && KEYBOARD_press(DIK_D)) { // �E�ړ�
                if (KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_S))player->dynamic_obj.object.vecRotation.y = cam_rot.y - D3DX_PI * 0.75f;
                else if (!KEYBOARD_press(DIK_W) && KEYBOARD_press(DIK_S))player->dynamic_obj.object.vecRotation.y = cam_rot.y - D3DX_PI * 0.25f;
                else player->dynamic_obj.object.vecRotation.y = cam_rot.y - D3DX_PI * 0.50f;
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y) * valuemove;
            }
            else if (KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_S)) {
                player->dynamic_obj.object.vecRotation.y = cam_rot.y + D3DX_PI;
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y) * valuemove;
            }
            else if (!KEYBOARD_press(DIK_W) && KEYBOARD_press(DIK_S)) {
                player->dynamic_obj.object.vecRotation.y = cam_rot.y;
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y) * valuemove;
            }
        }
        else {
            if (KEYBOARD_press(DIK_W)) {
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y) * valuemove;
            }
            if (KEYBOARD_press(DIK_A)) {
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y - D3DX_PI * 0.5f) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y - D3DX_PI * 0.5f) * valuemove;
            }
            if (KEYBOARD_press(DIK_S)) {
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y + D3DX_PI) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y + D3DX_PI) * valuemove;
            }
            if (KEYBOARD_press(DIK_D)) {
                player->dynamic_obj.move.x += sinf(player->dynamic_obj.object.vecRotation.y + D3DX_PI * 0.5f) * valuemove;
                player->dynamic_obj.move.z += cosf(player->dynamic_obj.object.vecRotation.y + D3DX_PI * 0.5f) * valuemove;
            }
        }

        if (valuemove == VALUE_MOVE)
            PLAYER_STATE_set(PLAYER_STATE_WALK);

        if (player->dynamic_obj.flight == false && LEFTSTICK_get().x == 0.0f && LEFTSTICK_get().y == 0.0f &&
            !KEYBOARD_press(DIK_W) && !KEYBOARD_press(DIK_A) && !KEYBOARD_press(DIK_S) && !KEYBOARD_press(DIK_D)) {
            PLAYER_STATE_set(PLAYER_STATE_WAIT);
        }

    }

    //�W�����v
    if (player->dynamic_obj.flight == false) {
        if ((KEYBOARD_press(DIK_SPACE) || GAMEPAD_ispress(0, BUTTON_X))) {
            PLAYER_STATE_set(PLAYER_STATE_JUMP);
        }
    }
    else {
        if (player->dynamic_obj.move.y >= FALLSPEED_MAX) {//�d��
            int currenttime = clock();                                 // ���݂̎���(�~���b�P��)
            player->dynamic_obj.flightTime = (float)(currenttime - previoustime);  // �؋󎞊ԉ��Z(�~���b�P��)
            player->dynamic_obj.move.y -= VALUE_GRAVITY * player->dynamic_obj.flightTime / 15000;       // �d�͉��Z(�d�͉����x*�؋󎞊�)
        }
    }

    if (PLAYER_STATE_get() == PLAYER_STATE_SHOT) player->dynamic_obj.move.y *= 0.9f;

    if (PLAYER_STATE_get() != PLAYER_STATE_RUN && PLAYER_STATE_get() != PLAYER_STATE_HOVER && PLAYER_STATE_get() != PLAYER_STATE_SHOT) {
        if (player->dynamic_obj.flight == false) {
            if (KEYBOARD_press(DIK_LCONTROL));
            else {
                if (player->dynamic_obj.hovergage < 1.0f) player->dynamic_obj.hovergage += 1.0f / FRAME_HOVER_RECOVERY * 0.25f;
                if (player->dynamic_obj.hovergage >= 1.0f) player->dynamic_obj.hovergage = 1.0f;
                player->dynamic_obj.flightTime = 0.0f;
                PLAYER_ACTION_settime();
            }
        }
        else {
            if (player->dynamic_obj.move.y < 0.0f) {
                PLAYER_STATE_set(PLAYER_STATE_FALL);
            }
        }
    }

    if (KEYBOARD_press(DIK_G) || GAMEPAD_ispress(0, BUTTON_O)) {
        PLAYER_STATE_set(PLAYER_STATE_GETITEM);
    }
}


/*===========================================================================================================*/
//�W�����v
void PLAYER_ACTION_jump(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    player->move.x *= 0.4f;
    player->move.z *= 0.4f;
    player->move.y = VALUE_JUMP;
    player->flightTime = 0.0f;
    player->flight = true;
    PLAYER_ACTION_settime();
    PLAYER_STATE_set(PLAYER_STATE_RISE);
}

/*===========================================================================================================*/
//�W�����v�㏸
void PLAYER_ACTION_rise(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    D3DXVECTOR3 cam_rot = CAMERA_getrot();

    if (player->move.y < 0) {
        PLAYER_STATE_set(PLAYER_STATE_FALL);
    }
}

/*===========================================================================================================*/
//����    
void PLAYER_ACTION_fall(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    D3DXVECTOR3 cam_rot = CAMERA_getrot();

    static bool se = false;

    if (player->flight == false) {
        if (player->flightTime > 2000)
            PLAYER_STATE_set(PLAYER_STATE_LAND);
        else
            PLAYER_STATE_set(PLAYER_STATE_WAIT);
    }

    if (player->hovergage > 0) {
        if ((KEYBOARD_press(DIK_SPACE) || GAMEPAD_ispress(0, BUTTON_X))) {
            PLAYER_STATE_set(PLAYER_STATE_HOVER);
        }
    }
}

/*===========================================================================================================*/
//�z�o�[
void PLAYER_ACTION_hover(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    player->move.x *= 0.8f;
    player->move.z *= 0.8f;

    if (player->move.y < 0.0f) player->move.y = 0;
    player->move.y += VALUE_HOVER;
    player->hovergage -= 1.0f / FRAME_HOVER;
    PLAYER_ACTION_settime();             // ���݂̎���(�~���b�P��)

    PLAYER_STATE_set(PLAYER_STATE_FALL);

}

/*===========================================================================================================*/
//���n
void PLAYER_ACTION_land(void) {
    PLAYER_resetmove();
    static int intervalframe = 0;
    intervalframe++;
    if (intervalframe >= INTERVALFRAME) {
        PLAYER_STATE_set(PLAYER_STATE_WAIT);
        intervalframe = 0;
    }

}

/*===========================================================================================================*/
//�^�[�Q�b�g���b�N�I��
void PLAYER_ACTION_aim(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    OBJECT* target = TARGET_get();          //�^�[�Q�b�g
    D3DXVECTOR3 camera_target;                 //�J��������^�[�Q�b�g�܂ł̃x�N�g��
    D3DXVECTOR3 vec_p_t;
    D3DXVECTOR3 cameraR;                       //�J�����̌����̃x�N�g��
    D3DXVECTOR3 tmp_targetpos;
    D3DXVECTOR3 outcamera_target;
    float targetangle = 5;
    float outtargetangle_xz = 5;
    float outtargetangle_y = 5;
    player->lockon = false;

    //�J�����̌����̃x�N�g���쐬
    D3DXVec3Subtract(&cameraR, &CAMERA_getregard(), &CAMERA_getpos());
    D3DXVECTOR2 nor2;
    D3DXVECTOR3 nor4;
    nor2.x = cameraR.x;
    nor2.y = cameraR.z;
    D3DXVec2Normalize(&nor2, &nor2);
    D3DXVec3Normalize(&nor4, &cameraR);
    for (int i = 0; i < MAX_TARGET; i++) {
        if ((target + i)->isuse) {

            //�v���C���[����^�[�Q�b�g�܂ł̃x�N�g���쐬
            D3DXVec3Subtract(&camera_target, &(target + i)->vecPosition, &CAMERA_getpos());
            D3DXVec3Subtract(&vec_p_t, &(target + i)->vecPosition, &player->object.vecPosition);

            if (D3DXVec3LengthSq(&vec_p_t) > powf(ARM_RANGE_MIN, 2) &&
                D3DXVec3LengthSq(&vec_p_t) < powf(ARM_RANGE_MAX, 2)) {

                //XZ���ʏ�̊p�x�v�Z
                D3DXVECTOR2 nor1;

                nor1.x = camera_target.x;
                nor1.y = camera_target.z;

                //���K��
                D3DXVec2Normalize(&nor1, &nor1);

                float cxz = D3DXVec2Dot(&nor1, &nor2);
                float anglexz = (float)acos(cxz);

                D3DXVECTOR3 nor3;

                D3DXVec3Normalize(&nor3, &camera_target);

                //Y�����̊p�x�v�Z
                float angley = atanf((nor3.y - nor4.y));

                D3DXVec3Subtract(&camera_target, &(target + i)->vecPosition, &CAMERA_getpos());

                if (anglexz < XZ_RANGE && anglexz < targetangle) {
                    if (angley < Y_RANGE) {
                        D3DXVECTOR3 no;
                        for (int j = 0; j < XCUBE_get_num() + 1; j++) {
                            if (j >= XCUBE_get_num()) {
                                targetpos = (target + i)->vecPosition;
                                targetangle = anglexz;
                                player->lockon = true;
                                Taget_rockon_num = i;
                                break;
                            }
                            if (COLLISION_BOX_vsline(PLAYER_get(), &(CUBE_get() + j)->object, player->object.vecPosition, (target + i)->vecPosition, &no)) break;
                        }
                    }
                }
                else {
                    if (angley < outtargetangle_y) {
                        if (anglexz < outtargetangle_xz) {
                            outtargetangle_xz = anglexz;
                            outtargetangle_y = angley;
                            outcamera_target = camera_target;
                        }
                    }
                }
            }
        }
    }
    GUIDE_setpos(GUIDE_NONE);

    if (player->lockon) {
        if (GAMEPAD_istrigger(0, BUTTON_R2) || KEYBOARD_trigger(DIK_RSHIFT)) {
            player->targetpos = targetpos;
            D3DXVECTOR3 tmp;
            D3DXVec3Subtract(&tmp, &player->targetpos, &player->object.vecPosition);
            //player->object.vecRotation.y = atan2f(tmp.x, tmp.z);
            PLAYER_STATE_set(PLAYER_STATE_SHOT);
            ARM_setgoalpos();
        }
    }
    else {
        if (outtargetangle_xz != 5) {
            if (outtargetangle_y > Y_RANGE) {
                D3DXVECTOR3 tmp_target_camR;
                D3DXVec3Subtract(&tmp_target_camR, &outcamera_target, &nor4);
                if (tmp_target_camR.y > 0.0f)
                    GUIDE_setpos(GUIDE_UP);
            }
            else {
                D3DXVECTOR3 tmpcross;
                cameraR.y = 0.0f;
                camera_target.y = 0.0f;
                D3DXVec3Cross(&tmpcross, &cameraR, &camera_target);
                if (tmpcross.y < 0.0f)
                    GUIDE_setpos(GUIDE_LEFT);
                else
                    GUIDE_setpos(GUIDE_RIGHT);
            }
        }
    }
}

/*===========================================================================================================*/
//��l��
void PLAYER_ACTION_fpaim(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    D3DXVECTOR3 tmp_col_pos;
    float length = powf(ARM_RANGE_MAX, 2);
    player->lockon = false;

    for (int j = 0; j < XCUBE_get_num(); j++) {
        if (COLLISION_BOX_vsline(PLAYER_get(), &(CUBE_get() + j)->object, PLAYER_getpos(), CAMERA_getregard(), &tmp_col_pos)) {
            D3DXVECTOR3 player_col_pos;
            D3DXVec3Subtract(&player_col_pos, &tmp_col_pos, &PLAYER_getpos());
            DebugProc_Print("�������Ă�\n%f3\n", D3DXVec3LengthSq(&player_col_pos));
            if (length > D3DXVec3LengthSq(&player_col_pos)) {
                targetpos = tmp_col_pos;
                length = D3DXVec3LengthSq(&player_col_pos);
                player->lockon = true;
            }
        }
    }

    if (player->lockon) {
        if (GAMEPAD_istrigger(0, BUTTON_R2) || KEYBOARD_trigger(DIK_RSHIFT)) {
            player->targetpos = targetpos;
            PLAYER_resetmove();
            PLAYER_STATE_set(PLAYER_STATE_SHOT);
            ARM_setgoalpos();
        }
    }

    if (PLAYER_STATE_get() != PLAYER_STATE_SHOT) {
        if (KEYBOARD_release(DIK_LSHIFT) || GAMEPAD_isrelease(0, BUTTON_L2)) {
            player->fpaim = false;
        }
    }
}

/*===========================================================================================================*/
//�t�b�N�V���b�g�ړ�
void PLAYER_ACTION_hookmove(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    static int frame = 0;
    frame++;
    player->fpaim = false;
    D3DXVECTOR3 tmpvec;
    PLAYER_ACTION_sethookmove();

    player->move = player_target * VALUE_HOOKMOVE;
    D3DXVec3Subtract(&tmpvec, &(player->targetpos), &(player->object.vecPosition));
    if (D3DXVec3LengthSq(&tmpvec) <= 500 || frame >= ARM_FRAME_MAX) {
        frame = 0;
        PLAYER_ACTION_settime();
        PLAYER_STATE_set(PLAYER_STATE_RISE);
    }
}

void PLAYER_ACTION_swing(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    player->fpaim = false;
    static int frame = 0;
    D3DXVECTOR3 tmpvec;
    D3DXVECTOR3 gravity = D3DXVECTOR3(0, -0.25f, 0);
    PLAYER_ACTION_sethookmove();
    D3DXVECTOR3 tension = player_target * 0.25f;

    tmpvec = gravity + tension;

    D3DXVECTOR3 tmp = *D3DXVec3Cross(&tmp, &gravity, &tension);
    D3DXVECTOR3 tmpv = tmp * D3DXVec3Dot(&tmp, &player->move) / D3DXVec3Length(&tmp) / D3DXVec3Length(&tmp);

    if (player->conflict == true)
        player->move.y *= 0.9f;

    player->move = tmpvec * D3DXVec3Dot(&tmpvec, &player->move) / D3DXVec3Length(&tmpvec) / D3DXVec3Length(&tmpvec);
    player->move += tmpvec + tmpv;
    player->move *= 0.999f;

    frame++;

    player->object.vecRotation.y = atan2f(player->move.x, player->move.z);

    if (!KEYBOARD_press(DIK_RSHIFT) && !GAMEPAD_ispress(0, BUTTON_R2)) {
        PLAYER_ACTION_settime();
        if (frame >= 20) PLAYER_STATE_set(PLAYER_STATE_RISE);
        else PLAYER_STATE_set(PLAYER_STATE_HOOKMOVE);
        frame = 0;
    }
    if (KEYBOARD_press(DIK_SPACE) || GAMEPAD_ispress(0, BUTTON_A)) {
        PLAYER_STATE_set(PLAYER_STATE_HOOKMOVE);
        frame = 0;
    }

    D3DXVECTOR3 tmp_col_pos;
    for (int i = 0; i < XCUBE_get_num(); i++) {
        if (COLLISION_BOX_vsline(PLAYER_get(), &(CUBE_get() + i)->object, player->object.vecPosition, player->targetpos, &tmp_col_pos)) {
            if (player->targetpos != tmp_col_pos) {
                PLAYER_STATE_set(PLAYER_STATE_RISE);
                break;
            }
        }

    }

    DebugProc_Print("Move/X:%f/Y:%f/Z:%f", player->move.x, player->move.y, player->move.z);
}

/*===========================================================================================================*/
void PLAYER_ACTION_settime(void) {
    previoustime = clock();
}

/*===========================================================================================================*/
D3DXVECTOR3 PLAYER_ACTION_gettargetpos(void) {
    return targetpos;
}

/*===========================================================================================================*/
void PLAYER_ACTION_sethookmove(void) {
    DYNAMIC_OBJECT* player = PLAYER_get();
    D3DXVec3Subtract(&player_target, &(player->targetpos), &(player->object.vecPosition));
    D3DXVec3Normalize(&player_target, &player_target);
    frame = 0;
}

int PLAYER_ACTION_GET_TARGET_NUM(void) {
    return Taget_rockon_num;
}

// �A�C�e���̓���
void PLAYER_ACTION_getitem(void) {

    DYNAMIC_OBJECT* player = PLAYER_get();                     //�@�v���C���[���
    ITEM_OBJECT* item_object = ITEM_get_obtained();            //�@�A�C�e���̃I�u�W�F�N�g���擾

    for (int i = 0; i < ITEM_INDEX_MAX; i++)
        if (item_object[i].object.isuse) {
            item_object[i].object.objColBox[0].detection = false;
            if (COLLISION_BOX_trigger(player, &item_object[i].object)) {
                // PlaySound(SOUND_LABEL_SE_HIT);
                item_object[i].object.objColBox[0].detection = true;
                item_object[i].object.isuse = false;
                ITEM_acquisition(item_object[i].Item);
            }
        }

    PLAYER_STATE_set(PLAYER_STATE_WALK);
}