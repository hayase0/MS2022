/*==============================================================================
    DirectX9_HEW_ROC
    [chain.cpp]
    �E��
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_23-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "direct3d.h"
#include "player.h"
#include "ARM.h"


LPDIRECT3DVERTEXBUFFER9 g_pvtxbuffline = NULL;	// ���_�o�b�t�@�ւ̃|�C���^
D3DXMATRIX				g_mtxworldline;

void CHAIN_initialize(void) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    pDevice->CreateVertexBuffer(sizeof(VERTEX_3D) * 3,
                                D3DUSAGE_WRITEONLY,
                                FVF_VERTEX_3D,
                                D3DPOOL_MANAGED,
                                &g_pvtxbuffline,
                                NULL);
}
void CHAIN_finalize(void) {
    if (g_pvtxbuffline != NULL) {// ���_�o�b�t�@�̊J��
        g_pvtxbuffline->Release();
        g_pvtxbuffline = NULL;
    }
}
void CHAIN_update(void) {

    VERTEX_3D *pVtx;

    g_pvtxbuffline->Lock(0, 0, (void**)&pVtx, 0);

    pVtx[0].pos = PLAYER_getpos();

    pVtx[0].pos.y += 37.0f;
    
    pVtx[1].pos = ARM_getpos();

    pVtx[0].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
    pVtx[1].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f);

    pVtx[0].col = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
    pVtx[1].col = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);

    g_pvtxbuffline->Unlock();

    D3DXMATRIX mtxScl, mtxRot, mtxTranslate;

    D3DXMatrixIdentity(&g_mtxworldline);
    D3DXMatrixScaling(&mtxScl, 1, 1, 1);
    D3DXMatrixMultiply(&g_mtxworldline, &g_mtxworldline, &mtxScl);

    D3DXMatrixRotationYawPitchRoll(&mtxRot, 0, 0, 0);
    D3DXMatrixMultiply(&g_mtxworldline, &g_mtxworldline, &mtxRot);


}
void CHAIN_draw(void) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    pDevice->SetTransform(D3DTS_WORLD, &g_mtxworldline);

    pDevice->SetStreamSource(0, g_pvtxbuffline, 0, sizeof(VERTEX_3D));

    pDevice->SetFVF(FVF_VERTEX_3D);

    pDevice->DrawPrimitive(D3DPT_LINELIST, 0, 2);
}