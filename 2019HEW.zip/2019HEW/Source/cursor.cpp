/*==============================================================================
    DirectX9_HEW_ROC
    [cursor.cpp]
    �E���O���͉�ʂ̃J�[�\��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2020_01_20-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "texture.h"
#include "sprite.h"

#include "cursor.h"

#include "keyboard.h"

static CURSOR Cursor;
static CURSOR_STATE Cursor_state;

/*============================================================================*/

static void neutral(void) {

}
static void up(void) {

}
static void down(void) {

}
static void left(void) {

    Cursor.pos += D3DXVECTOR2(-75.0f, 0.0f);
}
static void right(void) {

    Cursor.pos += D3DXVECTOR2(75.0f, 0.0f);
}
static void decide(void) {
    
}

void(*cursor_function[CURSOR_STATE_MAX])(void) = {
    neutral,up,down,left,right,decide
};


/*============================================================================*/
void CURSOR_initialize(void) {
    Cursor.pos = D3DXVECTOR2(150.0f, 200.0f);
    Cursor.rot = D3DXVECTOR2(0.0f, 0.0f);
    Cursor.scale = D3DXVECTOR2(100.0f, 100.0f);
    Cursor.color = D3DCOLOR_RGBA(255, 0, 0, 255);
    Cursor.speed = 0.0f;
    Cursor.word.num_x = 0;
    Cursor.word.num_y = 0;

    Cursor_state = CURSOR_STATE_NEUTRAL;
}
void CURSOR_finalize(void) {

}
void CURSOR_update(void) {
    
    //--�X�e�[�g�̑I��------------
    Cursor_state = CURSOR_STATE_NEUTRAL;

    if (KEYBOARD_trigger(DIK_W)) {
        Cursor_state = CURSOR_STATE_UP;
    }
    if (KEYBOARD_trigger(DIK_A)) {
        Cursor_state = CURSOR_STATE_LEFT;
    }
    if (KEYBOARD_trigger(DIK_S)) {
        Cursor_state = CURSOR_STATE_DOWN;
    }
    if (KEYBOARD_trigger(DIK_D)) {
        Cursor_state = CURSOR_STATE_RIGHT;
    }
    if (KEYBOARD_trigger(DIK_SPACE)) {
        Cursor_state = CURSOR_STATE_DECIDE;
    }
    //----------------------------

    cursor_function[Cursor_state]();

    
}
void CURSOR_draw(void) {
    SPRITE_draw(TEXTURE_INDEX_CURSOR, Cursor.pos.x, Cursor.pos.y, Cursor.scale.x, Cursor.scale.y, Cursor.color);
}
