/*==============================================================================
    DirectX9_HEW_ROC
    [ARM.h]
    �E�t�b�N�V���b�g
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_16-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include "animation.h"

void ARM_initialize(void);
void ARM_update(void);
void ARM_draw(void);
void ARM_shot(void);

void ARM_setgoalpos(void);
ANIMATION_OBJECT* ARM_get(void);
D3DXVECTOR3 ARM_getpos(void);

