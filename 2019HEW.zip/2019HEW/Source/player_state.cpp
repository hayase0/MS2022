/*==============================================================================
    DirectX9_HEW_ROC
    [player_state.cpp]
    �E�v���C���[��ԊǗ�
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI (THS_AT12C342_21_85004)  /  2019_11_20-
================================================================================
    �X�V����


/*============================================================================*/
#include "main.h"
#include "keyboard.h"
#include "player.h"
#include "player_action.h"
#include "ARM.h"
#include "player_state.h"
#include "fall.h"
#include "animation.h"
#include "arm.h"

/*============================================================================*/
static PLAYER_STATE state = PLAYER_STATE_WAIT;
static int stopframe = 0;
static bool wait = false;
static int motiontype = 0;
/*============================================================================*/
static void wait_update() {
    PLAYER_ACTION_wait();
    PLAYER_ACTION_aim();

    ANIMATION_OBJECT *panim = PLAYER_animget();
    ANIMATION_OBJECT *armanim = ARM_get();

    if (wait == false) {
        stopframe++;
        ANIMATION_set(panim, ANIMATION_INDEX_PLAYER_WAIT);
        ANIMATION_set(armanim, ANIMATION_INDEX_PLAYERARM_WAIT);
    }

    if (stopframe == 300) {
        if (motiontype == 0)
            motiontype = 1;
        else
            motiontype = 0;
    }

    if (stopframe > 300) {
        wait = true;
        stopframe = 0;
        if (motiontype == 0) {
            ANIMATION_set(panim, ANIMATION_INDEX_PLAYER_WAIT1);
            ANIMATION_set(armanim, ANIMATION_INDEX_PLAYERARM_WAIT1);
        }
        else {
            ANIMATION_set(panim, ANIMATION_INDEX_PLAYER_WAIT2);
            ANIMATION_set(armanim, ANIMATION_INDEX_PLAYERARM_WAIT2);
        }
    }
}
static void walk_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
    PLAYER_ACTION_aim();
    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_WALK);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_WALK);
}
static void run_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
    PLAYER_ACTION_aim();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_RUN);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_RUN);

}
static void jump_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_jump();
    PLAYER_ACTION_aim();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_JUMP);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_JUMP);
}
static void rise_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
    PLAYER_ACTION_rise();
    PLAYER_ACTION_aim();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_JUMP);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_JUMP);
}
static void fall_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
    PLAYER_ACTION_fall();
    PLAYER_ACTION_aim();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_JUMP);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_JUMP);
}
static void hover_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
    PLAYER_ACTION_hover();
    PLAYER_ACTION_aim();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_JUMP);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_JUMP);
}
static void land_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_land();
}
static void fpaim_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
}
static void shot_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_move();
    ARM_shot();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_SHOT);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_SHOT);
}
static void hookmove_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_hookmove();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_SHOT);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_SHOT);
}
static void swing_update(void) {
    PLAYER_STATE_lifted();
    PLAYER_ACTION_swing();
    PLAYER_ACTION_aim();

    ANIMATION_set(PLAYER_animget(), ANIMATION_INDEX_PLAYER_SHOT);
    ANIMATION_set(ARM_get(), ANIMATION_INDEX_PLAYERARM_SHOT);
}
static void getitem_update(void) {
    PLAYER_ACTION_getitem();
}
/*----------------------------------------------------------------------------*/
// �V�[���֐��|�C���^�f�[�^�^����
typedef void(*state_function)(void);

// �֐��z��
static const state_function update[] = {
    wait_update,
    walk_update,
    run_update,
    jump_update,
    rise_update,
    fall_update,
    hover_update,
    land_update,
    fpaim_update,
    shot_update,
    hookmove_update,
    swing_update,
    getitem_update,
};

/*============================================================================*/
// ���݂�State�̊֐����Ăяo���֐�
void PLAYER_STATE_update(void) { update[state](); }

// getter
PLAYER_STATE PLAYER_STATE_get(void) { return state; }
// setter
void PLAYER_STATE_set(PLAYER_STATE nextstate) { state = nextstate; }

void PLAYER_STATE_lifted(void) {
    wait = false;
    stopframe = 0;
}