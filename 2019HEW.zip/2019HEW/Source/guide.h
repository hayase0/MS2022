/*==============================================================================
    DirectX9_HEW_ROC
    [guide.h]
    �E�K�C�h
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_12_15-2019_12_
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

enum GUIDE_POS {
    GUIDE_NONE,
    GUIDE_UP,
    GUIDE_DOWN,
    GUIDE_LEFT,
    GUIDE_RIGHT,
};

void GUIDE_initialize(void);
void GUIDE_finalize(void);
void GUIDE_update(void);
void GUIDE_draw(void);
void GUIDE_setpos(GUIDE_POS pos);
