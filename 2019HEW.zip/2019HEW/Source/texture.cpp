/*==============================================================================
    DirectX9_HEW_ROC
    [texture.cpp]
    �E�e�N�X�`���[
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_20-
================================================================================
    �X�V����
        2019_11_09  �}�X�^�ł̑J�ڗp�Ƀe�X�g�p�摜�����܂����B

/*============================================================================*/
#include "main.h"
#include "direct3d.h"
#include "texture.h"

#define TEXTURE_FILENAME_MAX (64)

typedef struct TextureFile_tag {
    char filename[TEXTURE_FILENAME_MAX];
    int width;
    int height;
} TextureFile;

static const TextureFile g_TextureFiles[] = {
    { "Asset/Texture/item_frame.png", 100,100},
    { "Asset/Texture/item_building1.png", 100,100},
    { "Asset/Texture/item_monkey.png", 100,100},
    { "Asset/Texture/Building_object/CocoonTowerIcon.jpg", 100,100},
    { "Asset/Texture/Building_object/BigSightIcon.jpg", 100,100},
    { "Asset/Texture/Building_object/GovernmentOfficeIcon.jpg", 100,100},
    { "Asset/Texture/Building_object/NationalStadiumIcon.jpg", 100,100},

    { "Asset/Texture/Ui/character.png", 1024,1024},

    { "Asset/Texture/square_frame.jpg", 160,160},
    { "Asset/Texture/ground_available.jpg", 160,160},
    { "Asset/Texture/ground_unavailable.jpg", 160,160},

    { "Asset/test/1logo.png", 1920, 1080 },
    { "Asset/test/2title.png", 1920, 1080 },
    { "Asset/test/3demo.png", 1920, 1080 },
    { "Asset/test/4tutorial.png", 1920, 1080 },
    { "Asset/test/5explore.png", 1920, 1080 },
    { "Asset/test/6name.png", 1920, 1080 },
    { "Asset/test/7haiti.png", 1920, 1080 },
    { "Asset/test/8owari.png", 1920, 1080 },

    { "Asset/test/arise.png", 600,600},
    { "Asset/test/fall.png", 600,600},
    { "Asset/test/complete.png", 600,600},
    { "Asset/test/navigator.png", 600,600},
    { "Asset/test/map.png", 600,600},
    { "Asset/test/pause.png", 600,600},
    { "Asset/test/moving object.jpg", 100,100},

    { "Asset/Texture/background.png", 1024, 1024},
    { "Asset/Texture/background_side.png", 1, 1},
    { "Asset/Texture/background_top.png", 2048, 2048},
    { "Asset/Texture/background_top.png", 2048, 2048},

    { "Asset/Texture/Ui/gauge_empty.png", 256,16},
    { "Asset/Texture/Ui/gauge_full.png", 248,10},

    { "Asset/Texture/floatmatter.png", 64,64},
    { "Asset/Texture/guide.png", 400,220},

    { "Asset/Texture/shadow.png",256,256},

    { "Asset/Texture/Stage_object/stage_001.png",256,256},
    { "Asset/Texture/Stage_object/stage_002.png",256,256},
    { "Asset/Texture/Stage_object/testwall.jpg",256,256},

    { "Asset/Texture/Ui/cursor.png", 64,64},

};

static const int TEXTURE_FILE_COUNT = sizeof(g_TextureFiles) / sizeof(g_TextureFiles[0]);

static_assert(TEXTURE_INDEX_MAX == TEXTURE_FILE_COUNT, "TEXTURE_INDEX_MAX != TEXTURE_FILE_COUNT");

static LPDIRECT3DTEXTURE9 g_pTextures[TEXTURE_FILE_COUNT] = {};

int TEXTURE_load(void) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) {
        return TEXTURE_FILE_COUNT;
    }

    int failed_count = 0;

    for (int i = 0; i < TEXTURE_FILE_COUNT; i++) {
        if (FAILED(D3DXCreateTextureFromFile(pDevice, g_TextureFiles[i].filename, &g_pTextures[i]))) {
            // DebugPrintf("�e�N�X�`���̓ǂݍ��݂Ɏ��s ... %s\n", g_TextureFiles[i].filename);
            failed_count++;
        }
    }

    return failed_count;
}

void TEXTURE_release(void) {
    for (int i = 0; i < TEXTURE_FILE_COUNT; i++) {
        if (g_pTextures[i]) {
            g_pTextures[i]->Release();
            g_pTextures[i] = NULL;
        }
    }
}

LPDIRECT3DTEXTURE9 TEXTURE_get_texture(TEXTURE_INDEX index) {
    if (index < 0 || index >= TEXTURE_INDEX_MAX) return NULL;
    return g_pTextures[index];
}

int TEXTURE_get_width(TEXTURE_INDEX index) {
    if (index < 0 || index >= TEXTURE_INDEX_MAX) return NULL;
    return g_TextureFiles[index].width;
}

int TEXTURE_get_height(TEXTURE_INDEX index) {
    if (index < 0 || index >= TEXTURE_INDEX_MAX) return NULL;
    return g_TextureFiles[index].height;
}
