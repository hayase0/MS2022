/*==============================================================================
    DirectX9_HEW_ROC
    [transition.h]
    �E��ʑJ��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_28-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

// �g�����W�V������Ԍ^��`
enum TRANSITION_STATE {
    TRANSITION_NONE,
    FADE_IN, FADE_OUT, DISSOLVE, SLIDE, IRIS, WIPE
};

// �v���g�^�C�v�錾
void TRANSITION_initialize(void);
void TRANSITION_finalize(void);
void TRANSITION_update(void);
void TRANSITION_draw(void);

void TRANSITION_set(TRANSITION_STATE, int transition_time = 0);
bool TRANSITION_check(void);

int TRANSITION_get_time(void);