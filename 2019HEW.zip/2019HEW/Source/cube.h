/*==============================================================================
    DirectX9_HEW_ROC
    [cube.h]
    �E�L���[�u
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_12_20-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once
#include "texture.h"

#define MAX_CUBE    (512)
#define CUBE_B_Y    (512)
#define CUBE_W_Y    (512)

//�L���[�u�\����
struct CUBE {
    OBJECT object;
    LPDIRECT3DVERTEXBUFFER9  VtxBuff = NULL;
    TEXTURE_INDEX texture_index;
};

void CUBE_initialize(void);
void CUBE_finalize(void);
void CUBE_draw(void);
CUBE *CUBE_get(void);
int CUBE_get_num(void);