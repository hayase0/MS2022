/*==============================================================================
    DirectX9_HEW_ROC
    [target.h]
    �E�^�[�Q�b�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA THS_AT12C342_36_80299) / 2020_01_19-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#define MAX_TARGET          (512)
#define TARGET_VERTEX_NUM   (8)
#define TARGET_POLYGON_NUM  (6)

// 3D�|���S�����_�t�H�[�}�b�g
#define TARGET_FVF_3D (D3DFVF_XYZ | D3DFVF_DIFFUSE)

struct TARGET_VERTEX {
    D3DXVECTOR3 pos;                            // ���_���W
    D3DCOLOR    col;                            // ���_�J���[
    LPDIRECT3DVERTEXBUFFER9 buf = NULL;         // �o�b�t�@
};


void TARGET_initialize(void);
void TARGET_finalize(void);
void TARGET_update(void);
void TARGET_draw(void);

OBJECT *TARGET_get(void);
