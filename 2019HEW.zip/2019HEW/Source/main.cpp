/*==============================================================================
    DirectX9_HEW_ROC
    [main.cpp]
    �E���C��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_28-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "texture.h"
#include "window.h"
#include "direct3d.h"

#include "debugproc.h"
 
#include "light.h"
#include "keyboard.h"
#include "gamepad.h"

#include "transition.h"

#include "scene.h"

/*============================================================================*/
static bool Initialize(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    if (!WINDOW_initialize(hInstance, hPrevInstance, lpCmdLine, nCmdShow)) return false;
    if (!DIRECT3D_initialize()) return false;
    if (!KEYBOARD_initialize(hInstance, WINDOW_get_hwnd())) return false;
    if (!GAMEPAD_initialize(hInstance, WINDOW_get_hwnd())) return false;

    DebugProc_Initialize();

    TEXTURE_load();
    
    if (!MESH_initialize()) return false;
       
    LIGHT_initialize();

    TRANSITION_initialize();

    SCENE_initialize();

    return true;
}

static void Finalize(void) {
    SCENE_finalize();

    DebugProc_Finalize();
    MESH_release();
    TEXTURE_release();

    KEYBOARD_finalize();
    GAMEPAD_finalize();
    DIRECT3D_finalize();
}

static void Update(void) {
    SCENE_update();
    KEYBOARD_update();
    GAMEPAD_update();
    TRANSITION_update();
}

static void Draw(void) {
    DIRECT3D_begin(); // ��ʃN���A�ƕ`��o�b�`���ߊJ�n


    DebugProc_Draw();

    SCENE_draw();

    TRANSITION_draw();

    DIRECT3D_end();   // �`��o�b�`���ߏI���ƃo�b�N�o�b�t�@�t���b�v

}

/*============================================================================*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {

    if (!Initialize(hInstance, hPrevInstance, lpCmdLine, nCmdShow)) return -1;

    MSG msg = {};

    while (WM_QUIT != msg.message) {
        if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessage(&msg);
        }
        else {
            Update();
            Draw();
        }
    }

    Finalize();

    return (int)msg.wParam;
}
