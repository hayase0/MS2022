
/*==============================================================================
    DirectX9_HEW_ROC
    [cube.cpp]
    �E�w�i
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_21_85004) / 2019_11_25-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "camera.h"
#include "direct3d.h"
#include "light.h"
#include "cube.h"
#include "collision_box.h"
#include "stage_f.h"

#define NUM_POLYGON     (16)       // �|���S����
#define NUM_MASU_X      (2)        // �}�X�ڐ�x
#define NUM_MASU_Y      (2)        // �}�X�ڐ�y
#define NUM_MASU_Z      (2)        // �}�X�ڐ�z
#define SIZE_X          (100.0f)
#define SIZE_Y          (100.0f)
#define SIZE_Z          (100.0f)

static LPDIRECT3DINDEXBUFFER9 IdxBuff = NULL;	// �C���f�b�N�X�o�b�t�@

static CUBE Cube[MAX_CUBE];
static int Cube_num = 0;    // ���������L���[�u�̐�

/*============================================================================*/
static void makevertex(void) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    for (int i = 0; i < Cube_num; i++) {
        if (Cube[i].object.isuse) {
            // ���_�f�[�^�쐬
            pDevice->CreateVertexBuffer(sizeof(VERTEX_3D) * 24, // ���_�f�[�^�p�Ɋm�ۂ���o�b�t�@�T�C�Y(�o�C�g�P��)
                                        D3DUSAGE_WRITEONLY,     // ���_�o�b�t�@�̎g�p�@
                                        FVF_VERTEX_3D,          // �g�p���钸�_�t�H�[�}�b�g
                                        D3DPOOL_MANAGED,        // ���\�[�X�̃o�b�t�@��ێ����郁�����N���X���m��
                                        &Cube[i].VtxBuff,               // ���_�o�b�t�@�C���^�[�t�F�[�X�ւ̃|�C���^
                                        NULL);                  // NULL�ɐݒ�

            {
                //���_�f�[�^��ύX���邽�߂̃|�C���^
                VERTEX_3D *pVtx;

                //���b�N(���_�f�[�^��VRAM���烁�����Ɏ����Ă���(���_�f�[�^��ύX�\�ɂ���))
                Cube[i].VtxBuff->Lock(0, 0, (void**)&pVtx, 0);

                //���_���W
                // �O��
                pVtx[0].pos = D3DXVECTOR3(-SIZE_X, SIZE_Y, -SIZE_Z);
                pVtx[1].pos = D3DXVECTOR3(SIZE_X, SIZE_Y, -SIZE_Z);
                pVtx[2].pos = D3DXVECTOR3(-SIZE_X, -SIZE_Y, -SIZE_Z);
                pVtx[3].pos = D3DXVECTOR3(SIZE_X, -SIZE_Y, -SIZE_Z);
                // ���
                pVtx[4].pos = D3DXVECTOR3(SIZE_X, SIZE_Y, SIZE_Z);
                pVtx[5].pos = D3DXVECTOR3(-SIZE_X, SIZE_Y, SIZE_Z);
                pVtx[6].pos = D3DXVECTOR3(SIZE_X, -SIZE_Y, SIZE_Z);
                pVtx[7].pos = D3DXVECTOR3(-SIZE_X, -SIZE_Y, SIZE_Z);
                // ����
                pVtx[8].pos = pVtx[1].pos;
                pVtx[9].pos = pVtx[4].pos;
                pVtx[10].pos = pVtx[3].pos;
                pVtx[11].pos = pVtx[6].pos;
                // �E��
                pVtx[12].pos = pVtx[5].pos;
                pVtx[13].pos = pVtx[0].pos;
                pVtx[14].pos = pVtx[7].pos;
                pVtx[15].pos = pVtx[2].pos;
                // ���
                pVtx[16].pos = pVtx[5].pos;
                pVtx[17].pos = pVtx[4].pos;
                pVtx[18].pos = pVtx[0].pos;
                pVtx[19].pos = pVtx[1].pos;
                // ����
                pVtx[20].pos = pVtx[2].pos;
                pVtx[21].pos = pVtx[3].pos;
                pVtx[22].pos = pVtx[7].pos;
                pVtx[23].pos = pVtx[6].pos;

                // �O��
                pVtx[0].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, 0.0f);
                pVtx[1].tex = D3DXVECTOR2(0.0f, 0.0f);
                pVtx[2].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, Cube[i].object.vecScale.y * NUM_MASU_Y);
                pVtx[3].tex = D3DXVECTOR2(0.0f, Cube[i].object.vecScale.y * NUM_MASU_Y);
                // ���
                pVtx[4].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, 0.0f);
                pVtx[5].tex = D3DXVECTOR2(0.0f, 0.0f);
                pVtx[6].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, Cube[i].object.vecScale.y * NUM_MASU_Y);
                pVtx[7].tex = D3DXVECTOR2(0.0f, Cube[i].object.vecScale.y * NUM_MASU_Y);
                // ����
                pVtx[8].tex = D3DXVECTOR2(Cube[i].object.vecScale.z * NUM_MASU_Z, 0.0f);
                pVtx[9].tex = D3DXVECTOR2(0.0f, 0.0f);
                pVtx[10].tex = D3DXVECTOR2(Cube[i].object.vecScale.z * NUM_MASU_Z, Cube[i].object.vecScale.y * NUM_MASU_Y);
                pVtx[11].tex = D3DXVECTOR2(0.0f, Cube[i].object.vecScale.y * NUM_MASU_Y);
                // �E��
                pVtx[12].tex = D3DXVECTOR2(Cube[i].object.vecScale.z * NUM_MASU_Z, 0.0f);
                pVtx[13].tex = D3DXVECTOR2(0.0f, 0.0f);
                pVtx[14].tex = D3DXVECTOR2(Cube[i].object.vecScale.z * NUM_MASU_Z, Cube[i].object.vecScale.y * NUM_MASU_Y);
                pVtx[15].tex = D3DXVECTOR2(0.0f, Cube[i].object.vecScale.y * NUM_MASU_Y);
                // ���
                pVtx[16].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, 0.0f);
                pVtx[17].tex = D3DXVECTOR2(0.0f, 0.0f);
                pVtx[18].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, Cube[i].object.vecScale.z * NUM_MASU_Z);
                pVtx[19].tex = D3DXVECTOR2(0.0f, Cube[i].object.vecScale.z * NUM_MASU_Z);
                // ����
                pVtx[20].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, 0.0f);
                pVtx[21].tex = D3DXVECTOR2(0.0f, 0.0f);
                pVtx[22].tex = D3DXVECTOR2(Cube[i].object.vecScale.x * NUM_MASU_X, Cube[i].object.vecScale.z * NUM_MASU_Z);
                pVtx[23].tex = D3DXVECTOR2(0.0f, Cube[i].object.vecScale.z * NUM_MASU_Z);

                for (int i = 0; i < 6; i++)
                    for (int j = 0; j < 4; j++) {
                        // �@���x�N�g��
                        if (i == 0)pVtx[i * 4 + j].nor = D3DXVECTOR3(0.0f, 0.0f, -1.0f); // �O��
                        else if (i == 1)pVtx[i * 4 + j].nor = D3DXVECTOR3(0.0f, 0.0f, 1.0f); // ���
                        else if (i == 2)pVtx[i * 4 + j].nor = D3DXVECTOR3(1.0f, 0.0f, 0.0f); // �E��
                        else if (i == 3)pVtx[i * 4 + j].nor = D3DXVECTOR3(-1.0f, 0.0f, 0.0f); // ����
                        else if (i == 4)pVtx[i * 4 + j].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f); // ���
                        else if (i == 5)pVtx[i * 4 + j].nor = D3DXVECTOR3(0.0f, -1.0f, 0.0f); // ����
                        // �J���[�ύX(RGBA)
                        pVtx[i * 4 + j].col = D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f);
                    }

                //�A�����b�N(���_�f�[�^������������VRAM�ɕԂ�(���_�f�[�^�ύX�s�ɂȂ�))
                Cube[i].VtxBuff->Unlock();
            }
        }
    }
}

static void generate_cube(D3DXVECTOR3 pos, D3DXVECTOR3 rot, D3DXVECTOR3 scl, TEXTURE_INDEX tx) {

    Cube[Cube_num].object.isuse = true;
    Cube[Cube_num].object.meshIndex = MESH_INDEX_STAGE_002; // �����蔻��p�B
    Cube[Cube_num].object.vecPosition = pos;
    Cube[Cube_num].object.vecRotation = rot;
    Cube[Cube_num].object.vecScale = scl;
    Cube[Cube_num].texture_index = tx;
    COLLISION_BOX_setting(&Cube[Cube_num].object);
    STAGE_F_set_collision_object(&Cube[Cube_num].object);

    for (int i = 0; i < NUM_MESH_BOX; i++)
        for (int k = 0; k < 6; k++)
            Cube[Cube_num].object.objColBox[i].faceUse[k] = true;

    Cube_num++;
}

static void cube_set(void) {

    STAGE_POS *stage_pos = STAGE_F_get_stage_pos();

    /* �e���v��
    {
        float x, y, z;
        x = stage_pos[STAGE_LUMP_000].x;
        y = stage_pos[STAGE_LUMP_000].y;
        z = stage_pos[STAGE_LUMP_000].z;

        generate_cube(D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                      D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                      D3DXVECTOR3(1.0f, 1.0f, 1.0f),
                      CUBE_TEXTURE_001);

    }
    */

    {
        float x, y, z;
        x = stage_pos[STAGE_LUMP_002].x;
        y = stage_pos[STAGE_LUMP_002].y;
        z = stage_pos[STAGE_LUMP_002].z;


        // ��
        generate_cube(D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z),
                      D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                      D3DXVECTOR3(20.0f, 1.0f, 20.0f),
                      CUBE_TEXTURE_001);

        // ��
        generate_cube(D3DXVECTOR3(0.0f + x, 1000.0f + y, 2000.0f + z),
                      D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                      D3DXVECTOR3(20.0f, 10.0f, 0.1f),
                      CUBE_TEXTURE_002);


    }

    {
        float x, y, z;
        x = stage_pos[STAGE_LUMP_003].x;
        y = stage_pos[STAGE_LUMP_003].y;
        z = stage_pos[STAGE_LUMP_003].z;


        // ��
        generate_cube(D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z),
                      D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                      D3DXVECTOR3(20.0f, 1.0f, 20.0f),
                      CUBE_TEXTURE_001);

        // ��
        generate_cube(D3DXVECTOR3(0.0f + x, 1000.0f + y, 2000.0f + z),
                      D3DXVECTOR3(0.0f, 0.0f, 0.0f),
                      D3DXVECTOR3(20.0f, 10.0f, 0.1f),
                      CUBE_TEXTURE_003);


    }


}

/*============================================================================*/

void CUBE_initialize(void) {

    // �L���[�u��z�u
    cube_set();

    //���_�f�[�^�쐬
    makevertex();

    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    pDevice->CreateIndexBuffer(sizeof(WORD) * 36,   // ���_�f�[�^�p�Ɋm�ۂ���o�b�t�@�T�C�Y(�o�C�g�P��)
                               D3DUSAGE_WRITEONLY,  // ���_�o�b�t�@�̎g�p�@
                               D3DFMT_INDEX16,      // �g�p����C���f�b�N�X�t�H�[�}�b�g
                               D3DPOOL_MANAGED,     // ���\�[�X�̃o�b�t�@��ێ����郁�����N���X���m��
                               &IdxBuff,            // �C���f�b�N�X�o�b�t�@�C���^�[�t�F�[�X�ւ̃|�C���^
                               NULL);

    {// �C���f�b�N�X�o�b�t�@�̒��g�𖄂߂�
        WORD *pIdx;

        IdxBuff->Lock(0, 0, (void**)&pIdx, 0);

        for (int i = 0; i < 6; i++) {
            pIdx[i * 6 + 0] = i * 4 + 1;
            pIdx[i * 6 + 1] = i * 4 + 3;
            pIdx[i * 6 + 2] = i * 4 + 0;
            pIdx[i * 6 + 3] = i * 4 + 0;
            pIdx[i * 6 + 4] = i * 4 + 3;
            pIdx[i * 6 + 5] = i * 4 + 2;
        }

        IdxBuff->Unlock();
    }
}

void CUBE_finalize(void) {
    if (IdxBuff != NULL) {// �C���f�b�N�X�o�b�t�@�̊J��
        IdxBuff->Release();
        IdxBuff = NULL;
    }
    for (int i = 0; i < MAX_CUBE; i++) {
        if (Cube[i].VtxBuff != NULL) {// ���_�o�b�t�@�̊J��
            Cube[i].VtxBuff->Release();
            Cube[i].VtxBuff = NULL;
        }
    }
}

void CUBE_update(void) {

}

void CUBE_draw(void) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();

    // �ʒu�X�V
    D3DXMATRIX mtx, mtxTranslate, mtxRotation, mtxScale;

    for (int i = 0; i < Cube_num; i++) {
        if (Cube[i].object.isuse) {
            D3DXMatrixIdentity(&mtx);

            D3DXMatrixScaling(&mtxScale, Cube[i].object.vecScale.x, Cube[i].object.vecScale.y, Cube[i].object.vecScale.z);
            D3DXMatrixMultiply(&mtx, &mtx, &mtxScale);

            D3DXMatrixRotationYawPitchRoll(&mtxRotation, Cube[i].object.vecRotation.x, Cube[i].object.vecRotation.y, Cube[i].object.vecRotation.z);
            D3DXMatrixMultiply(&mtx, &mtx, &mtxRotation);

            D3DXMatrixTranslation(&mtxTranslate, Cube[i].object.vecPosition.x, Cube[i].object.vecPosition.y, Cube[i].object.vecPosition.z);
            D3DXMatrixMultiply(&mtx, &mtx, &mtxTranslate);

            // �`��
            pDevice->SetTransform(D3DTS_WORLD, &mtx);
            pDevice->SetStreamSource(0, Cube[i].VtxBuff, 0, sizeof(VERTEX_3D));
            pDevice->SetIndices(IdxBuff);   // �C���f�b�N�X�o�b�t�@�̃Z�b�g
            pDevice->SetFVF(FVF_VERTEX_3D);

            for (int j = 0; j < 6; j++) {
                pDevice->SetTexture(0, TEXTURE_get_texture(Cube[i].texture_index));
                pDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, j * 4, 0, 4, 0, 2);    //�|���S���`��(�C���f�b�N�X�o�b�t�@��)
            }
        }
    }
}

CUBE *CUBE_get(void) {
    return Cube;
}

int CUBE_get_num(void) {
    return Cube_num;
}
