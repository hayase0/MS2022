/*====================================================================
    DirectX9
    [Callback.cpp]
    �E�R�[���o�b�N
----------------------------------------------------------------------
    @WATARU FUKUOKA(THS_AT12C342_36_80299) / 2019_07_04-2019_07_04
====================================================================*/
#include <d3dx9.h>

LRESULT CALLBACK WndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {
    switch (uMsg) {
    case WM_KEYDOWN:
        if (wParam == VK_ESCAPE) {
            SendMessage(hWnd, WM_CLOSE, 0, 0);
        }
        break;

    case WM_CLOSE:
        if (MessageBox(hWnd, "�{���ɏI�����Ă�낵���ł����H", "�m�F", MB_OKCANCEL | MB_DEFBUTTON2) == IDOK) {
            DestroyWindow(hWnd);
        }
        return 0;

    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    };

    return DefWindowProc(hWnd, uMsg, wParam, lParam);
}