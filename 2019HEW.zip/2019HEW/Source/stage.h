//#pragma once
//
// 
//
//#define MAX_BUILDING  (20)
//#define MAX_ITEM      (5)
//#define MAX_TARGETa    (10)
//
//void STAGE_initialize();
//void STAGE_finalize();
//void STAGE_update();
//void STAGE_draw();
//
//OBJECT *STAGE_get_building(void);
//OBJECT *STAGE_get_item(void);
//OBJECT *STAGE_get_target(void);