/*==============================================================================
    DirectX9_HEW_ROC
    [stage_f.cpp]
    �E�X�e�[�W
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_12_20-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "collision_box.h"
#include "player.h"

#include "cube.h"
#include "xcube.h"
#include "item.h"

#include "camera.h"
#include "shadow.h"

#include "stage_f.h"


static OBJECT *Collision_object[MAX_COLLISION_OBJECT] = { 0 };

static int Used_count = 0;

static STAGE_POS Stage_pos[STAGE_LUMP_MAX] = { 0 };

/*============================================================================*/

// �X�e�[�W���ł܂薈�Ɉړ���������W���Z�b�g
void set_stage_lump_pos(void) {

    // sekiro
    Stage_pos[STAGE_LUMP_000].x = 50000.0f;
    Stage_pos[STAGE_LUMP_000].y = 0.0f;
    Stage_pos[STAGE_LUMP_000].z = 0.0f;

    // �c���ꍆ
    Stage_pos[STAGE_LUMP_001].x = -20000.0f;
    Stage_pos[STAGE_LUMP_001].y = 0.0f;
    Stage_pos[STAGE_LUMP_001].z = -20000.0f;

    // �ŏ��̏�
    Stage_pos[STAGE_LUMP_002].x = 300000.0f;
    Stage_pos[STAGE_LUMP_002].y = 0.0f;
    Stage_pos[STAGE_LUMP_002].z = 0.0f;


    Stage_pos[STAGE_LUMP_003].x = 0.0f;
    Stage_pos[STAGE_LUMP_003].y = 0.0f;
    Stage_pos[STAGE_LUMP_003].z = 0.0f;

    Stage_pos[STAGE_LUMP_004].x = 0.0f;
    Stage_pos[STAGE_LUMP_004].y = 0.0f;
    Stage_pos[STAGE_LUMP_004].z = 0.0f;

    Stage_pos[STAGE_LUMP_005].x = 0.0f;
    Stage_pos[STAGE_LUMP_005].y = 0.0f;
    Stage_pos[STAGE_LUMP_005].z = 0.0f;

    Stage_pos[STAGE_LUMP_006].x = 0.0f;
    Stage_pos[STAGE_LUMP_006].y = 0.0f;
    Stage_pos[STAGE_LUMP_006].z = 0.0f;

    Stage_pos[STAGE_LUMP_007].x = 0.0f;
    Stage_pos[STAGE_LUMP_007].y = 0.0f;
    Stage_pos[STAGE_LUMP_007].z = 0.0f;

    Stage_pos[STAGE_LUMP_008].x = 0.0f;
    Stage_pos[STAGE_LUMP_008].y = 0.0f;
    Stage_pos[STAGE_LUMP_008].z = 0.0f;

    Stage_pos[STAGE_LUMP_009].x = 0.0f;
    Stage_pos[STAGE_LUMP_009].y = 0.0f;
    Stage_pos[STAGE_LUMP_009].z = 0.0f;



}



/*============================================================================*/
void STAGE_F_initialize(void) {
    Used_count = 0;

    set_stage_lump_pos();

    XCUBE_initialize();
    CUBE_initialize();


}

void STAGE_F_finalize(void) {
    CUBE_finalize();
}

void STAGE_F_update(void) {

}

void STAGE_F_draw(void) {
    for (int i = 0; i < Used_count; i++) {
        if (Collision_object[i]->isuse)
            MESH_render(Collision_object[i], Collision_object[i]->meshIndex);
    }
    CUBE_draw();
}

OBJECT *STAGE_F_get_collision_object(void) {
    return *Collision_object;
}

// �Փ˔���̂���I�u�W�F�N�g����̔z��ɂ܂Ƃ߂�B
void STAGE_F_set_collision_object(OBJECT *object) {

    Collision_object[Used_count] = object;
    Used_count++;
}

void STAGE_F_collsion(DYNAMIC_OBJECT *player) {
    for (int i = 0; i < NUM_DETECTION + 1; i++) {
        if (i != 0) player->object.vecPosition += player->move / NUM_DETECTION;
        COLLISION_BOX_setting(player); // �����蔻����X�V
        while (1) {
            for (int j = 0; j < Used_count; j++) {
                if (Collision_object[j]->isuse)
                    if (COLLISION_BOX_collision(player, Collision_object[j])) continue;
            }
            break;
        }
    }
}

void STAGE_F_collsion_camera(CAMERA *camera) {
    for (int i = 0; i < Used_count; i++) {
        if (Collision_object[i]->isuse) {
            D3DXVECTOR3 col_point;
            if (COLLISION_BOX_vsline(PLAYER_get(), Collision_object[i], camera->posR, camera->posV, &col_point)) camera->posV = col_point;
        }
    }
}

void STAGE_F_collsion_shadow(SHADOW *shadow) {
    shadow->isuse = false;
    DYNAMIC_OBJECT *player = PLAYER_get();
    float length = 40000.0f;


    shadow->pos.x = player->object.vecPosition.x;
    shadow->pos.z = player->object.vecPosition.z;


    if (player->flight) {
        D3DXVECTOR3 real_pos;
        for (int i = 0; i < Used_count; i++) {
            if (Collision_object[i]->isuse) {
                D3DXVECTOR3 col_point;
                if (COLLISION_BOX_vsline(player, Collision_object[i], player->object.vecPosition,
                                         player->object.vecPosition + D3DXVECTOR3(0.0f, -SHADOW_DIS, 0.0f), &col_point)) {
                    D3DXVECTOR3 ptoc = player->object.vecPosition - col_point;
                    if (length > D3DXVec3LengthSq(&ptoc)) {
                        length = D3DXVec3LengthSq(&ptoc);
                        real_pos = col_point;
                    }

                }
            }
        }
        shadow->pos.y = real_pos.y;
        shadow->isuse = true;
    }
    else {
        shadow->pos.y = player->object.vecPosition.y;
        shadow->isuse = true;
    }
    shadow->pos.y += 0.5f;
}

STAGE_POS *STAGE_F_get_stage_pos(void) {
    return Stage_pos;
}