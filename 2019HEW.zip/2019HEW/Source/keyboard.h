/*==============================================================================
    DirectX9
    [keyboard.h]
    �E�L�[�{�[�h����
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_19-2019_09_19
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#define DIRECTINPUT_VERSION (0x0800)
#include <dinput.h>

#define    NUM_KEY_MAX            (256)

/*============================================================================*/
bool KEYBOARD_initialize(HINSTANCE, HWND);
void KEYBOARD_finalize(void);
void KEYBOARD_update(void);

bool KEYBOARD_press(int nKey);
bool KEYBOARD_trigger(int nKey);
bool KEYBOARD_release(int nKey);