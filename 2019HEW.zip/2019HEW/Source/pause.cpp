/*==============================================================================
    DirectX9_HEW_ROC
    [pause.cpp]
    �E�|�[�Y�\���X�e�[�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "scene.h"
#include "phase.h"
#include "state.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

/*============================================================================*/
void PAUSE_initialize(void) {

}

void PAUSE_finalize(void) {

}

void PAUSE_update(void) {
    if (KEYBOARD_trigger(DIK_0)) {
        STATE_set(STATE_NORMAL);
    }
    if (KEYBOARD_trigger(DIK_1)) {
        SCENE_change(SCENE_TITLE);
    }
    if (KEYBOARD_trigger(DIK_2)) {
        PHASE_set(PHASE_END);
    }
}

void PAUSE_draw(void) {
    SPRITE_draw(TEST_PAUSE);
}