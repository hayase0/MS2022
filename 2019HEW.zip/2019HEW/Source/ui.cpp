/*==============================================================================
    DirectX9_HEW_ROC
    [ui.cpp]
    �E�v���C���[
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_21-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "hovergauge.h"
#include "guide.h"

void UI_initialize(void) {

}

void UI_finalize(void) {

}

void UI_update(void) {

}

void UI_draw(void) {
    //GUIDE_draw();
    HOVERGAUGE_draw();
}