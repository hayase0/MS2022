/*==============================================================================
    DirectX9_HEW_ROC
    [complete.cpp]
    �E�Q�[���I���X�e�[�g(�^�C���A�b�v�I)
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_11-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include "state.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

/*============================================================================*/
void COMPLETE_initialize(void) {

}

void COMPLETE_finalize(void) {

}

void COMPLETE_update(void) {

}

void COMPLETE_draw(void) {
    SPRITE_draw(TEST_COMPLETE);
}