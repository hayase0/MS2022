/*==============================================================================
    DirectX9_HEW_ROC
    [cube.cpp]
    �E�L���[�u
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_12_20-
================================================================================
    �X�V����

/*============================================================================*/

#include "main.h"

#include "cube.h"
#include "collision_box.h"
#include "stage_f.h"

#include "xcube.h"

static int Xcube_num = 0;

static OBJECT Xcube_b_y[CUBE_B_Y];
static OBJECT Xcube_w_y[CUBE_W_Y];

/*============================================================================*/
// �F���ɕ�����(mesh�Ⴄ�Ɠ����蔻��t�^���ʓ|�L������)
// ���������Ԃ��B

/* �ʂ��Ƃ̓����蔻��̗L�����E������

    Xcube_b_y[num].objColBox[�{�b�N�X�i���o�[(���󂾂�0�����g���ĂȂ��͂�)].faceUse[�ʂ̃i���o�[] = true��false;

    �ʂ̃i���o�[(����]��)
     0�c���
     1�c����
     2�c��O��
     3�c����
     4�c�E��
     5�c����

    �g�p��(num�Ԗڂ�Cube�̏�ʂ𖳌�������)
    Xcube_b_y[num].objColBox[0].faceUse[0] = false;
*/

int set_cube_b_y(void) {
    int num = 0;

    STAGE_POS *stage_pos = STAGE_F_get_stage_pos();

    for (int i = 0; i < CUBE_B_Y; i++) {
        Xcube_b_y[i].isuse = false;
        Xcube_b_y[i].meshIndex = MESH_INDEX_STAGE_000;
        Xcube_b_y[i].vecPosition = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[i].vecScale = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        for (int j = 0; j < NUM_MESH_BOX; j++)
            for (int k = 0; k < 6; k++)
                Xcube_b_y[i].objColBox[j].faceUse[k] = true;
    }

    /*============================================================================*/

    /* �e���v��
        {
        int x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = y = z = 0;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        num++;
        }
    */

    /*----------------------------------------------------------------------------*/

    {   // sekiro
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_000].x;
        y = stage_pos[STAGE_LUMP_000].y;
        z = stage_pos[STAGE_LUMP_000].z;


        // 1F
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 600.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(100.0f, 10.0f, 300.0f);
        num++;



        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 200.0f);
        num++;


        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 2500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(200.0f, 10.0f, 1000.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 2500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(200.0f, 10.0f, 1000.0f);
        num++;


        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 4000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 200.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 4000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 4000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 5000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(200.0f, 10.0f, 500.5f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 77.0f + y, 5990.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(-(D3DX_PI) * 0.05f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(200.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 150.0f + y, 6980.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 50.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 5000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(200.0f, 10.0f, 500.5f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 77.0f + y, 5990.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(-(D3DX_PI) * 0.05f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(200.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 150.0f + y, 6980.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 50.0f, 500.0f);
        num++;



        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 150.0f + y, 7250.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 500.0f);
        num++;

        // ����
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, -200.0f + y, 2500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;





        // 2F
        y = 300;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 200.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 2500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, (D3DX_PI) * 0.5f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 200.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 2500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, (D3DX_PI) * 0.5f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 200.0f);
        num++;


        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 4000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 200.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1500.0f + x, 0.0f + y, 4000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1500.0f + x, 0.0f + y, 4000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 500.0f);
        num++;




    }



    {   // �c���ꍆ
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_001].x;
        y = stage_pos[STAGE_LUMP_001].y;
        z = stage_pos[STAGE_LUMP_001].z;

        // ��K
        // ��
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 10.0f, 2000.0f);
        num++;

        // ��K
        // ��
        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 300.0f + y, -100.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(100.0f, 10.0f, 200.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 400.0f + y, 1200.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(100.0f, 10.0f, 300.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-700.0f + x, 300.0f + y, 600.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 900.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(700.0f + x, 450.0f + y, -100.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 900.0f);
        num++;


        // ��
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1000.0f + x, 495.0f + y, 600.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(5.0f, 200.0f, 900.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1000.0f + x, 495.0f + y, 600.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(5.0f, 200.0f, 900.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 495.0f + y, -300.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 200.0f, 5.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 495.0f + y, 1500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(1000.0f, 200.0f, 5.0f);
        num++;

        // ����
        // ���T�C�h
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-1100.0f + x, 850.0f + y, 900.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        // �E�T�C�h
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(1100.0f + x, 850.0f + y, 900.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        // �^��
        // ��
        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 900.0f + y, 100.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 920.0f + y, -400.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 940.0f + y, -900.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 900.0f + y, 3000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(300.0f, 10.0f, 300.0f);
        num++;

        // ��
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-300.0f + x, 990.0f + y, -400.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(5.0f, 100.0f, 800.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(300.0f + x, 990.0f + y, -400.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(5.0f, 100.0f, 800.0f);
        num++;

        //
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 990.0f + y, 800.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(400.0f, 10.0f, 200.0f);
        num++;

        // ��cube
        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(900.0f + x, 50.0f + y, 600.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(40.0f, 40.0f, 40.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(560.0f + x, 50.0f + y, -1000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(40.0f, 40.0f, 40.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-600.0f + x, 50.0f + y, 300.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(40.0f, 40.0f, 40.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-800.0f + x, 50.0f + y, -1100.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(40.0f, 40.0f, 40.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(40.0f, 40.0f, 40.0f);
        num++;

        //Xcube_b_y[num].meshIndex = MESH_INDEX_STAGE_003;
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 200.0f + y, -500.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(40.0f, 40.0f, 40.0f);
        num++;
    }



    /*----------------------------------------------------------------------------*/
    { // 
        float x, y, z;    // �܂Ƃ߂Ĉړ�������ϐ��B
        x = stage_pos[STAGE_LUMP_002].x;
        y = stage_pos[STAGE_LUMP_002].y;
        z = stage_pos[STAGE_LUMP_002].z;

        // ��
        //Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 0.0f + y, 0.0f + z);
        //Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        //Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 1000.0f);
        //num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 490.0f + y, -2900.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.25f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(100.0f, 10.0f, 2000.0f);
        num++;


        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 490.0f + y, -2900.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.25f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(100.0f, 10.0f, 2000.0f);
        num++;


        // �V��
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 510.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(500.0f, 10.0f, 1000.0f);
        num++;


        // ��
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-510.0f + x, 255.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(10.0f, 265.0f, 1000.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(510.0f + x, 255.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(10.0f, 265.0f, 1000.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-310.0f + x, 255.0f + y, -990.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(210.0f, 265.0f, 10.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(310.0f + x, 255.0f + y, -990.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(210.0f, 265.0f, 10.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(300.0f + x, 255.0f + y, -3000.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(10.0f, 265.0f, 1000.0f);
        num++;

        // �u��
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, 25.0f + y, 0.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(10.0f, 10.0f, 10.0f);
        num++;

        // �΂�
        Xcube_b_y[num].vecPosition = D3DXVECTOR3(0.0f + x, -371.5f + y, 1323.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3((D3DX_PI) * 0.27f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(100.0f, 10.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(-100.0f + x, -371.5f + y, 1323.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3((D3DX_PI) * 0.27f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(10.0f, 50.0f, 500.0f);
        num++;

        Xcube_b_y[num].vecPosition = D3DXVECTOR3(100.0f + x, -371.5f + y, 1323.0f + z);
        Xcube_b_y[num].vecRotation = D3DXVECTOR3((D3DX_PI) * 0.27f, 0.0f, 0.0f);
        Xcube_b_y[num].vecScale = D3DXVECTOR3(10.0f, 50.0f, 500.0f);
        num++;
    }
    /*----------------------------------------------------------------------------*/

    for (int i = 0; i < num; i++) {
        Xcube_b_y[i].isuse = true;
        COLLISION_BOX_setting(&Xcube_b_y[i]);
        STAGE_F_set_collision_object(&Xcube_b_y[i]);
    }

    return num;
}

int set_cube_w(void) {
    int num = 0;

    //for (int i = 0; i < CUBE_W_Y; i++) {
    //    Xcube_w_y[i].isuse = false;
    //    Xcube_w_y[i].meshIndex = MESH_INDEX_STAGE_001;
    //    Xcube_w_y[i].vecPosition = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    //    Xcube_w_y[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    //    Xcube_w_y[i].vecScale = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    //}

    //Xcube_w_y[num].vecPosition = D3DXVECTOR3(50.0f, 50.0f, 500.0f);
    //Xcube_w_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    //Xcube_w_y[num].vecScale = D3DXVECTOR3(50.0f, 50.0f, 50.0f);
    //num++;

    //Xcube_w_y[num].vecPosition = D3DXVECTOR3(250.0f, 50.0f, 500.0f);
    //Xcube_w_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    //Xcube_w_y[num].vecScale = D3DXVECTOR3(50.0f, 50.0f, 50.0f);
    //num++;

    //Xcube_w_y[num].vecPosition = D3DXVECTOR3(500.0f, 50.0f, 500.0f);
    //Xcube_w_y[num].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
    //Xcube_w_y[num].vecScale = D3DXVECTOR3(50.0f, 50.0f, 50.0f);
    //num++;

    //for (int i = 0; i < num; i++) {
    //    Xcube_w_y[i].isuse = true;
    //    COLLISION_BOX_setting(&Xcube_w_y[i]);
    //    STAGE_F_set_collision_object(&Xcube_w_y[i]);
    //}

    return num;
}

/*============================================================================*/
void XCUBE_initialize(void) {
    Xcube_num = (0
                 + set_cube_b_y()
                 + set_cube_w()
                 );
}

void XCUBE_update(void) {

}


OBJECT *XCUBE_get(void) {
    return Xcube_b_y;
}

int XCUBE_get_num(void) {
    return Xcube_num;
}
