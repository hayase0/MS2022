/*==============================================================================
    DirectX9
    [keyboard.cpp]
    �E�L�[�{�[�h����
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_19-2019_09_19
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "keyboard.h"

static LPDIRECTINPUT8       g_pInput = NULL;
static LPDIRECTINPUTDEVICE8 g_pDevKeyboard = NULL;
static BYTE                 g_aKeyState[NUM_KEY_MAX];
static BYTE                 g_aKeyStateTrigger[NUM_KEY_MAX];
static BYTE                 g_aKeyStateRelease[NUM_KEY_MAX];

/*============================================================================*/
static bool initialize(HINSTANCE hInstance) {
    if (g_pInput == NULL) {
        if (FAILED(DirectInput8Create(hInstance, DIRECTINPUT_VERSION, IID_IDirectInput8, (void**)&g_pInput, NULL))) {
            return false;
        }
    }
    return true;
}

static void finalize(void) {
    if (g_pInput != NULL) {
        g_pInput->Release();
        g_pInput = NULL;
    }
}

/*============================================================================*/
bool KEYBOARD_initialize(HINSTANCE hInstance, HWND hWnd) {
    if (!initialize(hInstance)) {
        MessageBox(hWnd, "DirectInput�I�u�W�F�N�g�����˂��I", "�x���I", MB_ICONWARNING);
        return false;
    }

    if (FAILED(g_pInput->CreateDevice(GUID_SysKeyboard, &g_pDevKeyboard, NULL))) {
        MessageBox(hWnd, "�L�[�{�[�h���˂��I", "�x���I", MB_ICONWARNING);
        return false;
    }

    if (FAILED(g_pDevKeyboard->SetDataFormat(&c_dfDIKeyboard))) {
        MessageBox(hWnd, "�L�[�{�[�h�̃f�[�^�t�H�[�}�b�g��ݒ�ł��܂���ł����B", "�x���I", MB_ICONWARNING);
        return false;
    }
    //                                                    DISCL_BACKGROUND | DISCL_EXCLUSIVE    
    if (FAILED(g_pDevKeyboard->SetCooperativeLevel(hWnd, (DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))) {
        MessageBox(hWnd, "�L�[�{�[�h�̋������[�h��ݒ�ł��܂���ł����B", "�x���I", MB_ICONWARNING);
        return false;
    }

    g_pDevKeyboard->Acquire();

    return true;
}

void KEYBOARD_finalize(void) {
    if (g_pDevKeyboard != NULL) {
        g_pDevKeyboard->Unacquire();
        g_pDevKeyboard->Release();
        g_pDevKeyboard = NULL;
    }

    finalize();
}

void KEYBOARD_update(void) {
    BYTE aKeyState[NUM_KEY_MAX];

    if (SUCCEEDED(g_pDevKeyboard->GetDeviceState(sizeof(aKeyState), aKeyState))) {
        for (int nCnKey = 0; nCnKey < NUM_KEY_MAX; nCnKey++) {
            g_aKeyStateTrigger[nCnKey] = (g_aKeyState[nCnKey] ^ aKeyState[nCnKey]) & aKeyState[nCnKey];
            g_aKeyStateRelease[nCnKey] = (g_aKeyState[nCnKey] ^ aKeyState[nCnKey]) & g_aKeyState[nCnKey];
            g_aKeyState[nCnKey] = aKeyState[nCnKey];
        }
    }
    else {
        g_pDevKeyboard->Acquire();
    }
}

bool KEYBOARD_press(int nKey) {
    return (g_aKeyState[nKey] & 0x80) ? true : false;
}

bool KEYBOARD_trigger(int nKey) {
    return (g_aKeyStateTrigger[nKey] & 0x80) ? true : false;
}

bool KEYBOARD_release(int nKey) {
    return (g_aKeyStateRelease[nKey] & 0x80) ? true : false;
}
