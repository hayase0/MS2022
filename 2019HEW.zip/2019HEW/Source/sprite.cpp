/*==============================================================================
    DirectX9
    [sprite.cpp]
    �E�X�v���C�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_20-2019_09_20
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"

#include <math.h>
#include "direct3d.h"
#include "texture.h"
#include "sprite.h"

typedef struct Vertex2D_tag {
    D3DXVECTOR4 position;
    D3DCOLOR color;
    D3DXVECTOR2 texcoord;
} Vertex2D;

static Player_pos player_pos;

#define FVF_VERTEX2D (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)

static D3DCOLOR g_Color = D3DCOLOR_RGBA(255, 255, 255, 255);

void SPRITE_set_color(D3DCOLOR color) {
    g_Color = color;
}

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float w = (float)TEXTURE_get_width(texture_index);
    float h = (float)TEXTURE_get_height(texture_index);

    float x = dx - w / 2;
    float y = dy - h / 2;

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(x - 0.5f, y - 0.5f, 0.0f, 1.0f), g_Color,         D3DXVECTOR2(0.0f, 0.0f) },
        { D3DXVECTOR4(x + w - 0.5f, y - 0.5f, 0.0f, 1.0f), g_Color,     D3DXVECTOR2(1.0f, 0.0f) },
        { D3DXVECTOR4(x - 0.5f, y + h - 0.5f, 0.0f, 1.0f), g_Color,     D3DXVECTOR2(0.0f, 1.0f) },
        { D3DXVECTOR4(x + w - 0.5f, y + h - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(1.0f, 1.0f) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));

    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float w = (float)TEXTURE_get_width(texture_index);
    float h = (float)TEXTURE_get_height(texture_index);

    float u[2], v[2];
    u[0] = (float)tx / w;
    v[0] = (float)ty / h;
    u[1] = (float)(tx + tw) / w;
    v[1] = (float)(ty + th) / h;

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(dx - 0.5f, dy - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[0], v[0]) },
        { D3DXVECTOR4(dx + tw - 0.5f, dy - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[1], v[0]) },
        { D3DXVECTOR4(dx - 0.5f, dy + th - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[0], v[1]) },
        { D3DXVECTOR4(dx + tw - 0.5f, dy + th - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[1], v[1]) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th,
                 D3DCOLOR color) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float w = (float)TEXTURE_get_width(texture_index);
    float h = (float)TEXTURE_get_height(texture_index);

    float u[2], v[2];
    u[0] = (float)tx / w;
    v[0] = (float)ty / h;
    u[1] = (float)(tx + tw) / w;
    v[1] = (float)(ty + th) / h;

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(dx - 0.5f, dy - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[0], v[0]) },
        { D3DXVECTOR4(dx + tw - 0.5f, dy - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[1], v[0]) },
        { D3DXVECTOR4(dx - 0.5f, dy + th - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[0], v[1]) },
        { D3DXVECTOR4(dx + tw - 0.5f, dy + th - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[1], v[1]) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

// �v���C���[��p
void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th,
                 float cx, float cy,
                 float sx, float sy,
                 float rotation) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float w = (float)TEXTURE_get_width(texture_index);
    float h = (float)TEXTURE_get_height(texture_index);

    float u[2], v[2];
    u[0] = (float)tx / w;
    v[0] = (float)ty / h;
    u[1] = (float)(tx + tw) / w;
    v[1] = (float)(ty + th) / h;

    D3DXMATRIX matBase[4];

    D3DXMatrixTranslation(&matBase[0], -(tw - (tw - cx)), -(th - (th - cy)), 0.0f);
    D3DXMatrixTranslation(&matBase[1], tw - cx, -(th - (th - cy)), 0.0f);
    D3DXMatrixTranslation(&matBase[2], -(tw - (tw - cx)), th - cy, 0.0f);
    D3DXMatrixTranslation(&matBase[3], tw - cx, th - cy, 0.0f);

    D3DXMATRIX matTrans;
    D3DXMATRIX matRot;
    D3DXMATRIX matScale;
    D3DXMATRIX matAll;
    float px[4], py[4];

    D3DXMatrixTranslation(&matTrans, dx, dy, 0.0f);
    D3DXMatrixRotationZ(&matRot, rotation);
    D3DXMatrixScaling(&matScale, sx, sy, 1.0f);

    for (int i = 0; i < 4; i++) {
        matAll = matBase[i] * matScale * matRot * matTrans;
        px[i] = matAll._41;
        py[i] = matAll._42;
    }

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(px[0] - 0.5f, py[0] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[0], v[0]) },
        { D3DXVECTOR4(px[1] - 0.5f, py[1] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[1], v[0]) },
        { D3DXVECTOR4(px[2] - 0.5f, py[2] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[0], v[1]) },
        { D3DXVECTOR4(px[3] - 0.5f, py[3] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[1], v[1]) },
    };

    for (int i = 0; i < 4; i++) {
        player_pos.x[i] = px[i];
        player_pos.y[i] = py[i];
    }

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

void SPRITE_draw(TEXTURE_INDEX texture_index, float dx, float dy, int tx, int ty, int tw, int th, float cx, float cy, float sx, float sy, float rotation, D3DCOLOR color) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float w = (float)TEXTURE_get_width(texture_index);
    float h = (float)TEXTURE_get_height(texture_index);

    float u[2], v[2];
    u[0] = (float)tx / w;
    v[0] = (float)ty / h;
    u[1] = (float)(tx + tw) / w;
    v[1] = (float)(ty + th) / h;

    D3DXMATRIX matBase[4];

    D3DXMatrixTranslation(&matBase[0], -(tw - (tw - cx)), -(th - (th - cy)), 0.0f);
    D3DXMatrixTranslation(&matBase[1], tw - cx, -(th - (th - cy)), 0.0f);
    D3DXMatrixTranslation(&matBase[2], -(tw - (tw - cx)), th - cy, 0.0f);
    D3DXMatrixTranslation(&matBase[3], tw - cx, th - cy, 0.0f);

    D3DXMATRIX matTrans;
    D3DXMATRIX matRot;
    D3DXMATRIX matScale;
    D3DXMATRIX matAll;
    float px[4], py[4];

    D3DXMatrixTranslation(&matTrans, dx, dy, 0.0f);
    D3DXMatrixRotationZ(&matRot, rotation);
    D3DXMatrixScaling(&matScale, sx, sy, 1.0f);

    for (int i = 0; i < 4; i++) {
        matAll = matBase[i] * matScale * matRot * matTrans;
        px[i] = matAll._41;
        py[i] = matAll._42;
    }

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(px[0] - 0.5f, py[0] - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[0], v[0]) },
        { D3DXVECTOR4(px[1] - 0.5f, py[1] - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[1], v[0]) },
        { D3DXVECTOR4(px[2] - 0.5f, py[2] - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[0], v[1]) },
        { D3DXVECTOR4(px[3] - 0.5f, py[3] - 0.5f, 0.0f, 1.0f), color, D3DXVECTOR2(u[1], v[1]) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

void SPRITE_draw(TEXTURE_INDEX texture_index, float dx, float dy, int tx, int ty, int tw, int th, float cx, float cy, float sx, float sy, float rotation, int a) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float w = (float)TEXTURE_get_width(texture_index);
    float h = (float)TEXTURE_get_height(texture_index);

    float u[2], v[2];
    u[0] = (float)tx / w;
    v[0] = (float)ty / h;
    u[1] = (float)(tx + tw) / w;
    v[1] = (float)(ty + th) / h;

    D3DXMATRIX matBase[4];

    D3DXMatrixTranslation(&matBase[0], -(tw - (tw - cx)), -(th - (th - cy)), 0.0f);
    D3DXMatrixTranslation(&matBase[1], tw - cx, -(th - (th - cy)), 0.0f);
    D3DXMatrixTranslation(&matBase[2], -(tw - (tw - cx)), th - cy, 0.0f);
    D3DXMatrixTranslation(&matBase[3], tw - cx, th - cy, 0.0f);

    D3DXMATRIX matTrans;
    D3DXMATRIX matRot;
    D3DXMATRIX matScale;
    D3DXMATRIX matAll;
    float px[4], py[4];

    D3DXMatrixTranslation(&matTrans, dx, dy, 0.0f);
    D3DXMatrixRotationZ(&matRot, rotation);
    D3DXMatrixScaling(&matScale, sx, sy, 1.0f);

    for (int i = 0; i < 4; i++) {
        matAll = matBase[i] * matScale * matRot * matTrans;
        px[i] = matAll._41;
        py[i] = matAll._42;
    }

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(px[0] - 0.5f, py[0] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[0], v[0]) },
        { D3DXVECTOR4(px[1] - 0.5f, py[1] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[1], v[0]) },
        { D3DXVECTOR4(px[2] - 0.5f, py[2] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[0], v[1]) },
        { D3DXVECTOR4(px[3] - 0.5f, py[3] - 0.5f, 0.0f, 1.0f), g_Color, D3DXVECTOR2(u[1], v[1]) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

// �C���f�b�N�X,���Wx,y,����,�c��,�e�N�X�`�����Wx,y,�������̃X�v���C�g��,�F
void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 float tw, float th,
                 char tx_num, char ty_num,
                 int split,
                 D3DCOLOR color) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float tsw = tw / 2;
    float tsh = th / 2;

    float unit = 1.0f / split;

    float u[2], v[2];
    u[0] = (float)tx_num * unit;
    v[0] = (float)ty_num * unit;
    u[1] = u[0] + unit;
    v[1] = v[0] + unit;

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(dx - tsw, dy - tsh, 0.0f, 1.0f), color, D3DXVECTOR2(u[0], v[0]) },
        { D3DXVECTOR4(dx + tsw, dy - tsh, 0.0f, 1.0f), color, D3DXVECTOR2(u[1], v[0]) },
        { D3DXVECTOR4(dx - tsw, dy + tsh, 0.0f, 1.0f), color, D3DXVECTOR2(u[0], v[1]) },
        { D3DXVECTOR4(dx + tsw, dy + tsh, 0.0f, 1.0f), color, D3DXVECTOR2(u[1], v[1]) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}

// �ꏊ�ƃT�C�Y�ƃJ���[�̂�
void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 float tw, float th,
                 D3DCOLOR color) {
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    if (!pDevice) return;

    float tsw = tw / 2;
    float tsh = th / 2;

    Vertex2D vertexes[] = {
        { D3DXVECTOR4(dx - tsw, dy - tsh, 0.0f, 1.0f), color, D3DXVECTOR2(0.0f, 0.0f) },
        { D3DXVECTOR4(dx + tsw, dy - tsh, 0.0f, 1.0f), color, D3DXVECTOR2(1.0f, 0.0f) },
        { D3DXVECTOR4(dx - tsw, dy + tsh, 0.0f, 1.0f), color, D3DXVECTOR2(0.0f, 1.0f) },
        { D3DXVECTOR4(dx + tsw, dy + tsh, 0.0f, 1.0f), color, D3DXVECTOR2(1.0f, 1.0f) },
    };

    pDevice->SetFVF(FVF_VERTEX2D);
    pDevice->SetTexture(0, TEXTURE_get_texture(texture_index));
    pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, vertexes, sizeof(Vertex2D));
}


Player_pos SPRITE_player_get(void) {
    return player_pos;
}

