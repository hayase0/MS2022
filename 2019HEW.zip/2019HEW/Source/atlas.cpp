/*==============================================================================
    DirectX9_HEW_ROC
    [atlas.cpp]
    �E�}�b�v�\���X�e�[�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"

#include "scene.h"
#include "state.h"

#include "texture.h"
#include "sprite.h"

#include "map.h"

#include "keyboard.h"

/*============================================================================*/
void ATLAS_initialize(void) {

}
void ATLAS_finalize(void) {

}
void ATLAS_update(void) {
    if (KEYBOARD_trigger(DIK_0)) {
        STATE_set(STATE_NORMAL);
    }
}
void ATLAS_draw(void) {
    MAP_draw();
}
