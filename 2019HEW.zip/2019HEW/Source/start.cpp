/*==============================================================================
    DirectX9_HEW_ROC
    [start.cpp]
    �E�N���V�[���B���S��\������B
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"

#include "scene.h"
#include "phase.h"

#include "texture.h"
#include "sprite.h"

#include "keyboard.h"

#include "transition.h"
/*============================================================================*/
void START_initialize(void) {
    PHASE_set(PHASE_BEGIN);

}
void START_finalize(void) {

}
void START_update(void) {
    PHASE_function(SCENE_get());
}
void START_draw(void) {
    SPRITE_draw(TEST_01);

}
/*============================================================================*/
void START_begin(void) {
    if (!TRANSITION_check()) PHASE_set(PHASE_RUN);
}
void START_run(void) {
    if (KEYBOARD_trigger(DIK_1)) {
        PHASE_set(PHASE_END);
    }
}
void START_end(void) {
    if (!TRANSITION_check()) SCENE_change(SCENE_TITLE);

}