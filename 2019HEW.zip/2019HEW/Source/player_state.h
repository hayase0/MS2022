/*==============================================================================
    DirectX9_HEW_ROC
    [player_state.h]
    �E�v���C���[��ԊǗ�
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI (THS_AT12C342_21_85004)  /  2019_11_20-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

enum PLAYER_STATE {
    PLAYER_STATE_WAIT,
    PLAYER_STATE_WALK,
    PLAYER_STATE_RUN,
    PLAYER_STATE_JUMP,
    PLAYER_STATE_RISE,
    PLAYER_STATE_FALL,
    PLAYER_STATE_HOVER,
    PLAYER_STATE_LAND,
    PLAYER_STATE_FPAIM,
    PLAYER_STATE_SHOT,
    PLAYER_STATE_HOOKMOVE,
    PLAYER_STATE_SWING,
    PLAYER_STATE_GETITEM,

};

void PLAYER_STATE_update(void);

PLAYER_STATE PLAYER_STATE_get(void);
void PLAYER_STATE_set(PLAYER_STATE nextstate);
void PLAYER_STATE_lifted(void);