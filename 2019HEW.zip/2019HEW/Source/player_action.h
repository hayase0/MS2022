/*==============================================================================
    DirectX9_HEW_ROC
    [playeraction.h]
    �E�v���C���[����
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_11_17-2019_11_
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

void PLAYER_ACTION_wait(void);
void PLAYER_ACTION_move(void);
void PLAYER_ACTION_jump(void);
void PLAYER_ACTION_rise(void);
void PLAYER_ACTION_fall(void);
void PLAYER_ACTION_hover(void);
void PLAYER_ACTION_land(void);
void PLAYER_ACTION_aim(void);
void PLAYER_ACTION_fpaim(void);
void PLAYER_ACTION_hookmove(void);
void PLAYER_ACTION_swing(void);
void PLAYER_ACTION_settime(void);
D3DXVECTOR3 PLAYER_ACTION_gettargetpos(void);
void PLAYER_ACTION_sethookmove(void);
int PLAYER_ACTION_GET_TARGET_NUM(void);
void PLAYER_ACTION_getitem(void);