/*==============================================================================
    DirectX9_HEW_ROC
    [network.cpp]
    �E�l�b�g���[�N
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2020_01_16
================================================================================
    �X�V����

/*============================================================================*/
// �T�[�o�[�T�C�h(tcp)
#pragma comment(lib, "Ws2_32.lib")
#pragma warning (disable:4996)
#include <winsock2.h>
#include <stdio.h>
#include <string.h>
#include "main.h"

#include "network.h"
#include "build_data.h"

#define MY_ADDRESS ("10.192.110.77")
#define OTHER_ADDRESS ("10.192.110.77")

WSADATA WinSockDateStorage = { 0 };
SOCKET ConnectSocket;
SOCKET CommunicationSocket;
SOCKADDR_IN ServerInfo = { 0 };
SOCKADDR_IN ClientInfo = { 0 };
WSAEVENT AcceptJudgmentSwitch;
bool Last = false;

static float convert_to_float(char* source, int len, int dec) {
    float num = 0.0f;
    float bit = (float)pow(10, len - 1);
    int max = len;
    while (len + dec > 0) {
        num += (float)(((int)source[max - len] - 48) * bit);
        bit /= 10.0f;
        len -= 1;
    }
    return num;
}

static float convert_to_rot(char* source) {
    if (*source == '0')
        return 0.0f;
    else if (*source == '1')
        return D3DX_PI * 0.5f;
    else if (*source == '2')
        return D3DX_PI;
    else return D3DX_PI * 1.5f;
}

static MESH_INDEX convert_to_meshid(char* source) {
    int meshid = ((int)*source - 48);
    return (MESH_INDEX)meshid;
}

static void square_convert(char* data) {
    int x, z;

    x = (int)convert_to_float(data, 2, 0);
    data += 2;
    z = (int)convert_to_float(data, 2, 0);
    data += 2;

    SQUARE_set(x, z);
    SQUAREVECTOR2 vec;
    vec.x = x; vec.z = z;
}

static BUILDING building_convert(char* data) {
    BUILDING build;
    build.buildersName[0] = '\0';
    int len;
    for (len = 0; len < 64; len++) {
        if (data[len] == '|') {
            build.buildersName[len] = '\0';
            break;
        }
        else
            build.buildersName[len] = data[len];
    }

    len += 1;

    build.object.vecPosition.x = convert_to_float(&data[len], 5, 0);
    len += 5;
    build.object.vecPosition.y = convert_to_float(&data[len], 5, 0);
    len += 5;
    build.object.vecPosition.z = convert_to_float(&data[len], 5, 0);
    len += 5;
    build.object.vecRotation.y = convert_to_rot(&data[len]);
    len += 1;
    build.object.vecScale.x = convert_to_float(&data[len], 2, 1);
    len += 3;
    build.object.vecScale.y = convert_to_float(&data[len], 2, 1);
    len += 3;
    build.object.vecScale.z = convert_to_float(&data[len], 2, 1);
    len += 3;
    build.object.meshIndex = convert_to_meshid(&data[len]);

    build.object.vecRotation.x = 0.0f;
    build.object.vecRotation.z = 0.0f;
    return build;
}

static char* convert_to_char5(int source) {
    static char data[6] = "\0";

    data[5] = '\0';
    for (int i = 4; i >= 0; i--) {
        data[i] = source % 10 + 48;
        source /= 10;
    }

    return data;
}

static char* convert_to_char3(float source) {
    static char data[4] = "\0";
    int tmp = (int)source * 10;

    data[3] = '\0';
    for (int i = 2; i >= 0 || tmp > 0; i--) {
        data[i] = tmp % 10 + 48;
        tmp /= 10;
    }

    return data;
}

static char* convert_to_char(float rot) {
    static char data[2];
    if (rot == 0.0f)
        data[0] = '0';
    else if (rot == D3DX_PI * 0.5f)
        data[0] = '1';
    else if (rot == D3DX_PI)
        data[0] = '2';
    else data[0] = '3';

    data[1] = '\0';

    return data;
}

static char* convert_to_char(MESH_INDEX meshid) {
    static char data[2];
    data[0] = (int)meshid + 48;
    data[1] = '\0';
    return data;
}

static char* convert(BUILDING building) {
    static char data[50] = "\0";

    strcpy(data, building.buildersName);
    strcat(data, "|");
    strcat(data, convert_to_char5((int)building.object.vecPosition.x));
    strcat(data, convert_to_char5((int)building.object.vecPosition.y));
    strcat(data, convert_to_char5((int)building.object.vecPosition.z));
    strcat(data, convert_to_char(building.object.vecRotation.y));
    strcat(data, convert_to_char3(building.object.vecScale.x));
    strcat(data, convert_to_char3(building.object.vecScale.y));
    strcat(data, convert_to_char3(building.object.vecScale.z));
    strcat(data, convert_to_char(building.object.meshIndex));
    strcat(data, "\0");

    return data;
}

static char* convert(int x, int z) {
    static char data[5] = "\0";

    data[1] = x % 10 + 48;

    if (x >= 10) {
        data[0] = x / 10 + 48;
    }

    data[3] = z % 10 + 48;

    if (z >= 10) {
        data[2] = z / 10 + 48;
    }

    strcat(data, "\0");
    return data;
}

void NETWORK_initialize(void) {
    WSAStartup(MAKEWORD(1, 1), &WinSockDateStorage);
    ServerInfo.sin_family = AF_INET;
    ServerInfo.sin_port = htons(54924);
    ServerInfo.sin_addr.S_un.S_addr = inet_addr(MY_ADDRESS);
}

void NETWORK_sendsignal(void) {
    ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
    bind(ConnectSocket, (SOCKADDR*)&ServerInfo, sizeof(ServerInfo));
    listen(ConnectSocket, 0);
    AcceptJudgmentSwitch = WSACreateEvent();
    WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_ACCEPT);
    int ClientInfoLEN = (int)sizeof(ClientInfo);

    while (1) {
        if ((WaitForSingleObject(AcceptJudgmentSwitch, 0)) == WAIT_OBJECT_0) { // AcceptJudgmentSwitch���V�O�i����ԂɂȂ�����^
            CommunicationSocket = accept(ConnectSocket, (SOCKADDR*)&ClientInfo, &ClientInfoLEN);

            send(CommunicationSocket, MY_ADDRESS, 15, 0); // �T�[�o�[�Ƀp�P�b�g�𑗂�

            NETWORK_finalize();
            NETWORK_initialize();
            ServerInfo.sin_addr.S_un.S_addr = inet_addr(OTHER_ADDRESS);


            break;
        }
    }
}

void NETWORK_send(BUILDING building, SELECTSQUARE* square) {
    ServerInfo.sin_addr.S_un.S_addr = inet_addr(MY_ADDRESS);
    ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
    bind(ConnectSocket, (SOCKADDR*)&ServerInfo, sizeof(ServerInfo));
    listen(ConnectSocket, 0);
    AcceptJudgmentSwitch = WSACreateEvent();
    WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_ACCEPT);

    int ClientInfoLEN = (int)sizeof(ClientInfo);
    while (1) {
        if ((WaitForSingleObject(AcceptJudgmentSwitch, 0)) == WAIT_OBJECT_0) { // AcceptJudgmentSwitch���V�O�i����ԂɂȂ�����^

            CommunicationSocket = accept(ConnectSocket, (SOCKADDR*)&ClientInfo, &ClientInfoLEN);

            char build_data[50];
            strcpy(build_data, convert(building));

            send(CommunicationSocket, build_data, 50, 0); // �T�[�o�[�Ƀp�P�b�g�𑗂�

            AcceptJudgmentSwitch = WSACreateEvent();
            WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_ACCEPT);
            break;
        }
    }

    for (int i = 0; i < 4; i++) {
        if (square[i].use == true) {
            while (1) {
                if ((WaitForSingleObject(AcceptJudgmentSwitch, 0)) == WAIT_OBJECT_0) { // AcceptJudgmentSwitch���V�O�i����ԂɂȂ�����^

                    CommunicationSocket = accept(ConnectSocket, (SOCKADDR*)&ClientInfo, &ClientInfoLEN);

                    static char data[10];
                    strcpy(data, convert(square[i].pos.x, square[i].pos.z));

                    send(CommunicationSocket, data, 6, 0); // �T�[�o�[�Ƀp�P�b�g�𑗂�

                    AcceptJudgmentSwitch = WSACreateEvent();
                    WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_ACCEPT);

                    break;
                }
            }
        }
    }
    while (1) {
        if ((WaitForSingleObject(AcceptJudgmentSwitch, 0)) == WAIT_OBJECT_0) { // AcceptJudgmentSwitch���V�O�i����ԂɂȂ�����^

            CommunicationSocket = accept(ConnectSocket, (SOCKADDR*)&ClientInfo, &ClientInfoLEN);

            if (Last == true) {
                send(CommunicationSocket, "last", 6, 0); // �T�[�o�[�Ƀp�P�b�g�𑗂�
                Last = false;
            }
            else
                send(CommunicationSocket, "end", 6, 0); // �T�[�o�[�Ƀp�P�b�g�𑗂�

            NETWORK_finalize();
            NETWORK_initialize();

            break;
        }
    }
}

void NETWORK_receive(void) {
    int count = 0;
    char ClientDateBuffer[1024];
    ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
    AcceptJudgmentSwitch = WSACreateEvent();
    WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_READ);
    {
        BUILDING* building = BUILD_DATA_get_building();

        while (1) {
            connect(ConnectSocket, (SOCKADDR*)&ServerInfo, sizeof(ServerInfo));
            if ((WaitForSingleObject(AcceptJudgmentSwitch, 0)) == WAIT_OBJECT_0) { // AcceptJudgmentSwitch���V�O�i����ԂɂȂ�����^

                int recvRETURN = 0;

                recvRETURN = recv(ConnectSocket, ClientDateBuffer, sizeof(ClientDateBuffer) - 1, 0);

                if (recvRETURN > 0) {
                    ClientDateBuffer[recvRETURN] = '\0';

                    if (strcmp(ClientDateBuffer, "end") != 0) {
                        building[count] = building_convert(ClientDateBuffer);
                        count++;
                    }
                    else break;

                    ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
                    AcceptJudgmentSwitch = WSACreateEvent();
                    WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_READ);
                }
            }
        }
    }
    ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);

    while (1) {
        connect(ConnectSocket, (SOCKADDR*)&ServerInfo, sizeof(ServerInfo));
        if ((WaitForSingleObject(AcceptJudgmentSwitch, 0)) == WAIT_OBJECT_0) { // AcceptJudgmentSwitch���V�O�i����ԂɂȂ�����^
            int recvRETURN = 0;
            recvRETURN = recv(ConnectSocket, ClientDateBuffer, sizeof(ClientDateBuffer) - 1, 0);

            if (recvRETURN > 0) {
                ClientDateBuffer[recvRETURN] = '\0';

                if (strcmp(ClientDateBuffer, "end") != 0) {
                    square_convert(ClientDateBuffer);
                }
                else
                    break;

                ConnectSocket = socket(AF_INET, SOCK_STREAM, 0);
                AcceptJudgmentSwitch = WSACreateEvent();
                WSAEventSelect(ConnectSocket, AcceptJudgmentSwitch, FD_READ);
            }
        }
    }
}

void NETWORK_finalize(void) {
    closesocket(CommunicationSocket);

    shutdown(CommunicationSocket, 2);
    closesocket(ConnectSocket);
    WSACleanup();

}

void NETWORK_last(void) {
    Last = true;
}