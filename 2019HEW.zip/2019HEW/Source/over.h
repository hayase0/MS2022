/*==============================================================================
    DirectX9_HEW_ROC
    [over.h]
    �E�T���L���[�t�H�[�v���C���O
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#pragma once



void OVER_initialize(void);
void OVER_finalize(void);
void OVER_update(void);
void OVER_draw(void);

void OVER_begin(void);
void OVER_run(void);
void OVER_end(void);