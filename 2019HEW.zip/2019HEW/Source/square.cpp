/*==============================================================================
    DirectX9_HEW_ROC
    [square.cpp]
    �E�}�X
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_23_80310) / 2019_12_16
================================================================================
    �X�V����

/*============================================================================*/

#include "keyboard.h"
#include "gamepad.h"
#include "texture.h"
#include "square.h"
#include "building.h"
#include "buildcamera.h"
#include "direct3d.h"

static HRESULT MakeVertexField(LPDIRECT3DDEVICE9 pDevice);

static SQUARE Square[SQUARE_NUM_Z][SQUARE_NUM_X];       // �}�X
static SQUAREVECTOR2 Selectpos;                         // �I�𒆂̃}�X�̈ʒu(int x, int z)
static SELECTSQUARE SelectSquare[4];
static LPDIRECT3DVERTEXBUFFER9 VtxBuffFrame = NULL;	    // ���_�o�b�t�@�ւ̃|�C���^

void SQUARE_squareposupdate(void) {
    for (int i = 0; i < 4; i++) SelectSquare[i].pos = Selectpos + SelectSquare[i].vec;
}

void SQUARE_formupdate(void) {
    SelectSquare[0].use = true;
    SelectSquare[1].use = false;
    SelectSquare[2].use = false;
    SelectSquare[3].use = false;
    SelectSquare[0].vec = SQUAREVECTOR2{ 0, 0 };
    if (BUILDING_getbuildingform() == BUILDING_FORM_PATTERN_SERIES2) {
        SelectSquare[1].use = true;
        if (BUILDING_getrotationy() == D3DX_PI) SelectSquare[1].vec = SQUAREVECTOR2{ 1, 0 };
        if (BUILDING_getrotationy() == D3DX_PI * 0.5f) SelectSquare[1].vec = SQUAREVECTOR2{ 0, 1 };
        if (BUILDING_getrotationy() == 0.0f) SelectSquare[1].vec = SQUAREVECTOR2{ -1, 0 };
        if (BUILDING_getrotationy() == -D3DX_PI * 0.5f) SelectSquare[1].vec = SQUAREVECTOR2{ 0, -1 };
    }
    else if (BUILDING_getbuildingform() == BUILDING_FORM_PATTERN_SERIES3) {
        SelectSquare[1].use = true;
        SelectSquare[2].use = true;
        if (BUILDING_getrotationy() == D3DX_PI) {
            SelectSquare[0].vec = SQUAREVECTOR2{ -1, 0 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 1, 0 };
        }
        if (BUILDING_getrotationy() == D3DX_PI * 0.5f) {
            SelectSquare[0].vec = SQUAREVECTOR2{ 0, -1 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 0, 1 };
        }
        if (BUILDING_getrotationy() == 0.0f) {
            SelectSquare[0].vec = SQUAREVECTOR2{ 1, 0 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ -1, 0 };
        }
        if (BUILDING_getrotationy() == -D3DX_PI * 0.5f) {
            SelectSquare[0].vec = SQUAREVECTOR2{ 0, 1 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 0, -1 };
        }
    }
    else if (BUILDING_getbuildingform() == BUILDING_FORM_PATTERN_SERIES4) {
        SelectSquare[1].use = true;
        SelectSquare[2].use = true;
        SelectSquare[3].use = true;
        if (BUILDING_getrotationy() == D3DX_PI) {
            SelectSquare[0].vec = SQUAREVECTOR2{ -1, 0 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 1, 0 };
            SelectSquare[3].vec = SQUAREVECTOR2{ 2, 0 };
        }
        if (BUILDING_getrotationy() == D3DX_PI * 0.5f) {
            SelectSquare[0].vec = SQUAREVECTOR2{ 0, -1 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 0, 1 };
            SelectSquare[3].vec = SQUAREVECTOR2{ 0, 2 };
        }
        if (BUILDING_getrotationy() == 0.0f) {
            SelectSquare[0].vec = SQUAREVECTOR2{ 1, 0 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ -1, 0 };
            SelectSquare[3].vec = SQUAREVECTOR2{ -2, 0 };
        }
        if (BUILDING_getrotationy() == -D3DX_PI * 0.5f) {
            SelectSquare[0].vec = SQUAREVECTOR2{ 0, 1 };
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 0, -1 };
            SelectSquare[3].vec = SQUAREVECTOR2{ 0, -2 };
        }
    }
    else if (BUILDING_getbuildingform() == BUILDING_FORM_PATTERN_KEYBRACKETS) {
        SelectSquare[1].use = true;
        SelectSquare[2].use = true;
        if (BUILDING_getrotationy() == D3DX_PI) {
            SelectSquare[1].vec = SQUAREVECTOR2{ 1, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 0, -1 };
        }
        if (BUILDING_getrotationy() == D3DX_PI * 0.5f) {
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, 1 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 1, 0 };
        }
        if (BUILDING_getrotationy() == 0.0f) {
            SelectSquare[1].vec = SQUAREVECTOR2{ -1, 0 };
            SelectSquare[2].vec = SQUAREVECTOR2{ 0, 1 };
        }
        if (BUILDING_getrotationy() == -D3DX_PI * 0.5f) {
            SelectSquare[1].vec = SQUAREVECTOR2{ 0, -1 };
            SelectSquare[2].vec = SQUAREVECTOR2{ -1, 0 };
        }
    }
    else if (BUILDING_getbuildingform() == BUILDING_FORM_PATTERN_SQUARE) {
        SelectSquare[1].use = true;
        SelectSquare[2].use = true;
        SelectSquare[3].use = true;
        SelectSquare[1].vec = SQUAREVECTOR2{ -1, 0 };
        SelectSquare[2].vec = SQUAREVECTOR2{ 0, 1 };
        SelectSquare[3].vec = SQUAREVECTOR2{ -1, 1 };
    }
    SQUARE_squareposupdate();
}

void SQUARE_move(int x, int z) {
    if ((Square[SelectSquare[0].pos.z + z][SelectSquare[0].pos.x + x].available ||
         Square[SelectSquare[0].pos.z + z][SelectSquare[0].pos.x + x].building) &&
         (SelectSquare[1].use == false ||
          Square[SelectSquare[1].pos.z + z][SelectSquare[1].pos.x + x].available ||
          Square[SelectSquare[1].pos.z + z][SelectSquare[1].pos.x + x].building) &&
          (SelectSquare[2].use == false ||
           Square[SelectSquare[2].pos.z + z][SelectSquare[2].pos.x + x].available ||
           Square[SelectSquare[2].pos.z + z][SelectSquare[2].pos.x + x].building) &&
           (SelectSquare[3].use == false ||
            Square[SelectSquare[3].pos.z + z][SelectSquare[3].pos.x + x].available ||
            Square[SelectSquare[3].pos.z + z][SelectSquare[3].pos.x + x].building)) {
        Selectpos += SQUAREVECTOR2{ x, z };
        SQUARE_squareposupdate();
    }
}

void SQUARE_initialize(void) {
    // �T�[�o�[�ʐM(�}�b�v���擾)�̗\��
    BUILD_DATA_send(*Square);

    Selectpos = START_SQUARE_POS;           // �ʒu�������ʒu�ɐݒ�
    SQUARE_formupdate();
    SQUARE_squareposupdate();
    MakeVertexField(DIRECT3D_get_D3DD());   // ���_���̍쐬
}

void SQUARE_finalize(void) {
    if (VtxBuffFrame != NULL) {// ���_�o�b�t�@�̊J��
        VtxBuffFrame->Release();
        VtxBuffFrame = NULL;
    }
}

void SQUARE_update(void) {
    SQUARE_formupdate();
    // �ړ�
    if (KEYBOARD_trigger(DIK_W)) {
        if (BUILDCAMERA_getroty() == D3DX_PI)SQUARE_move(0, 1);
        else if (BUILDCAMERA_getroty() == D3DX_PI * 0.5f)SQUARE_move(-1, 0);
        else if (BUILDCAMERA_getroty() == 0.0f)SQUARE_move(0, -1);
        else if (BUILDCAMERA_getroty() == -D3DX_PI * 0.5f)SQUARE_move(1, 0);
    }
    if (KEYBOARD_trigger(DIK_A)) {
        if (BUILDCAMERA_getroty() == D3DX_PI)SQUARE_move(-1, 0);
        else if (BUILDCAMERA_getroty() == D3DX_PI * 0.5f)SQUARE_move(0, -1);
        else if (BUILDCAMERA_getroty() == 0.0f)SQUARE_move(1, 0);
        else if (BUILDCAMERA_getroty() == -D3DX_PI * 0.5f)SQUARE_move(0, 1);
    }
    if (KEYBOARD_trigger(DIK_S)) {
        if (BUILDCAMERA_getroty() == D3DX_PI)SQUARE_move(0, -1);
        else if (BUILDCAMERA_getroty() == D3DX_PI * 0.5f)SQUARE_move(1, 0);
        else if (BUILDCAMERA_getroty() == 0.0f)SQUARE_move(0, 1);
        else if (BUILDCAMERA_getroty() == -D3DX_PI * 0.5f)SQUARE_move(-1, 0);
    }
    if (KEYBOARD_trigger(DIK_D)) {
        if (BUILDCAMERA_getroty() == D3DX_PI)SQUARE_move(1, 0);
        else if (BUILDCAMERA_getroty() == D3DX_PI * 0.5f)SQUARE_move(0, 1);
        else if (BUILDCAMERA_getroty() == 0.0f)SQUARE_move(-1, 0);
        else if (BUILDCAMERA_getroty() == -D3DX_PI * 0.5f)SQUARE_move(0, -1);
    }
}

void SQUARE_draw(void) {
    // �t���[���\��
    LPDIRECT3DDEVICE9 pDevice = DIRECT3D_get_D3DD();
    pDevice->SetRenderState(D3DRS_LIGHTING, FALSE);                 // ���C�e�B���O�𖳌���
    // ���Z�����ɐݒ�
    pDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);			// ���� = �]����(SRC) + �]����(DEST)
    pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);		// ���\�[�X�J���[�̎w��
    pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);			// ���f�X�e�B�l�[�V�����J���[�̎w��
    pDevice->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);				// Z�o�b�t�@�[�̏������݂����Ȃ�
    pDevice->SetStreamSource(0, VtxBuffFrame, 0, sizeof(VERTEX_3D));
    pDevice->SetFVF(FVF_VERTEX_3D);
    pDevice->SetTexture(0, TEXTURE_get_texture(TEST_SQUARE_FRAME));
    for (int i = 0; i < 4; i++)
        if (SelectSquare[i].use) {
            {   // �}�g���b�N�X�ݒ�
                D3DXMATRIX  mtxWorldSquare;
                D3DXMatrixIdentity(&mtxWorldSquare);    // ���[���h�}�g���b�N�X�̏�����(�P�ʍs��)
                {   // �ʒu���f
                    D3DXMATRIX mtxTranslate;
                    D3DXMatrixTranslation(&mtxTranslate, SelectSquare[i].pos.x * SQUARE_WIDTH, 0.0f, SelectSquare[i].pos.z * SQUARE_WIDTH);
                    D3DXMatrixMultiply(&mtxWorldSquare, &mtxWorldSquare, &mtxTranslate);
                }
                pDevice->SetTransform(D3DTS_WORLD, &mtxWorldSquare);
            }
            pDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, 0, 2);
        }

    pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);                  // ���C�e�B���O��L����
    // �ʏ�u�����h�ɖ߂�
    pDevice->SetRenderState(D3DRS_BLENDOP, D3DBLENDOP_ADD);			// ���� = �]����(SRC) + �]����(DEST)
    pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);		// ���\�[�X�J���[�̎w��
    pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);	// ���f�X�e�B�l�[�V�����J���[�̎w��
    pDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);				// Z�o�b�t�@�[�̏������݂�����
}

SQUARE* SQUARE_get(void) {
    return *Square;
}

SELECTSQUARE* SQUARE_getSelectSquare(void) {
    return SelectSquare;
}

SQUAREVECTOR2* SQUARE_getpos(void) {
    return &Selectpos;
}

HRESULT MakeVertexField(LPDIRECT3DDEVICE9 pDevice) {
    //���_�f�[�^�쐬
    if (FAILED(pDevice->CreateVertexBuffer(sizeof(VERTEX_3D) * 4, D3DUSAGE_WRITEONLY, FVF_VERTEX_3D, D3DPOOL_MANAGED, &VtxBuffFrame, NULL)))return E_FAIL;

    {
        //���_�f�[�^��ύX���邽�߂̃|�C���^
        VERTEX_3D *pVtx;

        //���b�N(���_�f�[�^��VRAM���烁�����Ɏ����Ă���(���_�f�[�^��ύX�\�ɂ���))
        VtxBuffFrame->Lock(0, 0, (void**)&pVtx, 0);

        //���_���W
        pVtx[0].pos = D3DXVECTOR3(-SQUARE_WIDTH / 2, 0.0f, SQUARE_WIDTH / 2);
        pVtx[1].pos = D3DXVECTOR3(SQUARE_WIDTH / 2, 0.0f, SQUARE_WIDTH / 2);
        pVtx[2].pos = D3DXVECTOR3(-SQUARE_WIDTH / 2, 0.0f, -SQUARE_WIDTH / 2);
        pVtx[3].pos = D3DXVECTOR3(SQUARE_WIDTH / 2, 0.0f, -SQUARE_WIDTH / 2);

        //�@���x�N�g��
        pVtx[0].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
        pVtx[1].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
        pVtx[2].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
        pVtx[3].nor = D3DXVECTOR3(0.0f, 1.0f, 0.0f);

        //�J���[�ύX(RGBA)
        pVtx[0].col = D3DXCOLOR(0.1f, 1.0f, 1.0f, 0.5f);
        pVtx[1].col = D3DXCOLOR(0.1f, 1.0f, 1.0f, 0.5f);
        pVtx[2].col = D3DXCOLOR(0.1f, 1.0f, 1.0f, 0.5f);
        pVtx[3].col = D3DXCOLOR(0.1f, 1.0f, 1.0f, 0.5f);

        //�e�N�X�`�����W
        pVtx[0].tex = D3DXVECTOR2(0.0f, 0.0f);
        pVtx[1].tex = D3DXVECTOR2(1.0f, 0.0f);
        pVtx[2].tex = D3DXVECTOR2(0.0f, 1.0f);
        pVtx[3].tex = D3DXVECTOR2(1.0f, 1.0f);

        //�A�����b�N(���_�f�[�^������������VRAM�ɕԂ�(���_�f�[�^�ύX�s�ɂȂ�))
        VtxBuffFrame->Unlock();
    }

    return S_OK;
}