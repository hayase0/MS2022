/*==============================================================================
    DirectX9_HEW_ROC
    [guide.cpp]
    �E�K�C�h
--------------------------------------------------------------------------------
    @Author HAYASE SUZUKI(THS_AT12C342_21_85004) / 2019_12_15-2019_12_
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "window.h"
#include "texture.h"
#include "sprite.h"
#include "guide.h"

GUIDE_POS g_pos = GUIDE_NONE;

void GUIDE_initialize(void) {

}
void GUIDE_finalize(void) {

}
void GUIDE_update(void) {

}
void GUIDE_draw(void) {
    if (g_pos != GUIDE_NONE) {
        SPRITE_set_color(D3DXCOLOR(1.0f, 0.0f, 0.0f, 0.8f));
        if(g_pos == GUIDE_LEFT)
        SPRITE_draw(TEST_GUIDE, 50, WINDOW_HEIGHT / 2 + 50, 0, 0, 440, 220, 220.0f, 110.0f, 3.0f, 3.0f, D3DX_PI / 2);
        else if (g_pos == GUIDE_RIGHT)
        SPRITE_draw(TEST_GUIDE, WINDOW_WIDTH - 60, WINDOW_HEIGHT / 2 - 100, 0, 0, 440, 220, 220.0f, 110.0f, 3.0f, 3.0f, -D3DX_PI / 2);
        else if (g_pos == GUIDE_UP)
        SPRITE_draw(TEST_GUIDE, WINDOW_WIDTH / 2 - 100, 50, 0, 0, 440, 220, 220.0f, 110.0f, 3.0f, 3.0f, D3DX_PI);

        SPRITE_set_color(D3DXCOLOR(1.0f, 1.0f, 1.0f, 1.0f));
    }
}

void GUIDE_setpos(GUIDE_POS pos) {
    g_pos = pos;
}