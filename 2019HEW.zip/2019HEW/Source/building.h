/*==============================================================================
    DirectX9_HEW_ROC
    [building.h]
    �E����
--------------------------------------------------------------------------------
    @Author RYUJI SEIKE(THS_AT12C342_23_80310) / 2019_12_17
================================================================================
    �X�V����

/*============================================================================*/

#pragma once

#include "build_data.h"
#include "item.h"



void BUILDING_initialize(void);
void BUILDING_update(void);
void BUILDING_draw(void);
BUILDING_FORM_PATTERN BUILDING_getbuildingform(void);
float BUILDING_getrotationy(void);