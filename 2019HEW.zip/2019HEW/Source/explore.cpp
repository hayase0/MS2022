/*==============================================================================
    DirectX9_HEW_ROC
    [explore.cpp]
    �E�T���V�[��
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_11_09-
================================================================================
    �X�V����

/*============================================================================*/
#include "main.h"
#include "texture.h"
#include "sprite.h"
#include "window.h"

#include "scene.h"
#include "phase.h"
#include "state.h"

#include "collision_box.h"
#include "ui.h"

#include "keyboard.h"

#include "player.h"
#include "target.h"
#include "item.h"
#include "ARM.h"
#include "chain.h"
#include "camera.h"
#include "stage.h"
#include "stage_f.h"
#include "floatmatter.h"
#include "map.h"
#include "background.h"

#include "fall.h"

#include "transition.h"

#include "arm.h"

#include "shadow.h"

/*============================================================================*/
void EXPLORE_initialize(void) {
    PHASE_set(PHASE_BEGIN);
    TRANSITION_set(FADE_IN, 60);

    COLLISION_BOX_initialize();
    PLAYER_initialize();
    ARM_initialize();
    CHAIN_initialize();
    CAMERA_initialize();
    //STAGE_initialize();
    STAGE_F_initialize();
    TARGET_initialize();
    ITEM_initialize();
    FLOATMATTER_initialize();
    BACKGROUND_initialize();
    FALL_initialize();
    SHADOW_initialize();
    
}
void EXPLORE_finalize(void) {
    FLOATMATTER_finalize();
    STATE_set(STATE_NORMAL);
}

void EXPLORE_update(void) {
    PHASE_function(SCENE_get());
    BACKGROUND_update(); 
    SHADOW_update();
}
void EXPLORE_draw(void) {
    //SPRITE_draw(TEST_05);
    CAMERA_setting();
    BACKGROUND_draw();
    PLAYER_draw();
    ARM_draw();
    CHAIN_draw();
    STATE_draw();
    //STAGE_draw();
    STAGE_F_draw();
    TARGET_draw();
    ITEM_draw();
    UI_draw();
    FLOATMATTER_draw();
    FALL_draw();
    SHADOW_draw();
}

/*============================================================================*/
void EXPLORE_begin(void) {
    if (!TRANSITION_check()) PHASE_set(PHASE_RUN);
}
void EXPLORE_run(void) {
    STATE_update();
}
void EXPLORE_end(void) {
    // if (!TRANSITION_check()) SCENE_change(TITLE);
    SCENE_change(SCENE_BUILD);
}
