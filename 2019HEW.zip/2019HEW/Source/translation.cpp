/*==============================================================================
    DirectX9_HEW_ROC
    [translation.cpp]
    �E�������UV���W�ɕϊ�
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2020_01_20-
================================================================================
    �X�V����

/*============================================================================*/
#include "character.h"
#include "translation.h"
#include <string.h>

CHARACTER TRANSLATION(const char *string) {
    CHARACTER character;

    for (int i = 0; i < MAX_STRING + 1; i++) {
        if (strncmp(&string[i * 2], "\0", 1) == 0) {
            character.word[i].num_x = -1;
            character.word[i].num_y = -1;
            break;
        }

        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "�A", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�C", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�E", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�G", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�I", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�J", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�L", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�N", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�P", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�R", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�T", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�V", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�X", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�Z", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�\", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�^", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�`", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�c", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�e", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�g", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�i", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�j", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�k", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�l", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�m", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�n", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "�q", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "�t", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "�w", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "�z", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "�}", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "�~", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "�K", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "�M", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "�O", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "�Q", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "�S", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "�U", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "�W", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "�Y", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "�[", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "�]", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "�_", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�a", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�d", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�f", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�h", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�o", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�r", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�u", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�x", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�{", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�p", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�s", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�v", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�y", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�|", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�@", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�B", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�D", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�F", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "�H", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�b", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�`", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�a", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�b", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�c", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�d", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�e", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 0;
        }
        if (strncmp(&string[i * 2], "�f", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�g", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�h", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�i", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�j", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�k", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 1;
        }
        if (strncmp(&string[i * 2], "�l", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�m", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�n", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�o", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�p", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�q", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 2;
        }
        if (strncmp(&string[i * 2], "�r", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�s", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�t", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�u", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�v", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�w", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 3;
        }
        if (strncmp(&string[i * 2], "�x", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�y", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 5;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 6;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 7;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 8;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "�O", 2) == 0) {
            character.word[i].num_x = 0;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�P", 2) == 0) {
            character.word[i].num_x = 1;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�Q", 2) == 0) {
            character.word[i].num_x = 2;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�R", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�S", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�T", 2) == 0) {
            character.word[i].num_x = 5;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�U", 2) == 0) {
            character.word[i].num_x = 6;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�V", 2) == 0) {
            character.word[i].num_x = 7;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�W", 2) == 0) {
            character.word[i].num_x = 8;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�X", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�A", 2) == 0) {
            character.word[i].num_x = 3;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "�B", 2) == 0) {
            character.word[i].num_x = 4;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 9;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "�I", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�H", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�^", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 4;
        }
        if (strncmp(&string[i * 2], "�[", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "�`", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "�Q", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 9;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 10;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 11;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 12;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 13;
        }
        if (strncmp(&string[i * 2], "�i", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�j", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�u", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�v", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�o", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "�p", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 14;
        }
        if (strncmp(&string[i * 2], "��", 2) == 0) {
            character.word[i].num_x = 14;
            character.word[i].num_y = 15;
        }
        if (strncmp(&string[i * 2], "�@", 2) == 0) {
            character.word[i].num_x = 15;
            character.word[i].num_y = 15;
        }

        //// ���ˑ�����
        // �X�y�[�h
        if (strncmp(&string[i * 2], "sp", 2) == 0) {
            character.word[i].num_x = 10;
            character.word[i].num_y = 15;
        }
        // �n�[�g
        if (strncmp(&string[i * 2], "he", 2) == 0) {
            character.word[i].num_x = 11;
            character.word[i].num_y = 15;
        }
        // �N���u
        if (strncmp(&string[i * 2], "cl", 2) == 0) {
            character.word[i].num_x = 12;
            character.word[i].num_y = 15;
        }
        // �_�C��
        if (strncmp(&string[i * 2], "di", 2) == 0) {
            character.word[i].num_x = 13;
            character.word[i].num_y = 15;
        }
    }

    return character;
}
