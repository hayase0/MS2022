///*==============================================================================
//    DirectX9_HEW_ROC
//    [stage.cpp]
//    �E�T���V�[��(Explore)-�X�e�[�W
//--------------------------------------------------------------------------------
//    @Author YUSUKE TAMURA (THS_AT12C342_27_81001)  /  2019_10_28-2019_10_28
//==============================================================================*/
//#include "main.h"
// 
//#include "stage.h"
//#include "stage_f.h"
//#include "collision_box.h"
//
//#define DISTANCE_X     (200.0f)
//#define DISTANCE_Z     (300.0f) 
//
//void SetBuilding(float posx, float posy, float posz);
//void SetItem(float posx, float posy, float posz);
//void SetTarget(float posx, float posy, float posz);
//
//OBJECT building[MAX_BUILDING];
//OBJECT target[MAX_TARGETa];
//OBJECT item[MAX_BUILDING];
//
//void STAGE_initialize() {
//    for (int i = 0; i < MAX_BUILDING; i++) {
//        building[i].meshIndex = MESH_INDEX_BUILDING;
//        building[i].isuse = false;
//        item[i].isuse = false;
//    }
//    for (int i = 0; i < MAX_TARGETa; i++) {
//        target[i].meshIndex = MESH_INDEX_CHIPS;
//        target[i].isuse = false;
//    }
//    SetTarget(0, 400, 100);
//    SetTarget(-300, 500, 100);
//    SetTarget(0, 300, -700);
//    SetTarget(100, 600, -500);
//    SetTarget(-200, 300, 400);
//    SetTarget(500, 400, 200);
//    SetTarget(700, 500, -300);
//    SetTarget(500, 400, 700);
//    SetTarget(-400, 600, 1000);
//    SetTarget(0, -300, 1000);
//    
//    SetBuilding(0.0f, 0.0f, 0.0f);
//    building[0].vecPosition = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
//    building[0].vecRotation = D3DXVECTOR3(D3DX_PI, 0.0f, 0.0f);
//    building[0].vecScale = D3DXVECTOR3(100.0f, 100.0f, 100.0f);
//    COLLISION_BOX_setting(&building[0]);
//
//    SetBuilding(0.0f, 0.0f, -400.0f);
//    SetBuilding(-DISTANCE_X, 0.0f, -400.0f);
//    SetBuilding(DISTANCE_X, 0.0f, -400.0f);
//
//    SetBuilding(-DISTANCE_X, 0.0f, -600.0f);
//    SetBuilding(DISTANCE_X, 0.0f, -600.0f);
//
//    SetBuilding(-DISTANCE_X, 0.0f, DISTANCE_Z);
//    //SetBuilding(0.0f, 0.0f, DISTANCE_Z);
//    SetBuilding(DISTANCE_X, 0.0f, DISTANCE_Z);
//
//    SetBuilding(-DISTANCE_X, 0.0f, DISTANCE_Z + 200.0f);
//    //SetBuilding(0.0f, 0.0f, DISTANCE_Z + 200.0f);
//    SetBuilding(DISTANCE_X, 0.0f, DISTANCE_Z + 200.0f);
//
//    SetBuilding(-DISTANCE_X, 0.0f, DISTANCE_Z + 400.0f);
//    SetBuilding(0.0f, 0.0f, DISTANCE_Z + 400.0f);
//    SetBuilding(DISTANCE_X, 0.0f, DISTANCE_Z + 400.0f);
//
//    SetBuilding(-80.0f, 0.0f, DISTANCE_Z + 120.0f);
//    SetBuilding(0.0f, 75.0f, DISTANCE_Z + 120.0f);
//    SetBuilding(80.0f, 150.0f, DISTANCE_Z + 120.0f);
//    SetBuilding(80.0f, 290.0f, DISTANCE_Z + 200.0f);
//    SetBuilding(0.0f, 470.0f, DISTANCE_Z + 200.0f);
//
//    //SetItem(0.0f, 5.0f, 700.0f);
//    SetItem(0.0f, 550.0f, DISTANCE_Z + 200.0f);
//    //SetItem(-DISTANCE_X, 0.0f, DISTANCE_Z);
//    //SetItem(DISTANCE_X, 0.0f, DISTANCE_Z + 400.0f);
//}
//
//void STAGE_finalize() {
//
//}
//
//void STAGE_update() {
//
//}
//
//void STAGE_draw() {
//    for (int i = 0; i < MAX_BUILDING; i++) {
//        if (building[i].isuse)
//            MESH_render(&building[i], MESH_INDEX_BUILDING);
//    }
//    for (int i = 0; i < MAX_BUILDING; i++) {
//        if (item[i].isuse)
//            MESH_render(&item[i], MESH_INDEX_MELON);
//    }
//    for (int i = 0; i < MAX_TARGETa; i++) {
//        if (target[i].isuse)
//            MESH_render(&target[i], MESH_INDEX_CHIPS);
//    }
//    OBJECT object;
//    object.vecPosition = D3DXVECTOR3(0.0f, 0.0f, DISTANCE_Z + 200.0f);
//    object.vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
//    object.vecScale = D3DXVECTOR3(4.0f, 28.0f, 4.0f);
//
//    MESH_render(&object, MESH_INDEX_BUILDING);
//    /*for (int i = 0; i < MAX_BUILDING; i++)
//        if (building[i].isuse)
//            COLLISION_BOX_draw(&building[i]);*/
//}
//
//void SetBuilding(float posx, float posy, float posz) {
//    for (int i = 0; i < MAX_BUILDING; i++) {
//        if (building[i].isuse == false) {
//            building[i].vecPosition = D3DXVECTOR3(posx, posy, posz);
//            building[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
//            building[i].vecScale = D3DXVECTOR3(7.0f, 7.0f, 7.0f);
//            building[i].isuse = true;
//            COLLISION_BOX_setting(&building[i]);
//            STAGE_F_set_collision_object(&building[i]);
//            break;
//        }
//    }
//}
//
//void SetItem(float posx, float posy, float posz) {
//    for (int i = 0; i < MAX_ITEM; i++) {
//        if (item[i].isuse == false) {
//            item[i].vecPosition = D3DXVECTOR3(posx, posy, posz);
//            item[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
//            item[i].vecScale = D3DXVECTOR3(5.0f, 5.0f, 5.0f);
//            item[i].isuse = true;
//            break;
//        }
//    }
//}
//
//void SetTarget(float posx, float posy, float posz) {
//    for (int i = 0; i < MAX_TARGETa; i++) {
//        if (target[i].isuse == false) {
//            target[i].vecPosition = D3DXVECTOR3(posx, posy, posz);
//            target[i].vecRotation = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
//            target[i].vecScale = D3DXVECTOR3(10.0f, 10.0f, 10.0f);
//            target[i].isuse = true;
//            break;
//        }
//    }
//}
//
//OBJECT *STAGE_get_building(void) {
//    return building;
//}
//
//OBJECT *STAGE_get_item(void) {
//    return item;
//}
//
//OBJECT *STAGE_get_target(void) {
//    return target;
//}