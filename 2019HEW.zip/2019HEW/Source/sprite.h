/*==============================================================================
    DirectX9
    [sprite.h]
    �E�X�v���C�g
--------------------------------------------------------------------------------
    @Author WATARU FUKUOKA (THS_AT12C342_36_80299)  /  2019_09_20-2019_09_20
================================================================================
    �X�V����

/*============================================================================*/
#pragma once

#include "window.h"
#include "texture.h"

struct Player_pos {
    float x[4];
    float y[4];
};

void SPRITE_set_color(D3DCOLOR color);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx = WINDOW_CENTER_X, float dy = WINDOW_CENTER_Y);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th,
                 D3DCOLOR color);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th,
                 float cx, float cy, float sx, float sy, float rotation);

void SPRITE_draw(TEXTURE_INDEX texture_index, 
                 float dx, float dy, 
                 int tx, int ty, int tw, int th,
                 float cx, float cy, float sx, float sy, float rotation, int a);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 int tx, int ty, int tw, int th,
                 float cx, float cy, float sx, float sy, float rotation,
                 D3DCOLOR color);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 float tw, float th,
                 char tx_num, char ty_num,
                 int ts,
                 D3DCOLOR color);

void SPRITE_draw(TEXTURE_INDEX texture_index,
                 float dx, float dy,
                 float tw, float th,
                 D3DCOLOR color);

Player_pos SPRITE_player_get(void);
